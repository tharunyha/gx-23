navbar={
    dropdown:[{
        title:'Insure',
        category:[
            {
                name:"Health Insurance",
                values:[
                    {name:"Individual Health Insurance"},
                    {name:"Family Health Insurance"},
                    {name:"Health Infinity Plan"},
                    {name:"Arogya Sanjeevani Policy"},
                    {name:"Topup Health Insurance"},
                    {name:"Corono Kavach Policy"},
                ]
            },
            {
                name:"EV Insurance",
                values:[
                    {name:"Electric Bike Insurance"},
                    {name:"Electric Car Insurance"},
                    {name:"Electric Commercial Vehicle Insurance"},
                    ]
            }
        ]
    }]
}