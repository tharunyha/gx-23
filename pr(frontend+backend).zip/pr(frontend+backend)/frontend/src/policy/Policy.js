import React from "react";
import { NavHead } from "../components/NavHead";
import axios from "axios";
import { useState, useEffect } from "react";
import PolicyCard from "../policy/PolicyCard";
import { useParams } from "react-router-dom";
import Footer from "../components/Footer";

export const PolicyCategories = () => {
  const { categoryType } = useParams();
  const token = localStorage.getItem("token")
  const [policies, setPolicy] = useState([]);
  useEffect(() => {
    viewPolicies();
  }, [categoryType]);
  console.log(categoryType);
  console.log(window.location);
  const viewPolicies = async () => {
    try {
      const response = await fetch(
        `http://localhost:8080/PoliciesByCategory/${categoryType}`
      );
      const data = await response.json();
      setPolicy(data); // Assuming data is an array of policies
      console.log(response);
    } catch (error) {
      console.error("Error fetching policies:", error);
    }
  };
  
  return (
    <div className="policy-list">
    <NavHead />
    {policies
      .filter(policy=>policy.policyStatus===true)
      .map((policy) => (
      <PolicyCard key={policy.id} policy={policy} />
    ))}
    <Footer/>
    </div>
  )};