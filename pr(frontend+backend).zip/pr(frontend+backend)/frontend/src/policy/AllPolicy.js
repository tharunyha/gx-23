import React from "react";
import { NavHead } from "../components/NavHead";
import { useState, useEffect } from "react";
import PolicyCard from "../policy/PolicyCard";

import Footer from "../components/Footer";


const AllPolicy = () => {
    const [policies, setPolicy] = useState([]);
    const token = localStorage.getItem("token");
    useEffect(() => {
      viewPolicies();
    }, []);
 
    const viewPolicies = async () => {
      try {
        const response = await fetch(
          `http://localhost:8080/AllPolicies`
         );
        const data = await response.json();
        setPolicy(data); // Assuming data is an array of policies
        console.log(response);
      } catch (error) {
        console.error("Error fetching policies:", error);
      }
    };
  return (
    <div className="policy-list">
    <NavHead />
    {policies
      .filter(policy=>policy.policyStatus===true)
      .map((policy) => (
      <PolicyCard key={policy.id} policy={policy} />
    ))}
    <Footer/>
    </div>
  )
}

export default AllPolicy