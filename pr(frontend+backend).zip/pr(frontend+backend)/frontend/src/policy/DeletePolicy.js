import React, { useState } from "react";
import { Form, Button } from "react-bootstrap";
import axios from "axios";
import { NavHead } from "../components/NavHead";
import { Display } from "react-bootstrap-icons";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

const DeletePolicy = () => {
    const{policyName}=useParams();
    const token = localStorage.getItem("token");
  const [policyData, setPolicyData] = useState({
    policyStatus: "",
  });
  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.delete(
        `http://localhost:8080/deletePolicy/${policyName}`,
        policyData,{
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      console.log("Policy deleted successfully:", response.data);
      navigate("/BajajAllianz/ViewPolicy");
    } catch (error) {
      console.error("Error deleting policy:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setPolicyData((prevData) => ({
      ...prevData,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  return (
    <div>
      <NavHead />
      <div className="mt-3" style={{ width: "70%" }}>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="formPolicyDescription">
            <Form.Label>Policy Status</Form.Label>
            <Form.Check
              type="radio"
              label="Default Radio"
              name="radioGroup"
              id="option1"
              value={true}
            />
            <Form.Check
              type="radio"
              label="Disable Policy"
              name="radioGroup"
              id="option2"
              value={false}
            />
          </Form.Group>

          <Button variant="primary" type="submit">
            Delete Policy
          </Button>
        </Form>
      </div>
    </div>
  );
};

export default DeletePolicy;
