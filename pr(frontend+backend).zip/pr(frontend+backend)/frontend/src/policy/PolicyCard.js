import React from "react";
import Accordion from "react-bootstrap/Accordion";
import "../assets/css/card.css";
import { Link, useNavigate, useParams } from "react-router-dom";

const PolicyCard = ({ policy }) => {
  const { policyid } = useParams();
  const loginStatus = localStorage.getItem("isLoggedIn");
  const navigate = useNavigate();

  console.log(loginStatus)
  const loginHandle = ()=>{
    loginStatus=true ? (navigate(`/BajajAllianz/PolicyForm/${policy.policyName}/${policy.policyID}`)) :( alert("Please Login"),navigate('/BajajAllianz/PolicyForm'))}
  
    console.log("mini", loginStatus)
  return (
    <div className="policy-card m-2 p-2">
      <Accordion defaultActiveKey="0">
        <Accordion.Item eventKey="0">
          <Accordion.Header>
            <span>{policy.policyName} </span>
                <button className="buyPolicy py-3" onClick={loginHandle}>Buy Policy</button>
          
          
          </Accordion.Header>
          <Accordion.Body>{policy.policyDescription}</Accordion.Body>
        </Accordion.Item>
      </Accordion>
    </div>
  );
};

export default PolicyCard;
