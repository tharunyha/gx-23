import React, { useState } from "react";
import { Form, Button } from "react-bootstrap";
import axios from "axios";
import { NavHead } from "../components/NavHead";
import { Display } from "react-bootstrap-icons";
import { useNavigate } from "react-router-dom";
import Footer from "../components/Footer";

const CreatePolicy = () => {
  const [policyData, setPolicyData] = useState({
    policyName: "",
    policyCategory: "",
    policyDescription: "",
  });
  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(
        `http://localhost:8080/NewPolicy`,
        policyData,{
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      alert("Policy created successfully");
     navigate('/BajajAllianz/ViewPolicy')
    } catch (error) {
      console.error("Error creating policy", error);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setPolicyData((prevData) => ({
      ...prevData,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  return (
    <div>
    <NavHead/>
    <div className="mt-3" style={{width:"70%"}}>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="formPolicyName">
          <Form.Label>Policy Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter policy name"
            name="policyName"
            value={policyData.policyName}
            onChange={handleChange}
          />
        </Form.Group>

        <Form.Group controlId="formPolicyCategory">
          <Form.Label>Policy Category</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter policy category"
            name="policyCategory"
            value={policyData.policyCategory}
            onChange={handleChange}
          />
        </Form.Group>

        <Form.Group controlId="formPolicyDescription">
        <Form.Label>Policy Description</Form.Label>
          <Form.Control
            type="text"
            label="Policy Description"
            name="policyDescription"
            checked={policyData.policyDescription}
            onChange={handleChange}
          />
        </Form.Group>

        <Button variant="primary" type="submit">
          Create Policy
        </Button>
      </Form>
    </div>
    <Footer/>
    </div>
  );
};

export default CreatePolicy;
