import React, { useState, useEffect } from "react";
import { MdOutlineExpandMore } from "react-icons/md";
import Accordion from "react-bootstrap/Accordion";
import { PremiumCards } from "./PremiumCards";
import { AccordionHeader, Button, Form, FormControl } from "react-bootstrap";
import { NavHead } from "../components/NavHead";
import { useParams } from "react-router-dom";
import axios from "axios";

export const PolicyForm = () => {
  const { policyId } = useParams();
  const { policyName } = useParams();
  const userName = localStorage.getItem("userName");
  const userEmail = localStorage.getItem("useremail");
  const userId = localStorage.getItem("userid");
  const dob = localStorage.getItem("dob");
  const token = localStorage.getItem("token")

  const [returnAmounts, setReturnAmounts] = useState([]);
  const [selectedReturnAmount, setSelectedReturnAmount] = useState(null);
  const [selectedPremium, setSelectedPremium] = useState([]);
  const [premiums, setPremiums] = useState();


  const [User, setUserInfo] = useState({
    name: userName,
    email: userEmail,
    dob: dob,
  });
  
  const [Policy, setPolicyInfo] = useState({
    policyName: policyName,
    startDate: " ",
    endDate: " ",
    paymentAmount: "",
  });

  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: "",
    expiryDate: "",
  });

  const handleChange = (name, value) => {
    if (name === "startDate" || name === "endDate") {
      const formatdate = new Date(value).toISOString().split("T")[0];
      setPolicyInfo((prevPolicy) => ({ ...prevPolicy, [name]: formatdate }));
    } else {
      setPolicyInfo((prevPolicy) => ({ ...prevPolicy, [name]: value }));
    }
    setUserInfo((prevUser) => ({ ...prevUser, [name]: value }));

    setPaymentInfo((prevpaymentInfo) => ({
      ...prevpaymentInfo,
      [name]: value,
    }));
  };

  useEffect(() => {
    viewPremiums();
  }, []);

  const viewPremiums = async () => {
    try {
      const response = await axios.get("http://localhost:8080/PolicyPremium",{
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const data = response.data;
      setReturnAmounts(data);
    } catch (error) {
      console.error("Error fetching return amounts", error);
    }
  };

  const handleReturnAmountChange = async (event) => {
    const selectedAmount = event.target.value;
    setSelectedReturnAmount(selectedAmount);

    try {
      const response = await axios.get(
        `http://localhost:8080/PolicyPremium/${selectedAmount}`,{
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      console.log(response.data);
      setSelectedPremium(response.data);
    } catch (error) {
      console.error("Error fetching return amounts", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const policyData = {
      policyStartDate: Policy.startDate,
      policyEndDate: Policy.endDate,
      insuranceDetails: [Policy.insuranceDetails],
      policyAmount:premiums,
    };

   
    try {
      // Make an HTTP POST request to your backend
      const response = await axios.post(
      
        `http://localhost:8080/BuyPolicy/${policyId}/${userId}/${selectedPremium.policyPremiumId}`,
      policyData
      );
      alert("Policy Purchased Successfully");
      //navigate("/BajajAllianz/HomePage");
    } catch (error) {
      alert("Error submitting form", error);
      console.log(error);
    }

  };
  // console.log("dala",policyData)
  console.log("amt",premiums)
  return (
    <div>
      <NavHead />
      <div className="m-5" style={{ border: "black 1px solid" }}>
        <Accordion>
          <Accordion.Header
            className="bg-warn"
            expandIcon={<MdOutlineExpandMore />}
          >
            <h3>User Info</h3>
          </Accordion.Header>
          <Accordion.Body className="my-2">
            <Form style={{ fontSize: "larger" }}>
              <Form.Label>
                Name:
                <input
                  type="text"
                  name="name"
                  value={User.name}
                  onChange={handleChange}
                />
              </Form.Label>
              <br />
              <Form.Label>
                Email:
                <input
                  type="email"
                  name="email"
                  value={User.email}
                  onChange={handleChange}
                />
              </Form.Label>
            </Form>
          </Accordion.Body>
        </Accordion>

        <Accordion>
          <Accordion.Header expandIcon={<MdOutlineExpandMore />}>
            <h3>Policy Info</h3>
          </Accordion.Header>
          <Accordion.Body>
            <Form style={{ fontSize: "larger" }}>
              <Form.Label>
                Policy Name:
                <input
                  type="text"
                  name="Policy.policyName"
                  value={Policy.policyName}
                  onChange={handleChange}
                />
              </Form.Label>
              <br />
              <Form.Label>
                Policy Start Date:
                <input
                  type="date"
                  name="Policy.startDate"
                  value={Policy.startDate}
                  onChange={(e) => handleChange("startDate", e.target.value)}
                />
              </Form.Label>
              <br />
              <Form.Label>
                Policy End Date:
                <input
                  type="date"
                  name="Policy.endDate"
                  value={Policy.endDate}
                  onChange={(e) => handleChange("endDate", e.target.value)}
                />
              </Form.Label>
              <br />

              <div>
                <Form.Label>Select Return Amount:</Form.Label>
                <select
                  value={selectedReturnAmount}
                  onChange={handleReturnAmountChange}
                >
                  <option value="">Select...</option>
                  {returnAmounts.map((premium) => (
                    <option key={premium} value={premium.returnAmount}>
                      {premium.returnAmount}
                    </option>
                  ))}
                </select>

                <div
                  style={{
                    display: "flex",
                    alignContent: "center",
                    justifyContent: "center",
                  }}
                >
                  {selectedReturnAmount && (
                    <div>
                      <PremiumCards
                        selectedPremium={selectedPremium.durationOne}
                        duration={"1 YEAR"}
                        value={Policy.paymentAmount}
                        onClick={() => {
                          setPremiums(selectedPremium.durationOne);
                        }}
                      />
                    </div>
                  )}
                  {selectedReturnAmount && (
                    <div>
                      <PremiumCards
                        selectedPremium={selectedPremium.durationTwo}
                        duration={"2 YEAR"}
                        value={selectedPremium.durationTwo}
                        onClick={() => {
                          setPremiums(selectedPremium.durationTwo);
                        }}
                      />
                    </div>
                  )}
                  {selectedReturnAmount && (
                    <div>
                      <PremiumCards
                        selectedPremium={selectedPremium.durationThree}
                        duration={"3 YEAR"}
                        value={selectedPremium.durationThree}
                        onClick={() => {
                          setPremiums(selectedPremium.durationThree);
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>
            </Form>
          </Accordion.Body>
        </Accordion>
        
        <Accordion>
          <Accordion.Header expandIcon={<MdOutlineExpandMore />}>
            <h3>Payment Info</h3>
          </Accordion.Header>
          <Accordion.Body>
            <Form style={{ fontSize: "larger" }}>
              <Form.Label>
                Card Number:
                <input
                  type="text"
                  name="cardNumber"
                  value={paymentInfo.cardNumber}
                  onChange={handleChange}
                />
              </Form.Label>
              <br />
              <Form.Label>
                Expiry Date:
                <input
                  type="text"
                  name="expiryDate"
                  value={paymentInfo.expiryDate}
                  onChange={handleChange}
                />
              </Form.Label>
            </Form>
          </Accordion.Body>
        </Accordion>

        <Button className="p-2 my-2" variant="primary" onClick={handleSubmit}>
          Submit
        </Button>
      </div>
    </div>
  );
};
