import React, { useState } from 'react';
import { Card, Form, Button } from 'react-bootstrap';
import { NavHead } from '../components/NavHead';
import { useParams } from 'react-router-dom';
import { useEffect } from 'react';
import { PremiumCards } from './PremiumCards';

export const PremiumDetails = () => {
  //const{policyid}=useParams();
  const [premiumdetails, setPremium] = useState([]);

  useEffect(() => {
    const fetchPremium = async () => {
      try {
        const response = await fetch(`http://localhost:8080/Policy/1/premiumDetails`);
        const data = await response.json();
        setPremium(data);
      } catch (error) {
        console.error('Error fetching premium details:', error);
      }
    };

    fetchPremium();
  }, []);

  return (
    <div>
    <NavHead/>
    <div className="app" style={{display:"flex"}}>
      {premiumdetails.map((premium) => (
        <PremiumCards key={premium.id} premium={premium} />
      ))}
      </div>
      </div>
  );

};


