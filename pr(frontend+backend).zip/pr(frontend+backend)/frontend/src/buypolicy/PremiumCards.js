import React from "react";

export const PremiumCards = ({
  selectedPremium,duration
}) => {
  //const durationOne = selectedPremium ? selectedPremium.durationOne : " ";
  //const durationTwo = selectedPremium ? selectedPremium.durationTwo : " ";
  //const durationThree = selectedPremium ? selectedPremium.durationThree : " ";

  return (
    <div>
      <div>
        <div className="card m-5" style={{ border: "1px blue solid", width: "fit-content" }}>
          <div class="card-header bg-info bg-gradient">
            {duration}
            <input
              type="radio"
              name="premiumSelection"
              //value={selectedPremium}
            //onChange={() => onPremiumSelect(durationOne)}
            />
          </div>
          <div className="card-body p-5">
            <h5>${selectedPremium}</h5>
          </div>
        </div>
      </div>
    </div>
  );
};

