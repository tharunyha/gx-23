import React from "react";
import { useState, useEffect } from "react";
import { PremiumCards } from "./PremiumCards";
import axios from "axios";

const PolicyPremium = () => {
  const [returnAmounts, setReturnAmounts] = useState([]);
  const [selectedReturnAmount, setSelectedReturnAmount] = useState(null);
  const [premiums, setPremiums] = useState([]);

  useEffect(() => {
    viewPremiums();
  }, []);
  const viewPremiums = async () => {
    try {
      const response = await axios.get("http://localhost:8080/PolicyPremium");
      const data = response.data;
      setReturnAmounts(data);
    } catch (error) {
      console.error("Error fetching return amounts", error);
    }
  };
  const handleReturnAmountChange = async (event) => {
    const selectedAmount = event.target.value;
    setSelectedReturnAmount(selectedAmount);
    // Fetch corresponding durations based on the selected return amount
    // Example API call using fetch:
    try {
      const response = await axios.get(
        `http://localhost:8080/PolicyPremium/${selectedAmount}`
      );
      const data = response.data;

      setPremiums(data);
    } catch (error) {
      console.error("Error fetching return amounts", error);
    }
  };

  return (
    <div>
      <label>Select Return Amount:</label>
      <select value={selectedReturnAmount} onChange={handleReturnAmountChange}>
        <option value="">Select...</option>
        {returnAmounts.map((premium) => (
          <option key={premium} value={premium.returnAmount}>
            {premium.returnAmount}
          </option>
        ))}
      </select>

      {selectedReturnAmount && (
        <div>
          <PremiumCards
            returnAmount={selectedReturnAmount}
            durationOne={premiums.durationOne}
            durationTwo={premiums.durationTwo}
            durationThree={premiums.durationThree}
          />
          <button>Submit Card</button>
        </div>
      )}
    </div>
  );
};

export default PolicyPremium;
