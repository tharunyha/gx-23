import React from "react";
import { NavHead } from "../components/NavHead";
import axios from "axios";
import { useState, useEffect } from "react";
import PolicyCard from "../policy/PolicyCard";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";
import { MdEdit } from "react-icons/md";
import { MdDelete } from "react-icons/md";
import Footer from "../components/Footer";

export const ViewPolicy = () => {
  const [policies, setPolicy] = useState([]);
  const token=localStorage.getItem("token");
  const navigate = useNavigate();
  useEffect(() => {
    viewPolicies();
  }, []);
  const viewPolicies = async () => {
    try {
      const response = await fetch(`http://localhost:8080/AllPolicies`,{
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const data = await response.json();
      setPolicy(data); // Assuming data is an array of policies
      console.log(response);
    } catch (error) {
      console.error("Error fetching policies", error);
    }
  };
  
  const deletePolicy = async(id) => {
    try {
      const policy = await axios.delete(
        `http://localhost:8080/deletePolicy/${id}`,{
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
    window.location.reload();
    } catch (error) {
       //alert("Error deleting policy", error);
       console.log(error)
    }
  };
  console.log(policies.policyName)
  return (
    <div className="policy-list">
      <NavHead />
      <div><Link to={`/BajajAllianz/CreatePolicy`}>
      <Button className=" bg-info mt-3 p-3 ">Create Policy</Button>
    </Link>
    { policies
      .filter(policy=>policy.policyStatus===true)
      .map((policy) => (
      <div>
        <PolicyCard key={policy.id} policy={policy}></PolicyCard>
        <Link to={`/BajajAllianz/CreatePolicy`}>
        </Link>
          <Button className="bg-danger mx-2 " onClick={()=>deletePolicy(policy.policyID)}>
            <MdDelete />
          </Button>
          
      </div>
      
    ))}</div>
    <div className="mt-5">
        <h3>Policies Inactive</h3>
      {policies.length > 0 ? (
        policies
          .filter(policy=>policy.policyStatus===false)
          .map((policy) => (
          <div>
           
            <PolicyCard key={policy.id} policy={policy}></PolicyCard>
            <Link to={`/BajajAllianz/CreatePolicy`}>
            </Link>
             
              
          </div>
          
        ))
      ):(<p>No policy</p>)}
      
    </div>
   
      <Footer/>
    </div>
  );
};
