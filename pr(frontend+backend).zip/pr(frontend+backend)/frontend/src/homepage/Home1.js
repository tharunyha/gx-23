import React from "react";
import { useState } from "react";
import backimage from "../assets/img/homepagemain.webp";
import guinness from "../assets/img/guinness.webp";
import "../assets/css/homepage.css";
import { NavHead } from "../components/NavHead";
import { FaCarSide, FaHome } from "react-icons/fa";
import { MdTwoWheeler } from "react-icons/md";
import { BsSuitcase2Fill } from "react-icons/bs";
import { GiHealthNormal } from "react-icons/gi";
import { MdOutlinePets } from "react-icons/md";
import { Link,useParams } from "react-router-dom";


export const Homemain = () => {
  

  return (
    <div>
      <NavHead />
      <div
        className="homepagemain"
        style={{ backgroundImage: `url(${backimage})` }}
      >
        <div
          className="pt-5  guinness"
          style={{
            color: "#1e83c5",
            display: "flex",
            position: "absolute",
            marginLeft: "300px",
          }}
        >
          <img src={guinness} alt="Guinness Logo"></img>
          <div
            className="mt-3 mx-3"
            style={{
              textAlign: "justify",
              whiteSpace: "wrap",
              fontSize: "13px",
            }}
          >
            <h3>Care that Breaks Records ! </h3>
            <p className="mb-1">
              BAJAJ ALLIANZ GENERAL INSURANCE ACHIEVES A FEAT
            </p>
            <p>For the Largest Attendance at an Insurance Conference!</p>
          </div>
        </div>
        <div
          style={{
            paddingTop: "200px",
            color: "#1e83c5",
            marginLeft: "100px",
            textAlign: "justify",
          }}
        >
          <div>
            There is nothing that we can’t help you with. Drive worry-free as
            you have our round-the-clock assistance
          </div>
        </div>
        <div className="button-row mt-5 pb-0">
          <div
            className=" buttonrow "
            style={{
              display: "flex",
              gap:"80px",
              flexWrap: " wrap",
              placeContent: "space-evenly center",
              justifyContent: "center",
            }}
          >
            <Link to="/BajajAllianz/Policies/Motor">
              <button >
                <FaCarSide size={30} style={{ color: "#1e83c5" }} />
              </button>
            </Link>
            <Link to="/BajajAllianz/Policies/Motor" > <button >
            <MdTwoWheeler size={30} style={{ color: "#1e83c5" }} />
          </button></Link>
          <Link to="/BajajAllianz/Policies/Health"> <button>
          <GiHealthNormal size={30} style={{ color: "#1e83c5" }} />
        </button></Link>
            
          </div>
          <div class="container" style={{    marginLeft: "200px"}}>
            <div class="row row-cols-1 row-cols-sm-6 g-2 g-lg-3">
              <div class="col">
                <div class="p-3 ">
                   Car
                </div>
              </div>
              <div class="col">
                <div class="p-3 ">Two wheeler</div>
              </div>
             
              <div class="col">
                <div class="p-3 ">Health</div>
              </div>
             
            </div>
          </div>
        </div>
      </div>
  
    
    </div>
  );
};
