import React, { useState } from "react";
import { NavHead } from "../components/NavHead";
import { Homemain } from "./Home1";
import "../assets/css/home2.css";
import img1 from "../assets/img/init-1.webp";
import img2 from "../assets/img/init-2.webp";
import img3 from "../assets/img/img3.webp";
import img41 from "../assets/img/init4-1.png";
import img42 from "../assets/img/init4-2.png"
import { Button } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Footer from "../components/Footer";

const Home2 = () => {
  const [display, setDisplay] = useState("A");
  const handleClick = (display) => {
    setDisplay(display);
  };
  return (
    <div>
      <Homemain />
      <div
        className=" p-3"
        style={{ backgroundColor: "#3c71b5", color: "white" }}
      >
        <p style={{ fontSize: "xx-large", fontWeight: "normal" }}>
          NEW INITIATIVES
        </p>
        <div className="mx-5 p-3 ">
          <Button
            className=" mx-5 navbutton"
            onClick={() => handleClick("A")}
            active
          >
            1
          </Button>
          <button className="mx-5 navbutton" onClick={() => handleClick("B")}>
            2
          </button>
          <button className="mx-5  navbutton" onClick={() => handleClick("C")}>
            3
          </button>
          <button className="mx-5  navbutton" onClick={() => handleClick("D")}>
            4
          </button>
          <button className="mx-5  navbutton" onClick={() => handleClick("E")}>
            5
          </button>
        </div>
        <p style={{ fontSize: "x-large", fontWeight: "400" }}>
          We Set GUINNESS WORLD RECORDS ™ title at the General Insurance
          Festival of India (GIFI)
        </p>
        {display === "A" && <img src={img1}></img>}
        {display === "B" && (
          <div>
            <Container>
              <Row>
                <Col>
                  <img src={img2}></img>
                </Col>
                <Col
                  className="mt-3"
                  style={{ textAlign: "justify", fontWeight: "100" }}
                >
                  <p style={{ fontWeight: "lighter", fontSize: "medium" }}>
                    We hosted the first-ever General Insurance Festival of India
                    (GIFI) on the 3rd of July 2023, where we invited nominations
                    which recognized the top-ranked health and general insurance
                    advisors across the insurance industry.
                  </p>

                  <p style={{ fontWeight: "lighter", fontSize: "medium" }}>
                    The event was organised in Pune which officially set a new
                    Guinness World Records achievement for the Largest
                    attendance for an insurance conference.
                  </p>

                  <p style={{ fontWeight: "lighter", fontSize: "medium" }}>
                    There was a record turnout of 5235 attendees who contributed
                    to creating history worldwide in the insurance industry.
                    This record-breaking achievement was announced at the main
                    event of GIFI.
                  </p>
                </Col>
              </Row>
            </Container>
          </div>
        )}
        {display === "C" && (
          <div>
            <Container>
              <Row>
                <Col>
                  <img src={img3}></img>
                </Col>
                <Col
                  className="mt-3"
                  style={{ textAlign: "justify", fontWeight: "100" }}
                >
                  <p style={{ fontWeight: "lighter", fontSize: "medium" }}>
                    As per the directive of the Insurance Regulatory and
                    Development Authority of India (IRDAI), Caringly Yours Day
                    is being organized at Bajaj Allianz General Insurance Co.
                    Ltd. 2nd floor, 4th Hathroi, Gopalbari, Ajmer Road, Jaipur –
                    302001, on 22nd December 2023 from 10:00 am to 4:00 pm
                  </p>

                  <p style={{ fontWeight: "lighter", fontSize: "medium" }}>
                    If you have any queries regarding your existing insurance
                    policy from Bajaj Allianz General Insurance, visit our
                    branch office and we will assist you and address the
                    queries. We firmly stand with the customers in their direst
                    hour of need. In this journey of care, we believe in
                    providing unique services and resolving the worries of our
                    customers.
                  </p>

                </Col>
              </Row>
            </Container>
          </div>
        )}
        {display === "D" && (
            <div>
              <Container>
                <Row>
                  <Col >
                    <img src={img41} height={"70%"} width={"85%"}></img>
                  </Col>
                  <Col>
                  <img src={img42} height={"70%"} width={"85%"}></img>
                  </Col>
                </Row>
              </Container>
            </div>
          )}
      </div>
      <Footer/>
    </div>
  );
};

export default Home2;
