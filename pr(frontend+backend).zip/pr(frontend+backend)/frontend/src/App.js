import 'bootstrap/dist/css/bootstrap.min.css';

import './App.css';

import Login from './pages/Login';
import RegistrationForm from './pages/Registration';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Home2 from './homepage/Home2';
import Renew from './pages/Renew';
import Claim from './pages/Claim';
import PayPremium from './pages/PayPremium';
import { CustomerService } from './pages/CustomerService';
import RenewForm from './pages/RenewForm';
import { PremiumDetails } from './buypolicy/PremiumDetails';
import { PolicyCategories } from './policy/Policy';
import { PolicyForm } from './buypolicy/PolicyForm';
import { Payment } from './payment/Payment';
import UserProfile from './pages/UserProfile';
import ClaimForm from './claim/ClaimForm';
import CreatePolicy from './policy/CreatePolicy';
import { ViewPolicy } from './admin/ViewPolicy';
import DeletePolicy from './policy/DeletePolicy';
import PaymentPage from './payment/PaymentPage';
import PolicyPremium from './buypolicy/PolicyPremium';
import AllPolicy from './policy/AllPolicy';
import ForgotPassword from './pages/ForgotPassword';
import ForgotPasswordForm from './pages/ForgotPassword';


function App() {
  return (
    <div className="App">
    <BrowserRouter>
     <Routes>
     <Route path='/BajajAllianz/ForgotPassword/:email' element={<ForgotPasswordForm/>}></Route>
     <Route path='/BajajAllianz/Login' element={<Login />}></Route>
     <Route path='/BajajAllianz/UserProfile' element={<UserProfile />}></Route>
     <Route path='/BajajAllianz/Register' element={<RegistrationForm/>}></Route>
     <Route path='/BajajAllianz/HomePage' element={<Home2/>}></Route>
     <Route path='/BajajAllianz/Renew' element={<Renew/>}></Route>
     <Route path='/BajajAllianz/RenewForm/:buyPolicyId' element={<RenewForm/>}></Route>
     <Route path='/BajajAllianz/Claim' element={<Claim/>}></Route>
     <Route path='/BajajAllianz/ClaimForm/:policyId' element={<ClaimForm/>}></Route>
     <Route path='/BajajAllianz/Pay Premium' element={<PayPremium/>}></Route>
     <Route path='/BajajAllianz/Pay/:buyPolicyId' element={<Payment/>}></Route>
     <Route path='/BajajAllianz/Policies/:categoryType' element={<PolicyCategories/>}></Route>
     <Route path='/BajajAllianz/CustomerService' element={<CustomerService/>}/>
     <Route path='/BajajAllianz/:policyId/PremiumDetails' element={<PremiumDetails/>}/>
     <Route path='/BajajAllianz/PolicyForm/:policyName/:policyId' element={<PolicyForm/>}/>
     <Route path='/BajajAllianz/ViewPolicy' element={<ViewPolicy/>}/>
     <Route path='/BajajAllianz/AllPolicy' element={<AllPolicy/>}/>
     <Route path='/BajajAllianz/CreatePolicy' element={<CreatePolicy/>}/>
     <Route path='/RazorPay/:buyPolicyId' element={<PaymentPage/>}/>
     <Route path='/BajajAllianz/PolicyPremium' element={<PolicyPremium/>}/>
     <Route path='/BajajAllianz/DeletePolicy/:policyId' element={<DeletePolicy/>}/>
     </Routes>
     </BrowserRouter>
    </div>
  );
}

export default App;
