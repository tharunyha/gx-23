import React, { useState, useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { NavHead } from "../components/NavHead";
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
} from "react-bootstrap";

export const Payment = () => {
  const { buyPolicyId } = useParams();
  const [paymentDetails, setPaymentDetails] = useState({});
  const [paymentHistory, setPaymentHistory] = useState();
  const token = localStorage.getItem("token")
  const navigate = useNavigate();
  useEffect(() => {
    viewPremiumDetails();
    viewHistory();
  }, [buyPolicyId]);

  const viewPremiumDetails = async () => {
    try {
      const response = await fetch(
        `http://localhost:8080/Policy/${buyPolicyId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const data = await response.json();

      localStorage.setItem("premium", data.policyAmount);
      setPaymentDetails(data);
    } catch (error) {
      console.error("Error fetching policy:", error);
    }
  };
  const viewHistory = async () => {
    try {
      const response = await fetch(
        `http://localhost:8080/PremiumHistory/${buyPolicyId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            
          "Authorization": `Bearer ${token}`,
        }
      }
          
      
      );
      const data = await response.json();
      setPaymentHistory(data);
    } catch (error) {
      console.error("Error fetching policy:", error);
    }
  };
  console.log(paymentHistory)
  return (
    <div>
      <NavHead />
      <div className="mt-5">
        {paymentDetails && (
          <div
            className="m-5"
            style={{ display: "grid", justifyItems: "center" }}
          >
            <Card className="w-50">
              <CardHeader>Premium Amount</CardHeader>
              <CardBody>{paymentDetails.policyAmount}</CardBody>
              <CardFooter>
              <Link to={`/RazorPay/${buyPolicyId}`}>
              <Button>Pay Now</Button>
            </Link>
                
              </CardFooter>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};
