

import React, { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { NavHead } from "../components/NavHead";
import Footer from "../components/Footer";

const PaymentPage = () => {

  const userName = localStorage.getItem("userName");
  const userEmail = localStorage.getItem("useremail");
 
  const premium=localStorage.getItem("premium")
  const navigate = useNavigate();
  const{buyPolicyId}=useParams();
  const token = localStorage.getItem("token");
    const createOrder = async () => {
      return await fetch(`http://localhost:8080/payment/${premium}/${buyPolicyId}`, {
        mode: "no-cors",
        method: "GET",
       
      });
    };
    console.log(premium)
    const handlePayment = async () => {
      const order = await createOrder();
     
      const options = {
        key: "rzp_test_b8BMyjwFCfqQLL",
        amount: premium * 100,
        currency: "INR",
        name: userName,
        description: "Test Transaction",
        image: "https://example.com/your_logo",
        order_id: order,
        handler: function (response) {
          alert(response.razorpay_payment_id);
          // alert(response.razorpay_order_id);
          // alert(response.razorpay_signature);
        },
      
        prefill: {
          name: userName,
          email: userEmail,
          contact: '',
        },
        notes: {
          address: "ABC, Delhi",
        },
        theme: {
          color: "#3399cc",
        },
      };
      localStorage.setItem("paymentid",order);
      const rzp1 = new window.Razorpay(options);

      rzp1.on("payment.failed", function (response) {
        alert(response.error.code);
        alert(response.error.description);
      });
      rzp1.on("payment.success",navigate("/BajajAllianz/HomePage"))
      rzp1.open();
    };
    handlePayment();
 

  return <div>
  <NavHead/>
  
  
  </div>;
};

export default PaymentPage;
