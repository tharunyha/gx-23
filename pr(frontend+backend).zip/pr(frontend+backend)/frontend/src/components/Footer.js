import React from "react";
import { Container, Row, Col } from "react-bootstrap";

const Footer = () => {
  return (
    <footer >
    <p><span>©</span> 2024 BajajAllianz. All Rights Reserved</p>
    </footer>
  );
};

export default Footer;
