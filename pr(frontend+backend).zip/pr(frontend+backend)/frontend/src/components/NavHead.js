import React from 'react'
import '../assets/css/nav1.css'
import { Whatsapp } from 'react-bootstrap-icons';
import { Button, Dropdown,NavDropdown,Nav } from 'react-bootstrap';
import Image from "react-bootstrap/Image"; 
import logo from '../assets/img/bjjj.png'
import { Link,useNavigate } from 'react-router-dom'
import { FaRegUser } from 'react-icons/fa';

export const NavHead=() =>{
  const isLoggedIn=localStorage.getItem('isLoggedIn')==='true';
  const userName=localStorage.getItem('userName');
  const userRole=localStorage.getItem('role')
  const navigate=useNavigate();

  const handleSignOut=()=>{
   
    const isLoggedIn=localStorage.getItem('isLoggedIn')==='false';
    localStorage.clear();
    navigate('/BajajAllianz/HomePage')
  }
  return (
    <div>
       <div>
    <nav class="navbar navbar-expand-lg navbar-light m-0 p-0  w-100">
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav" >
        <a class="nav-item nav-link px-3 fs-6"  href='/BajajAllianz/CustomerService'>Support</a>
        <a class="nav-item nav-link px-3 fs-6">About Us </a>
        <a class="nav-item nav-link px-3 fs-6" >Awards</a>
        <a class="nav-item nav-link px-3 fs-6" >Careers</a>
        <a class="nav-item nav-link px-3 fs-6">Become an Agent</a>
        <a class="nav-item nav-link  fs-6 "><Button  variant='warning'  style={{fontSize:"xx-small", borderRadius:'45px'}}>Update KYC</Button></a>
        <a class="nav-item nav-link px-2 fs-6">Respect Senior Care Rider: 9152007550 (Missed call) </a>
        <a class="nav-item nav-link px-2 fs-6" >Sales: 1800-209-0144</a>
        <a class="nav-item nav-link px-2 fs-6 " ><Whatsapp color='green'/> Service Chat: +91 75072 45858</a>
      </div>
    </div>
  </nav>
  <nav class="navbar navbar-light w-100 py-0" style={{backgroundColor:"#1e83c5", justifyContent:"flex-start"}}>
  <div class="container m-0"  style={{backgroundColor:"#1e83c5",display: "flex", flexWrap:"inherit",align: "center",
  justifyContent:" flex-start", width: "80%"}}>
    <a class="navbar-brand  d-flex align-items-center " href="#">
    <Link to={'/BajajAllianz/HomePage'}><Image src={logo} alt="" width="min-content" height="fit-content" class="px-3 pt-2" /></Link></a>
    <Link to={'/BajajAllianz/AllPolicy'} style={{textDecorationLine:"none"}} ><a class="nav-item nav-link px-3"style={{color:"white"}}>Insure</a></Link>
    <Link to={'/BajajAllianz/Renew'} style={{textDecorationLine:"none"}} ><a class="nav-item nav-link px-3"style={{color:"white"}}>Renew</a></Link>
    <Link to={'/BajajAllianz/Claim'} style={{textDecorationLine:"none"}}><a class="nav-item nav-link px-3"style={{color:"white"}}>Claim</a></Link>
    <Link to={'/BajajAllianz/Pay Premium'}style={{textDecorationLine:"none"}} ><a class="nav-item nav-link px-3 py-1"style={{color:"white"}}>Pay Premium</a></Link>
    <a class="nav-item nav-link px-3"style={{color:"white"}}>Government Scheme</a>
    {isLoggedIn && userRole === '[ADMIN]' ?   <Link to={'/BajajAllianz/ViewPolicy'} style={{textDecorationLine:"none"}}><a class="nav-item nav-link px-3"style={{color:"white"}}>Policy</a></Link> : null }
    
     </div>
     
   
      <div>
      {isLoggedIn ? (
        <div>
          <Link to={`/BajajAllianz/UserProfile`}>
            <Button className="UserProfile" variant="warning" style={{ borderRadius: '50px', marginRight: '15px' }}>
             <FaRegUser/>
            </Button>
          </Link>
          <Button className="Logout" variant="warning" style={{ borderRadius: '50px', marginLeft: '15px' }} onClick={handleSignOut}>
            Logout
          </Button>
        </div>
      ) : (
        <div>
          <Link to={`/BajajAllianz/Register`}>
            <Button className="Register" variant="warning" style={{ borderRadius: '50px', marginRight: '15px' }}>
              Register
            </Button>
          </Link>
          <Link to={`/BajajAllianz/Login`}>
            <Button className="SignIn" variant="warning" style={{ borderRadius: '50px', marginLeft: '15px' }}>
              SignIn
            </Button>
          </Link>
        </div>
      )}

</div>
</nav>
</div>


   </div>
    
    
  );
}