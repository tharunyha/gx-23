import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { Form, Button, Container, Row, Col } from "react-bootstrap";
import { NavHead } from "../components/NavHead";
import Footer from "../components/Footer";

const ClaimForm = () => {
  const { policyId } = useParams();
  const [claimType, setClaimType] = useState("");
  const [claimAmount, setClaimAmount] = useState(0);
  const [detail1, setDetails1] = useState("");
  const [detail2, setDetails2] = useState("");
  const [detail3, setDetails3] = useState("");
  const [buyPolicy, setpolicyId] = useState(policyId);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const claimData = {
      claimAmount,
      claimDetails: [detail1, detail2, detail3],
      buyPolicy: {
        buyPolicyId: policyId,
      },
      claimType,
    };

    try {
      const response = await axios.post(`http://localhost:8080/Claim`, claimData);
      alert("Claim Request Initiated ")
       navigate("/BajajAllianz/HomePage");
    } catch (error) {
      alert("Error submitting form", error);
      console.log(error);
    }

    setClaimType("");
    setClaimAmount(0);
    setDetails1("");
    setDetails2("");
    setDetails3("");
    setpolicyId(policyId);
  };

  return (
    <div>
    <NavHead />
    <Container className="mt-3">
     
      <Row className="justify-content-md-center">
        <Col md={6}>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formPolicyId">
              <Form.Label>Policy Id:</Form.Label>
              <Form.Control
                type="text"
                value={buyPolicy}
                placeholder={policyId}
                onChange={(e) => setpolicyId(e.target.value)}
              />
            </Form.Group>

            <Form.Group controlId="formClaimType">
              <Form.Label>Claim Type:</Form.Label>
              <Form.Select value={claimType} onChange={(e) => setClaimType(e.target.value)}>
                <option>Select</option>
                <option value="Minor">Minor</option>
                <option value="Major">Major</option>
              </Form.Select>
            </Form.Group>

            <Form.Group controlId="formClaimAmount">
              <Form.Label>Claim Amount:</Form.Label>
              <Form.Control
                type="text"
                value={claimAmount}
                onChange={(e) => setClaimAmount(parseFloat(e.target.value))}
              />
            </Form.Group>

            <Form.Group controlId="formClaimReason">
              <Form.Label>Claim Reason:</Form.Label>
              <Form.Control
                type="text"
                value={detail1}
                onChange={(e) => setDetails1(e.target.value)}
              />
            </Form.Group>

            <Form.Group controlId="formHospitalized">
              <Form.Label>Hospitalized:</Form.Label>
              <Form.Select value={detail2} onChange={(e) => setDetails2(e.target.value)}>
                <option>Select</option>
                <option value={"Yes"}>Yes</option>
                <option value={"No"}>No</option>
              </Form.Select>
            </Form.Group>

            <Form.Group controlId="formDays">
              <Form.Label>How many days?</Form.Label>
              <Form.Control
                type="text"
                value={detail3}
                onChange={(e) => setDetails3(e.target.value)}
              />
            </Form.Group>

            <Button variant="primary" type="submit">
              Submit
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
    <Footer/>
    </div>
  );
};

export default ClaimForm;

