import React from "react";
import { useState } from "react";
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBInput,
} from "mdb-react-ui-kit";
import axios from "axios";

import { Eye, EyeSlash } from "react-bootstrap-icons";
import { Button } from "react-bootstrap";
import { NavHead } from "../components/NavHead";
import { Link, useNavigate } from "react-router-dom";
import paymentimg from "../assets/img/Payment.webp";
import Footer from "../components/Footer";

const PayPremium = () => {
  const [buyPolicyId, setPolicyNumber] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate=useNavigate();
  const token  = localStorage.getItem("token")
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(
        `http://localhost:8080/MyPolicy/${buyPolicyId}/${password}`,
        {
          method: "GET",
          
        }
      );

      const data = await response.json();

      if (response.ok) {
        alert("valid credentials");
        navigate(`/BajajAllianz/Pay/${buyPolicyId}`)
      } else {
        alert(setError(data.message)); // Display error message from the backend
      }
    } catch (error) {
      if (error.response) {
        setError(error.response.data);
        console.log(error.response.data);
      } else if (error.request) {
        setError("Network Error");
      } else {
        setError("An Unexpected Error Occurred");
      }
    }
  };
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div>
      <NavHead />
      <div>
        <h5
          className="mt-3 p-3"
          style={{ fontSize: "xx-large", color: "#0071bb" }}
        >
          PAY PREMIUM
        </h5>
        <div>
        <MDBContainer fluid>
        <MDBRow>
          <MDBCol sm="6">
            <div className="d-flex flex-column justify-content-center h-custom-2 w-75 pt-5 mt-5">
              <MDBInput
                wrapperClass="mb-4 mx-5 w-100"
                type="password"
                placeholder="Enter Policy Number"
                value={buyPolicyId}
                onChange={(e) => setPolicyNumber(e.target.value)}
                size="lg"
              />
              <div style={{ display: "flex", marginLeft: "50px" }}>
                <MDBInput
                  style={{ width: "398px" }}
                  wrapperClass="mb-4 "
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter Password"
                  size="lg"
                >
                  {" "}
                </MDBInput>

                <Button
                  className="mb-4 "
                  variant="outline-secondary"
                  style={{
                    width: "min-content",
                    borderRadius: "0px",
                    backgroundColor: "#e0f7bc",
                    color: "black",
                    marginRight: "0px",
                    marginLeft: "0px",
                  }}
                  onClick={togglePasswordVisibility}
                >
                  {showPassword ? <Eye /> : <EyeSlash />}
                </Button>
              </div>
              <div className="small  ms-5" style={{textAlign:"center"}}>{error && <p>{error}</p>}</div>
                  <Button
                    className="mb-4 px-5 mx-5 w-100"
                    variant="info"
                    onClick={handleSubmit}
                    size="lg"
                  >
                    Pay Premium
                  </Button>
                </div>
              </MDBCol>

              <MDBCol sm="6" className="d-none d-sm-block px-0">
                <img
                  src={paymentimg}
                  alt="Login image"
                  className="w-75 h-75 "
                  style={{
                    objectFit: "contain",
                    objectPosition: "left",
                    marginTop: "55px",
                  }}
                />
              </MDBCol>
            </MDBRow>
          </MDBContainer>
          <Footer/>
        </div>
      </div>
    </div>
  );
};

export default PayPremium;
