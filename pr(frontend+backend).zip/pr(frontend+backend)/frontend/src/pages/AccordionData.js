import React, { useState } from 'react';
import { Accordion, Card, Button } from 'react-bootstrap';

export const CustomAccordion = ({ title, content }) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleAccordion = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div>
    <Card>
      <Card.Header>
        <Accordion.Toggle as={Button} variant="link" eventKey={title} onClick={toggleAccordion}>
          {title}
        </Accordion.Toggle>
      </Card.Header>
      <Accordion.Collapse eventKey={title}>
        <Card.Body>
          {title === 'User Info' && (
            <div>
              <p>Email: {content.email}</p>
              <p>Date of Birth: {content.dob}</p>
            </div>
          )}
          {title === 'My Policies' && (
            // Render policy-specific content here
            <pre>{JSON.stringify(content, null, 2)}</pre>
          )}
          {title === 'Claims' && (
            // Render claim-specific content here
            <pre>{JSON.stringify(content, null, 2)}</pre>
          )}
          {title === 'Payments' && (
            // Render payment-specific content here
            <pre>{JSON.stringify(content, null, 2)}</pre>
          )}
        </Card.Body>
      </Accordion.Collapse>
    </Card>
    </div>
  );
};

export default CustomAccordion;

