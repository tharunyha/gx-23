import React, { useState, useEffect } from "react";
import axios from "axios";
import CustomAccordion from "./AccordionData";
import { Accordion, Card, Container, Row, Col, Button } from "react-bootstrap";
import { useParams } from "react-router-dom";
import { NavHead } from "../components/NavHead";
import { MdEdit } from "react-icons/md";
import { MdDelete } from "react-icons/md";
import moment from "moment/moment";
import Modal from "react-bootstrap/Modal";
import Footer from "../components/Footer";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const UserProfile = () => {
  const [userInfo, setUserInfo] = useState({});
  const [myPolicies, setMyPolicies] = useState([]);
  const [claims, setClaims] = useState([]);
    const [error, setError] = useState("");
  const [payments, setPayments] = useState([]);
  const { userName } = useParams();
  const token = sessionStorage.getItem("token");
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  useEffect(() => {
    // Fetch user info
    viewUser();
  }, []);

  const viewUser = () => {
    axios
      .get("http://localhost:8080/userinfo", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        const { userId, userName, userEmail, userPhoneNumber, userRole, dob } =
          response.data;
        setUserInfo(response.data);
        if (response.status === 200) {
          localStorage.setItem("userName", userName);
          localStorage.setItem("useremail", userEmail);
          localStorage.setItem("userid", userId);
        } else {
          console.log("Error getting data");
        }

        // // Fetch my policies
        axios
          .get(`http://localhost:8080/MyPolicy/${userName}`)
          .then((response) => setMyPolicies(response.data));
        // // Fetch claims
      })
      .catch((error) => {
        console.log("profile error:", error);
      });
  };
  const userID = localStorage.getItem("userid");
  const startDate = new Date(myPolicies.policyStartDate);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    trigger,
  } = useForm();
  const navigate = useNavigate();
  const onSubmit = async (data) => {
    const isFormValid = await trigger();
    if (isFormValid) {
      try {
        const response = await axios.put(
          `http://localhost:8080/updateUser/${userID}`,
          data
        );
        alert("Account Updated Successfully!!!");
        setShow(false);
        window.location.reload();
      } catch (error) {
        if (error.response && error.response.data) {
          const errorMsg = error.response.data;
          setError(errorMsg)
        } else {
          alert("Network error. Please Try again!!!" + error);
        }
      }
    }
  };

  const phoneRegex = /^[0-9]{10}$/;

  const nameRegex = /^[^\s]{8,15}$/;
  return (
    <div>
      <NavHead />

      <div className="m-5">
        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey="0">
            <Accordion.Header>
              User Info{" "}
              <Button className="bg-info" onClick={handleShow}>
                <MdEdit />
              </Button>
            </Accordion.Header>
            <Accordion.Body>
              <div>
                <Container style={{ width: "50%" }}>
                  <Row>
                    <Col>User Name</Col>
                    <Col>{userInfo.userName}</Col>
                  </Row>
                  <Row>
                    <Col>User Email</Col>
                    <Col>{userInfo.userEmail}</Col>{" "}
                  </Row>
                  <Row>
                    <Col> User Phone Number </Col>{" "}
                    <Col> {userInfo.userPhoneNumber}</Col>
                  </Row>
                  <Row>
                    <Col> Date Of Birth</Col>
                    <Col> {moment(userInfo.dob).format("Do MMM YYYY")}</Col>
                  </Row>
                </Container>
              </div>
            </Accordion.Body>
          </Accordion.Item>
          <Accordion.Item eventKey="1">
            <Accordion.Header>My Policies</Accordion.Header>
            <Accordion.Body>
              <div>
                {myPolicies.map((policy) => (
                  <Card className="my-3" key={policy.buyPolicyId}>
                    <Container style={{ width: "50%" }}>
                      <Row>
                        <Col>Policy Number</Col>
                        <Col>{policy.buyPolicyId}</Col>
                      </Row>
                      <Row>
                        <Col>Policy Start Date</Col>
                        <Col>
                          {moment(policy.policyStartDate).format("Do MMM YYYY")}
                        </Col>{" "}
                      </Row>
                      <Row>
                        <Col> Policy End Date </Col>
                        <Col>
                          {" "}
                          {moment(policy.policyEndDate).format("Do MMM YYYY")}
                        </Col>
                      </Row>
                      <Row>
                        <Col> Coverage Amount</Col>
                        <Col> {policy.policyPremium.returnAmount}</Col>
                      </Row>
                      <Row>
                        <Col> Premium Amount</Col>
                        <Col> {policy.policyAmount}</Col>
                      </Row>
                    </Container>
                  </Card>
                ))}
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>

        <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title style={{ textAlign: "center" }}>
              UPDATE USER
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div>
              <form className="mt-5">
                <ul className="errors" style={{ listStyle: "none" }}>
                  {errors.userName && (
                    <li className="text-danger">{errors.userName.message}</li>
                  )}

                  {errors.dob && (
                    <li className="text-danger">{errors.dob.message}</li>
                  )}

                  {errors.phone && (
                    <li className="text-danger">{errors.phone.message}</li>
                  )}

                  {errors.email && (
                    <li className="text-danger">{errors.email.message}</li>
                  )}

                  {errors.password && (
                    <li className="text-danger">{errors.password.message}</li>
                  )}
                </ul>

                <div className="mb-3 w-100" style={{ textAlign: "start" }}>
                  <label htmlFor="userName" className="form-label">
                    User Name
                  </label>

                  <input
                    type="text"
                    className="form-control"
                    id="userName"
                    {...register("userName", {
                      pattern: {
                        value: nameRegex,
                        message:
                          "User name should contain 8-15 characters with no special characters ",
                      },
                    })}
                  />
                </div>

                <div className="mb-3" style={{ textAlign: "start" }}>
                  <label htmlFor="dob" className="form-label">
                    DOB
                  </label>

                  <input
                    type="date"
                    className="form-control"
                    id="dob"
                    {...register("dob", {})}
                  />
                </div>

                <div className="mb-3" style={{ textAlign: "start" }}>
                  <label htmlFor="phone" className="form-label">
                    Phone
                  </label>

                  <input
                    type="text"
                    className="form-control"
                    id="phone"
                    {...register("userPhoneNumber", {
                      pattern: {
                        value: phoneRegex,

                        message: "Enter a valid phone number",
                      },
                    })}
                  />
                </div>

                <div className="mb-3" style={{ textAlign: "start" }}>
                  <label htmlFor="email" className="form-label">
                    Email
                  </label>

                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    {...register("userEmail", {})}
                  />
                </div>

                <div className="mb-3" style={{ textAlign: "start" }}>
                  <label htmlFor="password" className="form-label">
                    Password
                  </label>

                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    {...register("password", {
                      minLength: {
                        value: 8,
                        message: "Password must be at least 8 characters",
                      },

                      pattern: {
                        value:
                          /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
                        message:
                          "Password must contain at least one uppercase, one lowercase letter, one number and one special character",
                      },
                    })}
                  />
                </div>
              </form>
              <div className="small  ms-5">{error && <p>{error}</p>}</div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="primary" onClick={handleSubmit(onSubmit)}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
      <Footer />
    </div>
  );
};

export default UserProfile;
