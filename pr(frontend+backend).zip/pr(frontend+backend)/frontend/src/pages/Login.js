import React from "react";
import { useState } from "react";
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBInput,
} from "mdb-react-ui-kit";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import { Eye, EyeSlash, Justify } from "react-bootstrap-icons";
import { Button } from "react-bootstrap";
import { NavHead } from "../components/NavHead";
import loginimg from "../assets/img/login.jpg";
import Footer from "../components/Footer";

const Login = () => {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");

  const [showPassword, setShowPassword] = useState(false);

  const [error, setError] = useState("");

  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!email || !password) {
      setError("Please provide both email and password.");
      return;
    }

    try {
      const logindata = {
        email: email,
        password: password,
      };

      const response = await axios.post(
        `http://localhost:8080/auth/generateToken`,
        logindata
      );
      const data = response.data;
      console.log(data);
      const resp = await axios.get("http://localhost:8080/user", {
        headers: {
          Authorization: `Bearer ${data}`,
        },
      });
      const datas = resp.data;
      console.log(datas);

      localStorage.setItem("role", datas);

      if (response.status === 200) {
        localStorage.setItem("isLoggedIn", true);
        sessionStorage.setItem("token", data);
        setIsLoggedIn(true);
        navigate("/BajajAllianz/HomePage");
      } else {
        alert(setError("Incorrect credentials"));
        navigate("/BajajAllianz/Login");
      }
    } catch (error) {
      if (error.response) {
        setError(error.response.data);
      } else if (error.request) {
        setError("Network Error");
      } else {
        setError("An Unexpected Error Occurred");
      }
    }
  };

  return (
    <div>
      <NavHead setIsLoggedIn={setIsLoggedIn} />
      <MDBContainer fluid>
        <MDBRow>
          <MDBCol sm="6">
            <div className="d-flex flex-column justify-content-center h-custom-2 w-75 pt-5 mt-5">
              <h3
                className="fw-normal mb-3 ps-5 pb-3"
                style={{ letterSpacing: "1px" }}
              >
                LOGIN
              </h3>

              <MDBInput
                wrapperClass="mb-4 mx-5 w-100"
                type="email"
                placeholder="Enter Email"
                value={email}
                onChange={handleEmailChange}
                size="lg"
              />
              <div style={{ display: "flex", marginLeft: "50px" }}>
                <MDBInput
                  style={{ width: "398px" }}
                  wrapperClass="mb-4 "
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={handlePasswordChange}
                  placeholder="Enter Password"
                  size="lg"
                ></MDBInput>

                <Button
                  className="mb-4 "
                  variant="outline-secondary"
                  style={{
                    width: "min-content",
                    borderRadius: "0px",
                    backgroundColor: "#e0f7bc",
                    color: "black",
                    marginRight: "0px",
                    marginLeft: "0px",
                  }}
                  onClick={togglePasswordVisibility}
                >
                  {showPassword ? <Eye /> : <EyeSlash />}
                </Button>
              </div>
              <div className="small  ms-5">{error && <p>{error}</p>}</div>

              <Button
                className="mb-4 px-5 mx-5 w-100"
                variant="info"
                size="lg"
                style={{ textDecoration: "none", color: "black" }}
                onClick={handleSubmit}
              >
                Login
              </Button>
              <p className="small  ms-5">
                <a class="text-muted" href="#!">
                  <Link to={`/BajajAllianz/ForgotPassword/${email}`}>
                    Forgot Password
                  </Link>
                </a>
              </p>

              <p className="ms-5">
                Don't have an account?{" "}
                <Link to={"/BajajAllianz/Register"}>Register here</Link>
              </p>
            </div>
          </MDBCol>

          <MDBCol sm="6" className="d-none d-sm-block px-0">
            <img
              src={loginimg}
              alt="Login image"
              className="w-100  "
              style={{
                objectFit: "cover",
                objectPosition: "left",
                marginTop: "100px",
              }}
            />
          </MDBCol>
        </MDBRow>
      </MDBContainer>
      <Footer />
    </div>
  );
};

export default Login;
