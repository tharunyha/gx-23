import React from "react";

import { useForm } from "react-hook-form";
import axios from "axios";
import { NavHead } from "../components/NavHead";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Footer from "../components/Footer";


const RegistrationForm = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    trigger,
  } = useForm();
  const navigate= useNavigate();
  const token=localStorage.getItem("token");
  const onSubmit = async (data) => {
    const isFormValid = await trigger();
    if (isFormValid) {
      try {
        const response = await axios.post(
          "http://localhost:8080/Register",
          data,
        );
        toast.success("Account Created Successfully!!!");
        navigate('/BajajAllianz/Login');
      } catch (error) {
      

        if (error.response && error.response.data) {
          const errorMsg = error.response.data;
          console.log(errorMsg);
        } else {
          alert("Network error. Please Try again!!!" + error);
        }
      }
    }
  };

  const phoneRegex = /^[0-9]{10}$/;

  const nameRegex = /^[^\s]{8,15}$/;

  return (
    <div>
      <NavHead />

      <div className="container p-2  w-50">
        <h3>Create Account</h3>

        <form className="mt-5" onSubmit={handleSubmit(onSubmit)}>
          <ul className="errors" style={{listStyle:"none"}}>
            {errors.userName && (
              <li className="text-danger">{errors.userName.message}</li>
            )}

            {errors.dob && (
              <li className="text-danger">{errors.dob.message}</li>
            )}

            {errors.phone && (
              <li className="text-danger">{errors.phone.message}</li>
            )}

            {errors.email && (
              <li className="text-danger">{errors.email.message}</li>
            )}

            {errors.password && (
              <li className="text-danger">{errors.password.message}</li>
            )}
          </ul>

          <div className="mb-3 w-100" style={{textAlign:"start"}}>
            <label htmlFor="userName"  className="form-label">
              User Name
            </label>

            <input
              type="text"
              className="form-control"
              id="userName"
              {...register("userName", {
                required: "User name is required",

                pattern: {
                  value: nameRegex,
                  message: "User name should contain 8-15 characters with no special characters ",
                },
              })}
            />
          </div>

          <div className="mb-3"style={{textAlign:"start"}}>
            <label htmlFor="dob" className="form-label">
              DOB
            </label>

            <input
              type="date"
              className="form-control"

              id="dob"
              {...register("dob", {
                required: "Date of Birth is required",
              })}
            />
          </div>

          <div className="mb-3"style={{textAlign:"start"}}>
            <label htmlFor="phone" className="form-label">
              Phone
            </label>

            <input
              type="text"
              className="form-control"
              id="phone"
              {...register("userPhoneNumber", {
                required: "Phone number is required",

                pattern: {
                  value: phoneRegex,

                  message: "Enter a valid phone number",
                },
              })}
            />
          </div>

          <div className="mb-3"style={{textAlign:"start"}}>
            <label htmlFor="email" className="form-label">
              Email
            </label>

            <input
              type="email"
              className="form-control"
              id="email"
              {...register("userEmail", {
                required: "Email is required",
              })}
            />
          </div>

          <div className="mb-3"style={{textAlign:"start"}}>
            <label htmlFor="password" className="form-label">
              Password
            </label>

            <input
              type="password"
              className="form-control"
              id="password"
              {...register("password", {
                required: "Password is required",

                minLength: {
                  value: 8,
                  message: "Password must be at least 8 characters",
                },

                pattern: {
                  value:
                    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
                  message:
                    "Password must contain at least one uppercase, one lowercase letter, one number and one special character",
                },
              })}
            />
          </div>

          <button type="submit" className="btn btn-primary">
            CREATE
          </button>
        </form>
      </div>
      <Footer/>
    </div>
  );
};

export default RegistrationForm;
