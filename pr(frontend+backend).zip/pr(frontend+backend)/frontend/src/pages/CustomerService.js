import React from "react";
import { NavHead } from "../components/NavHead";
import { Card, Button } from "react-bootstrap";
import c1 from "../assets/img/card1.webp";
import c2 from "../assets/img/card2.svg";
import c3 from "../assets/img/card3.svg";
import c5 from "../assets/img/card5.svg";
import c6 from "../assets/img/card6.svg";
import "../assets/css/service.css";
import Footer from "../components/Footer";

export const CustomerService = () => {
  return (
    <div>
      <NavHead />
      <div className="main">
        <div className="head">
          <h1 className="m-5" style={{ color: "#ff9b41" }}>
            Customer Service
          </h1>
        </div>
        <div
          className="m-3"
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "25px",
            justifyContent: "center",
          }}
        >
          <Card style={{ width: "22rem" }}>
            <Card.Img
              style={{
                width: "50%",
                alignSelf: "center",
              }}
              variant="top"
              src={c1}
            />
            <Card.Body>
              <Card.Title style={{ fontSize: "medium", fontWeight: "normal" }}>
                To know all the updates on your policy and claims, please scan
                and download our
              </Card.Title>
              <Card.Text style={{color:'#0072bc',fontSize: "medium"}}>Caringly Yours App</Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
          <Card style={{ width: "22rem" }}>
            <Card.Img
              style={{
                width: "50%",
                alignSelf: "center",
              }}
              variant="top"
              src={c2}
            />
            <Card.Body>
              <Card.Title style={{ fontSize: "medium", fontWeight: "normal" }}>
                Whatsapp Service
              </Card.Title>
              <Card.Text style={{color:'#0072bc',fontSize: "medium"}}>Say ‘Hi’ on Whatsapp +91 75072 45858</Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
          <Card style={{ width: "22rem" }}>
            <Card.Img
              style={{
                width: "50%",
                alignSelf: "center",
              }}
              variant="top"
              src={c3}
            />
            <Card.Body>
              <Card.Title style={{ fontSize: "medium", fontWeight: "normal" }}>
                COVID-19 Helpline Number
              </Card.Title>
              <Card.Text style={{color:'#0072bc',fontSize: "medium"}}>
              Our policyholders can call us at 1800-210-1030
              </Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
          <Card style={{ width: "22rem" }}>
            <Card.Img
              style={{
                width: "50%",
                alignSelf: "center",
              }}
              variant="top"
              src={c3}
            />
            <Card.Body>
              <Card.Title style={{ fontSize: "medium", fontWeight: "normal" }}>
                Missed Call Facility
              </Card.Title>
              <Card.Text style={{color:'#0072bc',fontSize: "medium"}}>
              Missed Call - 80809 45060
              Short code - SMS ( WORRY ) to 575758
              </Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
          <Card style={{ width: "22rem" }}>
            <Card.Img
              style={{
                width: "50%",
                alignSelf: "center",
              }}
              variant="top"
              src={c5}
            />
            <Card.Body>
              <Card.Title style={{ fontSize: "medium", fontWeight: "normal" }}>
                Email us on
              </Card.Title>
              <Card.Text style={{color:'#0072bc',fontSize: "medium"}}>
              bagichelp@bajajallianz.co.in
              </Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
          <Card style={{ width: "22rem" }}>
            <Card.Img
              style={{
                width: "50%",
                alignSelf: "center",
              }}
              variant="top"
              src={c6}
            />
            <Card.Body>
              <Card.Title style={{ fontSize: "medium", fontWeight: "normal" }}>
                For 24x7 Roadside Assistance
              </Card.Title>
              <Card.Text style={{color:'#0072bc',fontSize: "medium"}}>
              1800-103-5858
              </Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
          <Card style={{ width: "22rem" }}>
            <Card.Img
              style={{
                width: "50%",
                alignSelf: "center",
              }}
              variant="top"
              src={c3}
            />
            <Card.Body>
              <Card.Title style={{ fontSize: "medium", fontWeight: "normal" }}>
                Toll free number for intermediaries
              </Card.Title>
              <Card.Text style={{color:'#0072bc',fontSize: "medium"}}>
              1800-209-7073
              </Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
        </div>
      </div>
      <Footer/>
    </div>
  );
};
