import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
import { NavHead } from '../components/NavHead';
import Footer from '../components/Footer';

const ForgotPasswordForm = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError('Passwords do not match');
    } else {
      // Handle password reset logic here
      setError('');
      // Reset password and confirm password fields
      setPassword('');
      setConfirmPassword('');
    }
  };

  return (
    <div>
    <NavHead/>
    <div className='w-70 mt-3 mx-5'>
    <Form className='mt-3' onSubmit={handleSubmit}>
      <Form.Group controlId="password">
        <Form.Label>Password</Form.Label>
        <Form.Control
          type="password"
          placeholder="Enter password"
          value={password}
          onChange={handlePasswordChange}
        />
      </Form.Group>

      <Form.Group controlId="confirmPassword">
        <Form.Label>Confirm Password</Form.Label>
        <Form.Control
          type="password"
          placeholder="Confirm password"
          value={confirmPassword}
          onChange={handleConfirmPasswordChange}
        />
      </Form.Group>

      {error && <Alert variant="danger">{error}</Alert>}

      <Button variant="primary" type="submit" className='mt-3'>
        Reset Password
      </Button>
    </Form>
    </div>
    <Footer/>
    </div>
  );
};

export default ForgotPasswordForm;
