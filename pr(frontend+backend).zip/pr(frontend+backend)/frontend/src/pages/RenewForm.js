import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";
import { NavHead } from "../components/NavHead";
import { useNavigate, useParams } from "react-router-dom";
import { PremiumCards } from "../buypolicy/PremiumCards";
import { AccordionHeader, Button, Form, FormControl } from "react-bootstrap";


const RenewForm = () => {
  const { buyPolicyId } = useParams();
  const[policy,setPolicy]=useState({});
  const [payAmount, setPayAmount] = useState();
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [returnAmounts, setReturnAmounts] = useState([]);
  const [selectedReturnAmount, setSelectedReturnAmount] = useState(null);
  const [selectedPremium, setSelectedPremium] = useState([]);
  const [premiums, setPremiums] = useState();
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    viewPremiums();
  }, []);

  const viewPremiums = async () => {
    try {
      const response = await axios.get("http://localhost:8080/PolicyPremium");
      const data = response.data;
      setReturnAmounts(data);
    } catch (error) {
      console.error("Error fetching return amounts", error);
    }
  };

  const handleReturnAmountChange = async (event) => {
    const selectedAmount = event.target.value;
    setSelectedReturnAmount(selectedAmount);

    try {
      const response = await axios.get(
        `http://localhost:8080/PolicyPremium/${selectedAmount}`
      );
      console.log(response.data);
      setSelectedPremium(response.data);
    } catch (error) {
      console.error("Error fetching return amounts", error);
    }
  };

const token = localStorage.getItem("token")
  const handleRenew = async () => {
    const renewData = {
      policyEndDate:startDate,
      policyStartDate:endDate,
      policyAmount:payAmount,
    };
    try {
    
      const response = await axios.put(`http://localhost:8080/RenewPolicy/${buyPolicyId}/${selectedPremium.policyPremiumId}`,renewData,{
        
      });

      if (response.status===202) {
        alert("Policy renewed successfully!");
        navigate('/BajajAllianz/HomePage')
      } else {
        // Handle error
        console.error("Failed to renew policy");
      }
    } catch (error) {
      if (error.response) {
        setError(error.response.data);
        console.log(error.response.data);
      } else if (error.request) {
        setError("Network Error");
      } else {
        setError("An Unexpected Error Occurred");
      }
    }
  };

  return (
    <div className="renew-form">
      <NavHead />
      <div className="m-3">
      
      {policy && (
        <div>
          <p>Policy ID: {buyPolicyId}</p>
          <label>
            Start Date:
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
          </label>
          <br/>
          <br/>
          <label>
            End Date:
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
          </label>
          <div>
          <Form.Label>Select Return Amount:</Form.Label>
          <select
            value={selectedReturnAmount}
            onChange={handleReturnAmountChange}
          >
            <option value="">Select...</option>
            {returnAmounts.map((premium) => (
              <option key={premium} value={premium.returnAmount}>
                {premium.returnAmount}
              </option>
            ))}
          </select>

          <div
            style={{
              display: "flex",
              alignContent: "center",
              justifyContent: "center",
            }}
          >
            {selectedReturnAmount && (
              <div>
                <PremiumCards
                  selectedPremium={selectedPremium.durationOne}
                  duration={"1 YEAR"}
                  value={payAmount}
                  onClick={() => {
                    setPremiums(selectedPremium.durationOne);
                  }}
                />
              </div>
            )}
            {selectedReturnAmount && (
              <div>
                <PremiumCards
                  selectedPremium={selectedPremium.durationTwo}
                  duration={"2 YEAR"}
                  value={selectedPremium.durationTwo}
                  onClick={() => {
                    setPremiums(selectedPremium.durationTwo);
                  }}
                />
              </div>
            )}
            {selectedReturnAmount && (
              <div>
                <PremiumCards
                  selectedPremium={selectedPremium.durationThree}
                  duration={"3 YEAR"}
                  value={selectedPremium.durationThree}
                  onClick={() => {
                    setPremiums(selectedPremium.durationThree);
                  }}
                />
              </div>
            )}
          </div>
          </div>
   
      <div className="small  ms-5" style={{textAlign:"center"}}>{error && <p>{error}</p>}</div>
          <button onClick={handleRenew}>Renew Policy</button>
        </div>
      )}
      </div>
    </div>
  );
};


export default RenewForm;
