package com.demo.entity.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.Employee;
import com.demo.entity.repo.AccountRepo;
import com.demo.entity.repo.EmployeeRepo;
import com.demo.entity.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepo emprepo;
	
	@Override
	public Employee createEmployee(Employee employee) {
		Employee emps= emprepo.save(employee);
		return emps;
	}

	@Override
	public Employee getEmployeeById(Long emp_id) {
		return emprepo.findById(emp_id).orElse(null);
		
	}

	@Override
	public void deleteEmployee(Long emp_id) {
		 emprepo.deleteById(emp_id);
		
	}

}
