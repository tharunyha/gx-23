package com.demo.entity.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.Course;
import com.demo.entity.repo.CourseRepo;
import com.demo.entity.service.CourseService;

@Service
public class CourseServiceImpl implements CourseService {
	
	
	@Autowired
	CourseRepo courserepo;
	
	@Override
	public Course getCourseById(Long course_id) {
		// TODO Auto-generated method stub
		return courserepo.findById(course_id).orElse(null);
	}

	@Override
	public void deleteCourse(Long course_id) {
		courserepo.deleteById(course_id);
		
	}

	@Override
	public Course createCourse(Course course) {
		return courserepo.save(course);
	}

}
