package com.demo.entity.service;

import com.demo.entity.Course;


public interface CourseService {

	Course getCourseById(Long course_id);
	void deleteCourse(Long course_id);
	Course createCourse(Course course);
}
