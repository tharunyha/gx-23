package com.bajaj.controller;

import java.util.Optional;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.modal.PayPremium;
import com.bajaj.modal.PurchasePolicy;
import com.bajaj.repo.BuyPolicyRepo;
import com.bajaj.repo.PayPremiumRepo;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@RestController
public class PaymentIntegrationController {
    @Value("${rzp_key_id}")
    private String keyId;

    @Value("${rzp_key_secret}")
    private String secret;
    
    @Autowired
    PayPremiumRepo payPremiumRepo;
    @Autowired
    BuyPolicyRepo buyPolicyRepo;
    
    @GetMapping("/payment/{amount}/{id}")
    public String payment(@PathVariable String amount,@PathVariable Integer id) throws RazorpayException {
        
        RazorpayClient razorpayClient = new RazorpayClient(keyId, secret);
        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", amount);
        orderRequest.put("currency", "INR");
        orderRequest.put("receipt", "order_receipt_11");

        Order order = razorpayClient.orders.create(orderRequest);
        
        String orderId = order.get("id");
        String mode=order.get("payment_method");
        System.out.println(orderId);
        System.out.println(mode);
        
        Optional<PurchasePolicy> policy = buyPolicyRepo.findById(id);
        PayPremium payPremium = new PayPremium();
        payPremium.setPaymentId(orderId);
        payPremium.setPaymentStatus("Successful");
        payPremium.setPaymentType("RazorPay");
        payPremium.setBuyPolicy(policy.get());
        payPremiumRepo.save(payPremium);

        
        return "Payment Done";
    }
}