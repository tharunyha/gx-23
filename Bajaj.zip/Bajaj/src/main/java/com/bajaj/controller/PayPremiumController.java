package com.bajaj.controller;

import java.util.Optional;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.exception.PaymentException;
import com.bajaj.modal.PayPremium;
import com.bajaj.service.PremiumPaymentService;

@RestController
@CrossOrigin("*")
public class PayPremiumController {
	@Autowired
	PremiumPaymentService paymentService;
	
	@PostMapping("/PayPremium")
	public ResponseEntity<PayPremium >newPayment(@RequestBody PayPremium  payment){
		PayPremium  payments = paymentService.payPremium(payment);
		return new ResponseEntity<>(payments,HttpStatus.CREATED);
	}
	
	@GetMapping("/PremiumPayment/{paymentId}")
	public ResponseEntity<?>getPayment(@PathVariable String paymentId){
		try {
			Optional<PayPremium> payment = paymentService.getPremiumbyId(paymentId);
			return new ResponseEntity<>(payment,HttpStatus.OK);	
		} catch (PaymentException e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);	
		}
		
	}
	@GetMapping("/PremiumHistory/{paymentId}")
	public ResponseEntity<?>getAllPayment(@PathVariable Integer paymentId){
		try {
			List<PayPremium> payment = paymentService.getAllById(paymentId);
			return new ResponseEntity<>(payment,HttpStatus.OK);	
		} catch (PaymentException e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);	
		}
		
	}
}
