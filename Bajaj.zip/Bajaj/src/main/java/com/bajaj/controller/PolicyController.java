package com.bajaj.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.exception.PolicyCategoryNotFound;
import com.bajaj.exception.PolicyNotFound;
import com.bajaj.modal.Policy;
import com.bajaj.modal.PolicyPremium;
import com.bajaj.service.PolicyService;

@RestController
@CrossOrigin("*")
public class PolicyController {

	@Autowired
	PolicyService policyService;

	@PostMapping("/NewPolicy")
	public ResponseEntity<Policy> createPolicy(@RequestBody Policy policy) {
		Policy newPolicy = policyService.addUpdatePolicy(policy);
		return new ResponseEntity<>(newPolicy, HttpStatus.CREATED);
	}

	@GetMapping("/AllPolicies")
	public ResponseEntity<?> getAllPolicies() {
		try {
			List<Policy> policies = policyService.getallPolicies();
			return new ResponseEntity<>(policies, HttpStatus.OK);
		} catch (PolicyNotFound e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/PoliciesByName/{policyName}")
	public ResponseEntity<?> getPolicybyname(@PathVariable String policyName) {
		try {
			Optional<Policy> policy = policyService.getByName(policyName);
			return new ResponseEntity<>(policy, HttpStatus.OK);
		} catch (PolicyNotFound e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/PoliciesByCategory/{category}")
	public ResponseEntity<?> getbyCategory(@PathVariable String category) {
		try {
			Optional<List<Policy>> policy = policyService.getByCategory(category);
			return new ResponseEntity<>(policy, HttpStatus.OK);
		} catch (PolicyCategoryNotFound e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/updatePolicy/{policyname}")
	public ResponseEntity<?> updatePolicy(@PathVariable String policyName, @RequestBody Policy policy) {
		try {
			Optional<Policy> oldPolicy = policyService.getByName(policyName);
			Policy policyEntity = oldPolicy.get();
			if (oldPolicy != null) {
				policyEntity.setPolicyName(policyName);
				policyEntity.setPolicyCategory(policy.getPolicyCategory());
				policyEntity.setPolicyName(policy.getPolicyName());
				policyEntity.setPolicyStatus(true);
			}
			Policy updatedPolicy = policyService.addUpdatePolicy(policyEntity);
			return new ResponseEntity<>(updatedPolicy, HttpStatus.ACCEPTED);
		} catch (PolicyNotFound e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}

	@DeleteMapping("/deletePolicy/{id}")
	public ResponseEntity<String> cancelPolicy(@PathVariable Integer id) {
		try {
			String deletePolicy = policyService.deletePolicy(id);
			return new ResponseEntity<>(deletePolicy, HttpStatus.OK);
		} catch (PolicyNotFound e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/Policy/{policyId}/premiumDetails")
	public ResponseEntity<?> getPolicyDetails(@PathVariable Integer policyId) {
		try {
			List<PolicyPremium> premiumDetails = policyService.policyPremiumDetail(policyId);
			return new ResponseEntity<>(premiumDetails, HttpStatus.OK);
		} catch (PolicyNotFound e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
}
