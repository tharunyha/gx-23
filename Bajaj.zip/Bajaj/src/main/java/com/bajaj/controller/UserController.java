package com.bajaj.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.exception.UserEmailException;
import com.bajaj.exception.UserException;
import com.bajaj.exception.UserPhoneException;
import com.bajaj.modal.Users;
import com.bajaj.service.UserService;
import com.bajaj.utils.ExceptionUtils;

@RestController
@CrossOrigin("*")
public class UserController {
	@Autowired
	UserService userService;

	@PostMapping("/Register")
	public ResponseEntity<?> createUser(@RequestBody Users user) {
		try {

			user.setUserStatus(true);
			userService.createUser(user);
			String response = "Successfully Registered\n" + "Username: " + user.getUserName() + "\n" + "User email: "
					+ user.getUserEmail() + "\n" + "Phone number: " + user.getUserPhoneNumber() + "\n"
					+ "Date of Birth: " + user.getDob();
			return new ResponseEntity<>(response, HttpStatus.CREATED);
		} catch (UserException | UserEmailException | UserPhoneException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}

	@GetMapping("/Users")
	public ResponseEntity<List<Users>> getAllUsers() {
		List<Users> user = userService.getAllUsers();
		return new ResponseEntity<>(user, HttpStatus.OK);
	}

	@GetMapping("/User/{username}")
	public ResponseEntity<?> getByUsername(@PathVariable String username) {
		try {
			Users user = userService.getUserByName(username);
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping("/updateUser/{id}")
	public ResponseEntity<?> updateUser(@PathVariable Integer id, @RequestBody Users user) {

		try {
			return new ResponseEntity<>(userService.modifyUser(id, user), HttpStatus.ACCEPTED);
		} catch (Exception e) {
			return new ResponseEntity<>(ExceptionUtils.USERUPDATE_FAILED, HttpStatus.CONFLICT);
		}
	}

	@DeleteMapping("/deleteUser/{id}")
	public ResponseEntity<String> deleteAccount(@PathVariable Integer id) {
		String deleteUser = userService.deleteUser(id);
		return new ResponseEntity<>(ExceptionUtils.USERDELETED_MESSAGE, HttpStatus.OK);
	}

	@GetMapping("/login/{email}/{password}")
	public ResponseEntity<?> userLogin(@PathVariable String email, @PathVariable String password) {

		try {
			Users user = userService.loginValidation(email, password);
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserException | UserEmailException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}
	
	@PutMapping("/updatePassword/{email}/{password}")
	public ResponseEntity<?> updateUser(@PathVariable String email,@PathVariable String password) {
			return new ResponseEntity<>(userService.forgotPassword(email, password), HttpStatus.ACCEPTED);
		
	}
}
