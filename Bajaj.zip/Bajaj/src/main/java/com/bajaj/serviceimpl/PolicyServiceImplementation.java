package com.bajaj.serviceimpl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Service;

import com.bajaj.exception.PolicyCategoryNotFound;
import com.bajaj.exception.PolicyNotFound;
import com.bajaj.modal.Policy;
import com.bajaj.modal.PolicyPremium;

import com.bajaj.repo.PolicyRepo;

import com.bajaj.service.PolicyService;
import com.bajaj.utils.ExceptionUtils;

@Service
public class PolicyServiceImplementation implements PolicyService {
	
	
	@Autowired
	PolicyRepo policyRepo;
	
	
	
	AuditorAware<String> auditAware = new AuditorAware<String>() {
		@Override
		public Optional<String> getCurrentAuditor() {
			return Optional.of(ExceptionUtils.ADMIN_NAME);
		}
	};

	
	
	@Override
	public Policy addUpdatePolicy(Policy policies) {
		Optional<String> userName =auditAware.getCurrentAuditor() ;
		if(userName.isPresent())
		userName.ifPresent(policies::setCreatedBy);
		policies.setModifiedBy(userName.orElse(null));
		policies.setPolicyStatus(true);
		return policyRepo.save(policies);
	}

	@Override
	public List<Policy> getallPolicies() throws PolicyNotFound {
		if(!policyRepo.equals(null)) {
			return policyRepo.findAll();
		}
	throw new PolicyNotFound(ExceptionUtils.ALLPOLICIES_EXCEPTION);
	}

	@Override
	public Optional<List<Policy>> getByCategory(String category) throws PolicyCategoryNotFound {
		Optional<List<Policy>> policy= policyRepo.findByPolicyCategoryContaining(category);
		if(policy.isPresent()) {
			return policy;
		}
		throw new PolicyCategoryNotFound(ExceptionUtils.POLICYCATEGORY_EXCEPTION);
	}
	
	@Override
	public Optional<Policy> getByName(String name) throws PolicyNotFound {
		Optional<Policy> policy  = policyRepo.findByPolicyNameContaining(name);
		if(policy.isPresent()) {
			return policy;
		}
		throw new PolicyNotFound(ExceptionUtils.POLICY_EXCEPTION);
	}

	@Override
	public String deletePolicy(Integer policyId) throws PolicyNotFound {
		Optional<Policy>policy=policyRepo.findById(policyId);
		if(policy.isPresent()) {
			Policy policyEntity=policy.get();
			policyEntity.setPolicyStatus(false);
			policyRepo.save(policyEntity);
			return ExceptionUtils.POLICYDELETED_MESSAGE;
		}
		throw new PolicyNotFound(ExceptionUtils.POLICY_EXCEPTION);
	}
	
	@Override
	public List<PolicyPremium> policyPremiumDetail(Integer id) throws PolicyNotFound {
		Optional<Policy> policy = policyRepo.findById(id);
		if(policy.isPresent()) {
			return policy.get().getPolicyPremium();
    }
		throw new PolicyNotFound(ExceptionUtils.POLICY_EXCEPTION);
	
	}
}
