package com.bajaj.serviceimpl;

/**
 * Contains methods to create, get, update, delete users along with login and forgot passwords
 * @author tsenthilkumar;
 */


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.bajaj.exception.UserEmailException;
import com.bajaj.exception.UserException;
import com.bajaj.modal.Users;
import com.bajaj.repo.UsersRepo;
import com.bajaj.service.UserService;
import com.bajaj.utils.ExceptionUtils;
import com.bajaj.utils.RoleUtils;
@Service
public class UserServicedImplementation implements UserService{
	
	@Autowired
	UsersRepo usersRepo;
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	
	
	/**
	 * this method is used to create new user
	 * @param Users - takes user detail 
	 * @exception UserException - throws error if user with same email,phone number, username exists
	 * @return Users detail
	 */
	
	@Override
	public Users createUser(Users user) throws UserException {
		if (usersRepo.findUserExists(user.getUserEmail(), user.getUserName(), user.getUserName()) != null) {
			throw new UserException(ExceptionUtils.USER_EXIST);
		
		}
		if ((user.getUserRole() == null || user.getUserRole().isEmpty()) && user.getUserEmail() == null
				|| !user.getUserEmail().endsWith(ExceptionUtils.ADMIN_EMAIL)) {
			user.setUserRole(RoleUtils.ROLE_USER);

		} else {
			user.setUserRole(RoleUtils.ROLE_ADMIN);
		}
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		Users users =(usersRepo.save(user));
		return users;
	}
	
	/**
	 * this method is used to get all existing users
	 * @return list of users
	 */
	

	@Override
	public List<Users> getAllUsers() {
		return usersRepo.findAll();
	}

	
	/**
	 * this method is used to get user by username
	 * @param String - username
	 * @exception UserException- throws exception if username not exists
	 * @return User
	 */
	
	@Override
	public Users getUserByName(String username) throws UserException {
		Users user=usersRepo.findByUserName(username);
		if(user==null) {
			throw new UserException(ExceptionUtils.USERNAME_EXCEPTION);
		}
		return user;
	}

	/**
	 * this is login method
	 * @param String- userEmail
	 * @param String- password
	 * @exception UserEmailException- throws exception if email not exists
	 * @exception UserException- throws exception if password is incorrect
	 * @return user details
	 */
	
	@Override
	public Users loginValidation(String useremail, String password) throws UserException, UserEmailException {
		Users user = usersRepo.findByUserEmail(useremail);
		if(user == null) {
			throw new UserEmailException(ExceptionUtils.USEREMAIL_EXCEPTION);
		}
		String encryptedPassword = user.getPassword();
		 
		if (!passwordEncoder.matches(password, encryptedPassword)) {
			throw new UserException(ExceptionUtils.PASSWORD_EXCEPTION);
		} else {

		return user;
		}

	}
	
	
	/**
	 * this is user detail update method
	 * @param integer- userId
	 * @param user
	 * @exception Exception- throws Exception if user with same details already exists
	 * @return user
	 */

	@Override
	public Users modifyUser(Integer id, Users user) throws Exception {
		Optional<Users> users = usersRepo.findById(id);
		if (users.isPresent()) {
			Users userEntity=users.get();
			userEntity.setUserName(user.getUserName());
			String encodedPassword = passwordEncoder.encode(user.getPassword());
			userEntity.setPassword(encodedPassword);
			userEntity.setUserEmail(user.getUserEmail());
			userEntity.setUserPhoneNumber(user.getUserPhoneNumber());
			userEntity.setDob(user.getDob());
			return (usersRepo.save(userEntity));  
		}
		if (usersRepo.findUserExists(user.getUserEmail(), user.getUserName(), user.getUserPhoneNumber()) != null) {
			throw new Exception(ExceptionUtils.USER_EXIST);

		}
		return user;
	}
	
	
	/**
	 * this method is to soft delete the user account
	 * @param Integer - userId
	 * @return String - message to display 
	 */
	
	@Override
	public String deleteUser(Integer userid) {
		Optional<Users> user = usersRepo.findById(userid);
		if (user.isPresent()&&user.get().getUserStatus()==true) {
			Users users = user.get();
			users.setUserStatus(false);
			usersRepo.save(users);
			return ExceptionUtils.USERDELETED_MESSAGE;
		}
		return ExceptionUtils.NOUSER_EXCEPTION;
	}

	/**
	 * this method is to update password
	 * @param - String userEmail
	 * @param - String password
	 * @return String - message to display
	 */
	
	
	@Override
	public String forgotPassword(String useremail,String password) {
		Users user = usersRepo.findByUserEmail(useremail);
		if(user!=null) {
			String encodedPassword = passwordEncoder.encode(password);
			user.setPassword(encodedPassword);
			usersRepo.save(user);
			return ExceptionUtils.PASSWORDUPDATE_SUCCESSFUL;
		}
		return ExceptionUtils.PASSWORDUPDATE_FAILED;
	}

}
