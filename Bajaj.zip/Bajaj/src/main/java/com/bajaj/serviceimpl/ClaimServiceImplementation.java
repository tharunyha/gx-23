package com.bajaj.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bajaj.exception.ClaimException;
import com.bajaj.modal.Claim;
import com.bajaj.repo.ClaimRepo;
import com.bajaj.service.ClaimService;
import com.bajaj.utils.ExceptionUtils;

@Service
public class ClaimServiceImplementation implements ClaimService {

	@Autowired
	ClaimRepo claimRepo;

	@Override
	public Claim newClaim(Claim claim) {
		claim.setActiveStatus(true);
		claim.setClaimstatus(ExceptionUtils.CLAIM_STATUS);
		return claimRepo.save(claim);
	}

	@Override
	public Optional<Claim> getById(Integer id) throws ClaimException {
		Optional<Claim> claim = claimRepo.findById(id);
		if (claim.isPresent()) {
			return claim;
		}
		throw new ClaimException(ExceptionUtils.CLAIM_EXCEPTION);
	}

	@Override
	public String cancelClaim(Integer id) throws ClaimException {
		Optional<Claim> claims = claimRepo.findById(id);
		if (claims.isPresent()) {
			Claim claim = claims.get();
			claim.setActiveStatus(false);
			claimRepo.save(claim);
			return ExceptionUtils.CLAIMDELETED_MESSAGE;
		}
		throw new ClaimException(ExceptionUtils.CLAIM_EXCEPTION);
	}

	@Override
	public List<Claim> getByPolicy(Integer policyId) throws ClaimException {
		List<Claim> claim = claimRepo.findByPolicy(policyId);
		if (claim!=null) {
			return claim;
		}
		throw new ClaimException(ExceptionUtils.CLAIM_EXCEPTION);
	
	}



}
