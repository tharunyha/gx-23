package com.bajaj.serviceimpl;

import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.bajaj.modal.PurchasePolicy;
import com.bajaj.modal.Users;
import com.bajaj.exception.CredentialException;
import com.bajaj.exception.MyPolicyException;
import com.bajaj.exception.PaymentException;
import com.bajaj.modal.PayPremium;
import com.bajaj.modal.Policy;
import com.bajaj.modal.PolicyPremium;
import com.bajaj.repo.BuyPolicyRepo;
import com.bajaj.repo.PolicyPremiumRepo;
import com.bajaj.repo.PolicyRepo;
import com.bajaj.repo.UsersRepo;
import com.bajaj.service.BuyPolicyService;
import com.bajaj.utils.ExceptionUtils;

@Service
public class BuyPolicyServiceImplementation implements BuyPolicyService {

	@Autowired
	BuyPolicyRepo buyPolicyRepo;

	@Autowired
	UsersRepo usersRepo;

	@Autowired
	PolicyRepo policyRepo;

	@Autowired
	PolicyPremiumRepo policyPremiumRepo;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@Override
	public PurchasePolicy purchasePolicy(PurchasePolicy buy, Integer policyId, Integer userId, Integer policyPremiumId)
			throws Exception {
		Optional<Policy> policy = policyRepo.findById(policyId);
		Optional<Users> users = usersRepo.findById(userId);
		buy.setPolicy(policy.get());
		buy.setUser(users.get());
		LocalDate startDate = buy.getPolicyStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate endDate = buy.getPolicyEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		long duration = Duration.between(startDate.atStartOfDay(), endDate.atStartOfDay()).toDays() / 365;
		Optional<PolicyPremium> premium = policyPremiumRepo.findById(policyPremiumId);
		buy.setPolicyPremium(premium.get());
		if (premium.isPresent()) {
			buy.setPolicyAmount(duration == 1 ? premium.get().getDurationOne()
					: (duration == 2 ? premium.get().getDurationTwo()
							: (duration == 3 ? premium.get().getDurationThree() : null)));
			return buyPolicyRepo.save(buy);
		}
		throw new MyPolicyException(ExceptionUtils.PURCHASE_FAILED);

	}

	@Override
	public Optional<PurchasePolicy> getPolicy(Integer id) throws MyPolicyException {
		Optional<PurchasePolicy> policy = buyPolicyRepo.findById(id);
		if (policy.isPresent()) {
			return policy;
		}
		throw new MyPolicyException(ExceptionUtils.PURCHASEPOLICY_EXCEPTION);
	}

	@Override
	public PurchasePolicy updatePolicy(Integer policyId, Integer policyPremiumId, PurchasePolicy policy)
			throws MyPolicyException {
		
		Optional<PurchasePolicy> buypolicy = Optional
				.of(buyPolicyRepo.findById(policyId).orElseThrow(() -> new MyPolicyException(ExceptionUtils.PURCHASEPOLICY_EXCEPTION)));
		if (buypolicy.isPresent()) {
			buypolicy.get().setPolicyEndDate(policy.getPolicyEndDate());
			buypolicy.get().setPolicyStartDate(policy.getPolicyStartDate());
			LocalDate startDate = (policy.getPolicyStartDate().toInstant().atZone(ZoneId.systemDefault())
					.toLocalDate());
			LocalDate endDate = policy.getPolicyEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			long duration = Duration.between(startDate.atStartOfDay(), endDate.atStartOfDay()).toDays() / 365;
			Optional<PolicyPremium> premium = policyPremiumRepo.findById(policyPremiumId);
			buypolicy.get().setPolicyPremium(premium.get());
			if (premium.isPresent()) {
				buypolicy.get()
						.setPolicyAmount(duration == 1 ? premium.get().getDurationOne()
								: (duration == 2 ? premium.get().getDurationTwo()
										: (duration == 3 ? premium.get().getDurationThree() : null)));
			}
			PurchasePolicy update = buypolicy.get();
			return buyPolicyRepo.save(update);
		}
		throw new MyPolicyException(ExceptionUtils.RENEW_EXCEPTION);
	}

	@Override
	public String cancelPolicy(Integer buypolicyid) throws MyPolicyException {
		Optional<PurchasePolicy> policy = buyPolicyRepo.findById(buypolicyid);
		if (policy.isPresent()) {
			buyPolicyRepo.deleteByBuypolicyId(buypolicyid);
			return ExceptionUtils.PURCHASEPOLICYCANCEL_MESSAGE;
		}
		throw new MyPolicyException(ExceptionUtils.PURCHASEPOLICY_EXCEPTION);
	}

	@Override
	public List<PayPremium> premiumPaymentHistory(Integer id) throws PaymentException {
		Optional<PurchasePolicy> policy = buyPolicyRepo.findById(id);
		if (policy.isPresent()) {
			return policy.get().getPayPremium();
		}
		throw new PaymentException(ExceptionUtils.PURCHASE_FAILED);
	}

	@Override
	public PurchasePolicy myPolicy(Integer buypolicyId, String password) throws MyPolicyException, CredentialException {
		PurchasePolicy policy = buyPolicyRepo.findById(buypolicyId).orElseThrow(MyPolicyException::new);
		if (!policy.equals(null)) {
			String encryptedPassword = policy.getUser().getPassword();
			Boolean validate = passwordEncoder.matches(password, encryptedPassword);
			if (validate == true) {
				return policy;
			}
		}
		throw new CredentialException(ExceptionUtils.CREDENTIAL_EXCEPTION);
	}

	@Override
	public List<PurchasePolicy> myPolicies(String username) throws MyPolicyException {
		Users user = usersRepo.findByUserName(username);
		if (user != null) {
			return buyPolicyRepo.findByUsers_Username(username);
		}
		throw new MyPolicyException(ExceptionUtils.PURCHASEPOLICY_EXCEPTION);

	}

}
