package com.bajaj.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bajaj.exception.PaymentException;
import com.bajaj.modal.PayPremium;
import com.bajaj.repo.PayPremiumRepo;
import com.bajaj.service.PremiumPaymentService;
import com.bajaj.utils.ExceptionUtils;

@Service
public class PaymentServiceImpl implements PremiumPaymentService  {
	
	@Autowired
	PayPremiumRepo payRepo;
	
	@Override
	public PayPremium payPremium(PayPremium  payment) {
		return payRepo.save(payment);
	}

	@Override
	public Optional<PayPremium > getPremiumbyId(String id) throws PaymentException {
		Optional<PayPremium >payPremium=payRepo.findById(id);
		if(payPremium.isPresent()) {
			return payPremium;
		}
		throw new PaymentException(ExceptionUtils.PAYMENT_NOTFOUND);
	}

	@Override
	public List<PayPremium> getAllById(Integer id) throws PaymentException {
		List<PayPremium> premium = payRepo.getPaymentByPolicy(id);
		if(premium!=null) {
			return premium;
		}
		throw new PaymentException(ExceptionUtils.PAYMENT_NOTFOUND);
	}

}
