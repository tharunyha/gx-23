package com.bajaj.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bajaj.exception.PolicyPremiumException;
import com.bajaj.modal.PolicyPremium;
import com.bajaj.repo.PolicyPremiumRepo;
import com.bajaj.service.PolicyPremiumService;
import com.bajaj.utils.ExceptionUtils;
@Service
public class PolicyPremiumServiceImplementation implements PolicyPremiumService {
	
	@Autowired
	PolicyPremiumRepo policyPremiumRepo;
	
	@Override
	public PolicyPremium createPremium(PolicyPremium premium) {
		return policyPremiumRepo.save(premium);
	}

	@Override
	public PolicyPremium getByReturnAmount(double returnAmount) throws PolicyPremiumException {
		PolicyPremium premium= policyPremiumRepo.findByReturnAmount(returnAmount);
		if(premium!=null) {
			return premium;
		}
		throw new PolicyPremiumException(ExceptionUtils.PREMIUM_EXCEPTION);
	}

	@Override
	public List<PolicyPremium> getAllPremium() {
		
		return policyPremiumRepo.findAll();
	}

}
