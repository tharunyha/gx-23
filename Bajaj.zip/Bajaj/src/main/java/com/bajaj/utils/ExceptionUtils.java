package com.bajaj.utils;

public class ExceptionUtils {
	
	//USER EXCEPTION message
	public final static String USER_EXIST="User already exists";
	public final static String ADMIN_EMAIL="@galaxe.com";
	public final static String USERNAME_EXCEPTION ="Username not found";
	public final static String USEREMAIL_EXCEPTION="Useremail not exists";
	public final static String PASSWORD_EXCEPTION="Password Incorrect";
	public final static String NOUSER_EXCEPTION="User not found";
	public final static String USERDELETED_MESSAGE="User Account deleted successfully";
	public final static String USERUPDATE_FAILED="User already exists with given credentials,User couldn't be updated";
	public final static String PASSWORDUPDATE_SUCCESSFUL="Password updated";
	public final static String PASSWORDUPDATE_FAILED="Password couldn't be updated";
	
	
	//Policy
	public final static String ADMIN_NAME="THARUNYHA";
	public final static String ALLPOLICIES_EXCEPTION="Sorry! No Policies to view";
	public final static String POLICYCATEGORY_EXCEPTION="No such policy category is available";
	public final static String POLICY_EXCEPTION="No such Policy found";
	public final static String POLICYDELETED_MESSAGE="Policy deleted successfully";
	
	//PurchasePolicy
	public final static String PURCHASE_FAILED="Unable to complete your policy purchase. Please try later";
	public final static String PURCHASEPOLICY_EXCEPTION = "Policy Application Not Found for given credentials!!!";
	public final static String PURCHASEPOLICYCANCEL_MESSAGE = "Policy application cancelled successfully";
	public final static String RENEW_EXCEPTION = "Unable to Renew Policy. Please try later";
	
	
	//PayPremium 
	public final static String PAYMENT_EXCEPTION = "Unable to process payment.Please try later";
	public final static String PAYMENT_NOTFOUND = "No Payment Details Found!!!";
			
			
	//Claim
	public final static String CLAIM_STATUS = "Initiated";
	public final static String CLAIM_EXCEPTION = "No Claims found!!! ";
	public final static String CLAIMDELETED_MESSAGE = "Your Claim is closed";
	
	//Premium
	public final static String PREMIUM_EXCEPTION = "Policy premium details not available";
	
	
	//Credentials
	public final static String CREDENTIAL_EXCEPTION = "Incorrect Credentials. Please give valid credentials";
	
	
	

	
}
