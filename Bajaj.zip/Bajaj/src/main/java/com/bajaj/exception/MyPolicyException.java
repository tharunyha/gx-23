package com.bajaj.exception;

public class MyPolicyException extends Exception {

	public MyPolicyException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyPolicyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
