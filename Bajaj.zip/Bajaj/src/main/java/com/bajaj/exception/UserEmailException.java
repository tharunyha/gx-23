package com.bajaj.exception;

public class UserEmailException extends Exception{

	public UserEmailException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserEmailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
