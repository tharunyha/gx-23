package com.bajaj.exception;

public class CredentialException extends Exception {

	public CredentialException() {
		super();
		
	}

	public CredentialException(String message) {
		super(message);
	
	}

	
}
