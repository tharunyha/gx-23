package com.bajaj.exception;

public class UserPhoneException extends Exception {

	public UserPhoneException() {
		super();
		
	}

	public UserPhoneException(String message) {
		super(message);
		
	}

}
