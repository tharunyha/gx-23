package com.bajaj.exception;

public class PolicyCategoryNotFound extends Exception  {

	public PolicyCategoryNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PolicyCategoryNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
