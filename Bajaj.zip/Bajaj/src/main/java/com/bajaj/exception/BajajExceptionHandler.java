package com.bajaj.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class BajajExceptionHandler {
	@ExceptionHandler(UserException.class)
	public ResponseEntity<?>userNameException(UserException ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("Username already exists.Give unique username", HttpStatus.INTERNAL_SERVER_ERROR);
		return msg;
	}
	
	@ExceptionHandler(UserEmailException.class)
	public ResponseEntity<?>userEmailException(UserEmailException ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("Email already exists.Please Login", HttpStatus.INTERNAL_SERVER_ERROR);
		return msg;
	}
	
	@ExceptionHandler(UserPhoneException.class)
	public ResponseEntity<?>userPhoneException(UserPhoneException ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("Phone number already exists.Please Login", HttpStatus.INTERNAL_SERVER_ERROR);
		return msg;
	}
	
	@ExceptionHandler(PolicyCategoryNotFound.class)
	public ResponseEntity<?>policyCategoryException(PolicyCategoryNotFound ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("No such Category found", HttpStatus.NOT_FOUND);
		return msg;
	}
	
	@ExceptionHandler(PolicyNotFound.class)
	public ResponseEntity<?>userPhoneException(PolicyNotFound ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("Policy number already exists.Please Login", HttpStatus.NOT_FOUND);
		return msg;
	}
	
	@ExceptionHandler(PolicyPremiumException.class)
	public ResponseEntity<?>policyPremiumException(PolicyPremiumException ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("Policy Premium details not found", HttpStatus.NOT_FOUND);
		return msg;
	}
	
	@ExceptionHandler(MyPolicyException.class)
	public ResponseEntity<?>getMyPolicy(MyPolicyException ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("No Policies Purchased", HttpStatus.NOT_FOUND);
		return msg;
	}
	
	@ExceptionHandler(CredentialException.class)
	public ResponseEntity<?>validateCredentials(CredentialException ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("Incorrect Credentials", HttpStatus.NOT_FOUND);
		return msg;
	}
	
	@ExceptionHandler(PaymentException.class)
	public ResponseEntity<?>paymentException(PaymentException ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("No payment details Found", HttpStatus.NOT_FOUND);
		return msg;
	}
	
	@ExceptionHandler(ClaimException.class)
	public ResponseEntity<?>claimException(ClaimException ex){
		ResponseEntity<String>msg=new ResponseEntity<String>("No Claims found", HttpStatus.NOT_FOUND);
		return msg;
	}
}
