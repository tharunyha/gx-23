package com.bajaj.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bajaj.modal.PolicyPremium;


@Repository
public interface PolicyPremiumRepo extends JpaRepository<PolicyPremium, Integer> {

	@Query(value="select * from policy_premium where policy_return_amount=:returnAmount", nativeQuery = true)
	PolicyPremium  findByReturnAmount(@Param("returnAmount") double returnAmount);
	
}
