package com.bajaj.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bajaj.modal.PayPremium;

@Repository
public interface PayPremiumRepo extends JpaRepository<PayPremium, String>{
	
	@Query(value="SELECT * from pay_premium WHERE my_policy_id = :id",nativeQuery = true)
	List<PayPremium> getPaymentByPolicy(int id);

}
