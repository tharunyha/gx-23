package com.bajaj.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bajaj.modal.PurchasePolicy;

import jakarta.transaction.Transactional;
import java.util.List;



@Repository
public interface BuyPolicyRepo extends JpaRepository<PurchasePolicy, Integer> {
	
	@Transactional
	@Modifying
	@Query(value="DELETE from purchase_policy where policy_id=:policyId",nativeQuery = true)
	void deleteByBuypolicyId(@Param("policyId") Integer buypolicy_id);
	
	@Query(value="SELECT * from purchase_policy p INNER JOIN users u ON p.users=u.user_id WHERE u.user_name = :username",nativeQuery = true)
	List<PurchasePolicy> findByUsers_Username(@Param("username")String userName);
	
	@Query(value="SELECT * from purchase_policy p INNER JOIN policy_premium o ON p.payment_details=o.policy_premium_id WHERE o.policy_premium_id = :policyId",nativeQuery = true)
	PurchasePolicy  findByPolicyId(@Param("policyId")Integer policyid);
	
}
