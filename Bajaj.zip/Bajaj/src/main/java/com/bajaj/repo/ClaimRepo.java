package com.bajaj.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bajaj.modal.Claim;


@Repository
public interface ClaimRepo extends JpaRepository<Claim, Integer> {

	@Query(value="SELECT * from claim WHERE my_policy_id = :policyid",nativeQuery = true)
	List<Claim> findByPolicy(@Param("policyid")Integer policyId);
}	

