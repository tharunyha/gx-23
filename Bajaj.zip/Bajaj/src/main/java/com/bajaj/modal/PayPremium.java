package com.bajaj.modal;

import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;

import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class PayPremium {
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY) 
//	@Column(name = "PaymentId")
	private String paymentId;
	
	@Column(name = "PaymentType")
	private String paymentType;
	
	@Column(name = "PaymentStatus")
	private String paymentStatus;
	
	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PaymentDate")
	private Date paymentDate;
	
	@ManyToOne(cascade = {CascadeType.MERGE})
	@JoinColumn(name = "MyPolicyId")
	private PurchasePolicy buyPolicy;

}
