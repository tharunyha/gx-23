package com.bajaj.modal;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PolicyPremium {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "PolicyPremiumId")
	private Integer policyPremiumId;
	
	@Column(name = "PolicyReturnAmount")
	private Double returnAmount;
	
	@Column(name = "OneYearPremiumAmount")
	private Double durationOne;
	
	@Column(name = "TwoYearsPremiumAmount")
	private Double durationTwo;
	
	@Column(name = "ThreeYearsPremiumAmount")
	private Double durationThree;
	
	
	@OneToMany(mappedBy = "policyPremium",cascade=CascadeType.ALL)
	@JsonIgnore
	private List <PurchasePolicy> buyPolicy;
	
	@ManyToOne
	@JoinColumn(name = "Policy")
	private Policy policy;

}
