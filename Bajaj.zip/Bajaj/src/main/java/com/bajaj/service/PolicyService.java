package com.bajaj.service;

import java.util.List;
import java.util.Optional;

import com.bajaj.exception.PolicyCategoryNotFound;
import com.bajaj.exception.PolicyNotFound;
import com.bajaj.modal.Policy;
import com.bajaj.modal.PolicyPremium;

public interface PolicyService {
	public Policy addUpdatePolicy(Policy policies);
	public List<Policy> getallPolicies() throws PolicyNotFound;
	public  Optional<List<Policy>>getByCategory(String category) throws PolicyCategoryNotFound;
	public  Optional<Policy>getByName(String name) throws PolicyNotFound;
	public String deletePolicy(Integer policyId) throws PolicyNotFound;
	List<PolicyPremium> policyPremiumDetail(Integer id) throws PolicyNotFound;
}
