package com.bajaj.service;

import java.util.List;
import java.util.Optional;

import com.bajaj.modal.PurchasePolicy;
import com.bajaj.exception.CredentialException;
import com.bajaj.exception.MyPolicyException;
import com.bajaj.exception.PaymentException;
import com.bajaj.modal.PayPremium;


public interface BuyPolicyService {
	PurchasePolicy purchasePolicy(PurchasePolicy buy,Integer policyId, Integer userId, Integer policyPremiumId) throws Exception;
	Optional<PurchasePolicy> getPolicy(Integer id) throws MyPolicyException;
	PurchasePolicy updatePolicy(Integer policyId, Integer policyPremiumId ,PurchasePolicy policy ) throws MyPolicyException;
	String cancelPolicy(Integer id) throws MyPolicyException;
	List<PayPremium> premiumPaymentHistory(Integer id) throws PaymentException;
	PurchasePolicy myPolicy(Integer buypolicyId, String password)throws MyPolicyException,CredentialException ;
	List<PurchasePolicy>myPolicies(String username) throws MyPolicyException;
	
	
	

}
