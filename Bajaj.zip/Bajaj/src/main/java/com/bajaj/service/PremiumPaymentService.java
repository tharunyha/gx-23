package com.bajaj.service;

import java.util.List;
import java.util.Optional;

import com.bajaj.exception.PaymentException;
import com.bajaj.modal.PayPremium;


public interface PremiumPaymentService {
	
	PayPremium payPremium (PayPremium payment);
	Optional<PayPremium> getPremiumbyId(String id) throws PaymentException;
	List<PayPremium>getAllById(Integer id) throws PaymentException;
}
