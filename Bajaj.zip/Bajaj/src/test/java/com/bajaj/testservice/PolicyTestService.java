package com.bajaj.testservice;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.bajaj.exception.PolicyNotFound;
import com.bajaj.modal.Policy;
import com.bajaj.service.PolicyService;

@SpringBootTest
public class PolicyTestService {
	
	@Autowired
	PolicyService policyService;
	
	
	@Test
	public void testPolicyByName() throws PolicyNotFound {
		String name="Car";
		Policy actualPolicy = policyService.getByName(name).get();
		
		Policy expectedPolicy = new Policy();
		expectedPolicy.setPolicyID(1);
		expectedPolicy.setPolicyName("Car Insurance");
		expectedPolicy.setPolicyCategory("Motor Insurance");
//		expectedPolicy.setPolicyDescription("With Bajaj Allianz car insurance , flat tires will lose their power to send you into a bad mood!  For every need, we serve up solutions faster than your favourite fast food joint. From tow truck to on-call medic, you will never have to go too far for help. With millions of customers served, if there is any place that we have not made our presence felt it is probably the racecourse! But then again, horses have long fallen out of favour as humanity’s go -to form of transportation");
		expectedPolicy.setCreatedBy("THARUNYHA");
//		expectedPolicy.setCreatedDate(Date.parse("2024-01-23T06:51:15.762+00:00"));
//		expectedPolicy.setModifiedDate("2024-01-23T17:37:51.840+00:00");
		expectedPolicy.setModifiedBy("THARUNYHA");
		expectedPolicy.setPolicyStatus(true);
		assertEquals(actualPolicy, expectedPolicy);
	}

}
