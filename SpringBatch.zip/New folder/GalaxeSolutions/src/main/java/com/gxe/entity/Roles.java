package com.gxe.entity;

public class Roles {

}
