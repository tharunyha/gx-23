package com.gxe.entity;

public class GalaxeProjects {

}
