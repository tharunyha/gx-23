package com.ehandle.advice;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class ExceptionHandling {
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public String exceptionHandler(MethodArgumentNotValidException ex) {
		return ex.getBindingResult().getFieldError().getDefaultMessage();
       
		
	}

}
