package com.ehandle.advice;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

public class UserNotFound extends RuntimeException{

	

	public UserNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(UserNotFound.class)
	public String handleRror(UserNotFound ex) {
		return ex.getLocalizedMessage();
	}
}
