package com.ehandle.dto;

import org.springframework.stereotype.Component;

import com.ehandle.entity.Users11;

import io.micrometer.common.lang.NonNull;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
//@Component
//@AllArgsConstructor(staticName = "build")
//@NoArgsConstructor
public class User11Dto {
	
	@NotNull(message = "username shouldn't be null")
	private String user_name;
	
	@Min(18)
	@Max(60)
	private int age;
	@Email(message = "invalid email id")
	private String email;
}
