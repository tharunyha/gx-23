package com.ehandle.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ehandle.entity.Users11;

@Repository
public interface UsersRepo extends JpaRepository<Users11, Long> {
	Users11  findByUserId(Long user_id);
}
