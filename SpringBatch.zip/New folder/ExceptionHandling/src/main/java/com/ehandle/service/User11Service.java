package com.ehandle.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ehandle.advice.UserNotFound;
import com.ehandle.dto.User11Dto;
import com.ehandle.entity.Users11;
import com.ehandle.repo.UsersRepo;

@Service
public class User11Service {
	@Autowired
	UsersRepo userrepo;
	
	public Users11 saveUsers(User11Dto userdto) {
		Users11 use = Users11.build(0, userdto.getUser_name(), userdto.getAge(), userdto.getEmail());
		return userrepo.save(use);	
	}
	
	public Users11 getUserById(Long id) {
		Optional<Users11> user11= userrepo.findById(id);
		if(user11.isPresent()) {
			return user11.get();
		}
		else {
			throw new UserNotFound("user not found for id "+id);
		}
	}

}
