package com.ehandle.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ehandle.dto.User11Dto;
import com.ehandle.entity.Users11;
import com.ehandle.service.User11Service;

import jakarta.validation.Valid;

@RestController
public class UsersController {
		@Autowired
		User11Service userserve;
		
		@PostMapping("/create")
		public ResponseEntity<Users11> createUser(@RequestBody @Valid User11Dto userdto11){
			return new ResponseEntity<>(userserve.saveUsers(userdto11),HttpStatus.CREATED);
		}
		
		@GetMapping("/get/{id}")
		public ResponseEntity<Users11> getUserbyId(@PathVariable Long id){
			return  ResponseEntity.ok(userserve.getUserById(id));
		}
}
