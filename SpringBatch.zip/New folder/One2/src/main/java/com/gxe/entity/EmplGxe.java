package com.gxe.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.gxe.dto.ProjectDTO;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmplGxe {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long emp_id;
	private String name;
	private String team_name;
	
	@ManyToMany(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@JoinTable(name="EMPLOYEE_PROJECT",joinColumns = {@JoinColumn(name="Employee_id")},
			inverseJoinColumns = {@JoinColumn(name="Project_id")})
	private Set<Project> projects;

	public void addProject(Project pro) {
		this.projects.add(pro);
		pro.getEmpl().add(this);
		
	}
	public void deleteProject(Project pro) {
		this.getProjects().remove(pro);
		pro.getEmpl().remove(this);
	}
	public void deletemanyProjects() {
		for(Project project : new HashSet<>(projects)) {
			deleteProject(project);
		}
	}
	
}
