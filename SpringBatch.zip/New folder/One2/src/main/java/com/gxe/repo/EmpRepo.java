package com.gxe.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gxe.entity.EmplGxe;
import com.gxe.entity.Project;
@Repository
public interface EmpRepo extends JpaRepository<EmplGxe,Long> {
	public  List<EmplGxe> findByName(String name);

}
