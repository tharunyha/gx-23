package com.gxe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.gxe.dto.ProjectDTO;
import com.gxe.service.ProjectService;

@RestController
public class ProjectController {

	@Autowired
	private ProjectService projectserve;
	
	@PostMapping("/saveProject")
	public ResponseEntity<ProjectDTO> saveEmployee(@RequestBody ProjectDTO dto){
		ProjectDTO empldto=projectserve.addProject(dto);
		return new ResponseEntity<>(empldto,HttpStatus.CREATED);
	}
	@GetMapping("/getProject")
	public ResponseEntity<List<ProjectDTO>> getEmployees(){
		List<ProjectDTO> empldto=projectserve.getAllProjects();
		return new ResponseEntity<>(empldto,HttpStatus.OK);
	
}
	@PutMapping("/updateProject/{id}")
	public ResponseEntity<ProjectDTO> updateEmployee(@PathVariable Long projectId, @RequestBody ProjectDTO dto){
		ProjectDTO empldto=projectserve.updateproject(projectId, dto);
		return new ResponseEntity<>(empldto,HttpStatus.CREATED);
	}
	@DeleteMapping("/deleteProject/{id}")
	public ResponseEntity<String> removeEmployee(@PathVariable Long projectId){
		String projectdto=projectserve.deleteProject(projectId);
		return new ResponseEntity<>(projectdto, HttpStatus.OK);
		   
	}
}
