package com.gxe.controller;

import java.util.List;

import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.gxe.dto.EmpDTO;
import com.gxe.serviceimpl.EmployeeServiceImpl;

@RestController
public class EmplController {

	@Autowired
	private EmployeeServiceImpl employeeserve;
	
	@PostMapping("/saveEmployee")
	public ResponseEntity<EmpDTO> saveEmployee(@RequestBody EmpDTO dto){
		EmpDTO empldto=employeeserve.addEmployee(dto);
		return new ResponseEntity<>(empldto,HttpStatus.CREATED);
	}
	@GetMapping("/getEmployees")
	public ResponseEntity<List<EmpDTO>> getEmployees(){
		List<EmpDTO> empldto=employeeserve.getallEmployees();
		return new ResponseEntity<>(empldto,HttpStatus.OK);
	
}
	@PutMapping("/updateEmployee/{id}")
	public ResponseEntity<EmpDTO> updateEmployee(@PathVariable Long empId, @RequestBody EmpDTO dto){
		EmpDTO empldto=employeeserve.updateEmployee(empId, dto);
		return new ResponseEntity<>(empldto,HttpStatus.CREATED);
	}
	@DeleteMapping("/deleteEmployee/{id}")
	public ResponseEntity<String> removeEmployee(@PathVariable Long empId){
		String empldto=employeeserve.deleteEmployee(empId);
		return new ResponseEntity<>(empldto, HttpStatus.OK);
		   
	}
}