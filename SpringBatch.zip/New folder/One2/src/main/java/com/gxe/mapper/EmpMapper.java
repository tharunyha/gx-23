package com.gxe.mapper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gxe.dto.EmpDTO;
import com.gxe.entity.EmplGxe;
import com.gxe.entity.Project;
import com.gxe.repo.ProjRepo;

@Component
public class EmpMapper {
	
	@Autowired
	private ProjRepo prorepo;
	
	
	public EmpDTO toempdto(EmplGxe empl) {
		EmpDTO dto=new EmpDTO();
		dto.setEmp_id(empl.getEmp_id());
		dto.setName(empl.getName());
		dto.setTeam_name(empl.getTeam_name());
		dto.setProjects(empl.getProjects().stream().map(Project::getProjectname).collect(Collectors.toSet()));
		return dto;
	}
	public EmplGxe toemp(EmpDTO dto) {
		EmplGxe empl=new EmplGxe();
		empl.setEmp_id(dto.getEmp_id());
		empl.setName(dto.getName());
		empl.setTeam_name(dto.getTeam_name());
		if(empl.getProjects()==null) {
			empl.setProjects(new HashSet<>());
		}
		dto.getProjects().stream().forEach(projectname->{
			Project pro = prorepo.findByProjectname(projectname);
			if(pro==null) {
				pro=new Project();
				pro.setEmpl(new HashSet<>());
			}
			pro.setProjectname(projectname);
		});
		return empl;
	}

}
