package com.gxe.service;

import java.util.List;

import com.gxe.dto.EmpDTO;

public interface EmployeeService {
	public EmpDTO addEmployee(EmpDTO dto);
	public List<EmpDTO>getallEmployees();
	public List<EmpDTO>getByName(String name);
	public EmpDTO updateEmployee(Long empId,EmpDTO emp);
	public String deleteEmployee(Long empId);
}
