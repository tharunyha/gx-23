package com.gxe.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gxe.dto.EmpDTO;
import com.gxe.entity.EmplGxe;
import com.gxe.mapper.EmpMapper;
import com.gxe.repo.EmpRepo;
import com.gxe.repo.ProjRepo;
import com.gxe.service.EmployeeService;

import jakarta.transaction.Transactional;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmpRepo emprepo;
	
	@Autowired
	private ProjRepo prorepo;

	@Override
	public EmpDTO addEmployee(EmpDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmpDTO> getallEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmpDTO> getByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmpDTO updateEmployee(Long empId, EmpDTO emp) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(Long empId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
