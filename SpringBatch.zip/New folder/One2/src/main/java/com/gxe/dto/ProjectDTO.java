package com.gxe.dto;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Component

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectDTO {
	private long project_id;
	private String projectname;
	private Set<String>employees=new HashSet<>();
}
