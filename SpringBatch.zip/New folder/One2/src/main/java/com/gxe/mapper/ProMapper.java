package com.gxe.mapper;

import org.springframework.stereotype.Component;

import com.gxe.dto.ProjectDTO;
import com.gxe.entity.Project;

@Component
public class ProMapper {
	
	public ProjectDTO toDto(Project project) {
		ProjectDTO dto = new ProjectDTO();
		dto.setProject_id(project.getProject_id());
		dto.setProjectname(project.getProjectname());
		return dto;
		
	}
	
	public Project toproject(ProjectDTO dto) {
		Project pro=new Project();
		pro.setProject_id(dto.getProject_id());
		pro.setProjectname(dto.getProjectname());
		return pro;
	}

}
