package com.gxe.entity;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Project {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long project_id;
	private String projectname;

	@ManyToMany(mappedBy = "projects")
	@JsonIgnore
	private Set<EmplGxe> empl;
	
	public void removeProject(EmplGxe employee) {
		this.getEmpl().remove(employee);
		employee.getProjects().remove(this);
	}

	public void removeProjects() {
		for (EmplGxe employee : new HashSet<>(empl)) {
			removeProject(employee);
		}
	}
}
