package com.gxe.service;

import java.util.List;

import com.gxe.dto.ProjectDTO;


public interface ProjectService {
	
	
	public ProjectDTO addProject(ProjectDTO project);

	public List<ProjectDTO> getAllProjects();

	public ProjectDTO updateproject(Long projectId, ProjectDTO project);

	public String deleteProject(Long projectId);

}
