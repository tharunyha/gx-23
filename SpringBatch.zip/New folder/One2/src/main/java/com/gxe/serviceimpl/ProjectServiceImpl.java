package com.gxe.serviceimpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gxe.dto.EmpDTO;
import com.gxe.dto.ProjectDTO;
import com.gxe.entity.EmplGxe;
import com.gxe.entity.Project;
import com.gxe.mapper.ProMapper;
import com.gxe.repo.EmpRepo;
import com.gxe.repo.ProjRepo;
import com.gxe.service.ProjectService;

import jakarta.transaction.Transactional;

@Service
public class ProjectServiceImpl implements ProjectService {
	
@Autowired
	private EmpRepo emprepo;
	
	@Autowired
	private ProjRepo prorepo;

	@Override
	public ProjectDTO addProject(ProjectDTO project) {
		Project pro = new Project();
		mapDtoToEntity(project, pro);
		Project saveProject = prorepo.save(pro);
		return mapEntityToDto(saveProject);
	}

	@Override
	public List<ProjectDTO> getAllProjects() {
		List<ProjectDTO> proDtos = new ArrayList<>();
		List<Project> projects = prorepo.findAll();
		projects.stream().forEach(project -> {
			ProjectDTO Dto = mapEntityToDto(project);
			proDtos.add(Dto);
		});
		return proDtos;
	}

	@Override
	public ProjectDTO updateproject(Long projectId, ProjectDTO project) {
		Project pro = prorepo.getOne(projectId);
		pro.getEmpl().clear();
		mapDtoToEntity(project, pro);
		Project project2 = prorepo.save(pro);
		return mapEntityToDto(project2);
	}
	@Transactional
	@Override
	public String deleteProject(Long projectId) {
		Optional<Project> project = prorepo.findById(projectId);
		// Remove the related students from course entity.
		if(project.isPresent()) {
			project.get().removeProjects();
			prorepo.deleteById(project.get().getProject_id());
			return "Course with id: " + projectId + " deleted successfully!";
		}
		return null;
	}
	
	private void mapDtoToEntity(ProjectDTO projectDTO, Project project) {
		project.setProjectname(projectDTO.getProjectname());
		if (null == project.getEmpl()) {
			project.setEmpl(new HashSet<>());
		}
		projectDTO.getEmployees().stream().forEach(employeeName -> {
			EmplGxe employee = (EmplGxe) emprepo.findByName(employeeName);
			if (null == employee) {
				employee = new EmplGxe();
				employee.setProjects(new HashSet<>());
			}
			employee.setName(employeeName);
			employee.addProject(project);
		});
	}

	private ProjectDTO mapEntityToDto(Project project) {
		ProjectDTO responseDto = new ProjectDTO();
		responseDto.setProjectname(project.getProjectname());
		responseDto.setProject_id(project.getProject_id());
		responseDto.setEmployees(project.getEmpl().stream().map(EmplGxe::getName).collect(Collectors.toSet()));
		return responseDto;
	}

}
