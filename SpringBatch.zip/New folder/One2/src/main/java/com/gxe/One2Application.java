package com.gxe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
@EnableJpaRepositories
@SpringBootApplication
public class One2Application {

	public static void main(String[] args) {
		SpringApplication.run(One2Application.class, args);
	}

}
