package com.gxe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class One2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
