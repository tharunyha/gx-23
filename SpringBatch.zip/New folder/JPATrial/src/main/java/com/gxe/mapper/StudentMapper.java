package com.gxe.mapper;

import org.springframework.stereotype.Component;

import com.gxe.dto.StudentDto;
import com.gxe.entity.Student;

@Component
public class StudentMapper {
	
	public StudentDto toStudentdto(Student student) {
		StudentDto dto=new StudentDto();
		dto.setStudentid(student.getStudentid());
		dto.setStudentname(student.getStudentname());
		dto.setGrade(student.getGrade());
		dto.setAttendancepercent(student.getAttendancepercent());
		return dto;	
	}
	
	public Student toStudent(StudentDto studentdto) {
		Student student=new Student();
		student.setStudentid(studentdto.getStudentid());
		student.setStudentname(studentdto.getStudentname());
		student.setGrade(studentdto.getGrade());
		student.setAttendancepercent(studentdto.getAttendancepercent());
		return student;	
	}
}
