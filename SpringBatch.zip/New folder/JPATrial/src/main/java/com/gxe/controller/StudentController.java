package com.gxe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gxe.dto.StudentDto;
import com.gxe.exception.StudentException;
import com.gxe.service.StudentService;
@RestController
public class StudentController {

	@Autowired
	StudentService studentservice;
	
	@GetMapping("/getStudentById/{id}")
	public ResponseEntity<StudentDto> getTicketById(@PathVariable int id) throws Exception {
		return new ResponseEntity<StudentDto>(studentservice.viewStudent(id),HttpStatus.OK);
	}
	
//	@GetMapping("/getByNameStaratingWith/{passengerName}")
//	public ResponseEntity<List<TicketDTO>> getByPassengerNameStartingWith(@PathVariable String passengerName) throws TicketException{
//		return new ResponseEntity<List<TicketDTO>>(ticketservice.getByPassengerNameStartingWith(passengerName),HttpStatus.OK);
//	}
	
	@PostMapping("/enrollStudent")
	public ResponseEntity<StudentDto> createTicket(@RequestBody StudentDto studentdto){
		return new ResponseEntity<StudentDto>(studentservice.enrollStudent(studentdto),HttpStatus.OK);
	}
	
	@PutMapping("/updateStudent")
	public ResponseEntity<StudentDto> updateTicket(@RequestBody StudentDto studentdto){
		return new ResponseEntity<StudentDto>(studentservice.updateStudent(studentdto),HttpStatus.OK);
	}
	
	@DeleteMapping("/removeStudent/{id}")
	public ResponseEntity<String> deleteTicket(@PathVariable int id) throws StudentException {
		studentservice.removeStudent(id);
		return new ResponseEntity<String>("Student removed" ,HttpStatus.OK);
	}
	
	@GetMapping("/getAllStudents")
	public ResponseEntity<List<StudentDto>> getAllTicket() throws StudentException{
		return new ResponseEntity<List<StudentDto>>(studentservice.viewallStudent(),HttpStatus.OK);
	}
	

	
}
