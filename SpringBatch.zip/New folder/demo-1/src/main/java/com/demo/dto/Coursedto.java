package com.demo.dto;

import java.util.List;

import org.springframework.stereotype.Component;

import com.demo.entity.Batch;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.OneToMany;
import lombok.Data;
//@Data
@Component
public class Coursedto {
	
	private long course_id;	
	private String course_name;
	private List<Batchdto> batches;
	public long getCourse_id() {
		return course_id;
	}
	public void setCourse_id(long course_id) {
		this.course_id = course_id;
	}
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public List<Batchdto> getBatches() {
		return batches;
	}
	public void setBatches(List<Batchdto> batches) {
		this.batches = batches;
	}
	
	

}
