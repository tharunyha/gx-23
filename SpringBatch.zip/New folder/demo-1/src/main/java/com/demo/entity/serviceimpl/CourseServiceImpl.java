package com.demo.entity.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dto.Batchdto;
import com.demo.dto.Coursedto;
import com.demo.entity.Batch;
import com.demo.entity.Course;
import com.demo.entity.repo.CourseRepo;
import com.demo.entity.service.CourseService;

@Service
public class CourseServiceImpl implements CourseService {
	
	
	@Autowired
	CourseRepo courserepo;
	
//	@Override
//	public Course getCourseById(Long course_id) {
//		 return courserepo.findById(course_id).orElse(null);
////		List<Batch> batch = course.getBatches();		
////		List<Batchdto> bdto = new ArrayList<>();
////		for(Batch ba:batch) {
////			Batchdto b = new Batchdto();
////			b.setBatch_id(ba.getBatch_id());
////			b.setBatch_name(ba.getBatch_name());
////			b.setTotalemp(ba.getTotalemp());
////			bdto.add(b);
//		//return course;
//		
////		Coursedto cdto = new Coursedto();
////		cdto.setBatches(bdto);
////		cdto.setCourse_id(course.getCourse_id());
////		cdto.setCourse_name(course.getCourse_name());
////		
////		return cdto;
//		
//	}

	@Override
	public void deleteCourse(Long course_id) {
		courserepo.deleteById(course_id);
		
	}

	@Override
	public Coursedto createCourse(Coursedto course) {
		Course c = new Course();
		c.setCourse_id(course.getCourse_id());
		c.setCourse_name(course.getCourse_name());
	
		List<Batchdto> bt = course.getBatches();
		List<Batch> batchnew = new ArrayList<>();
		for(Batchdto batch : bt) {
			Batch b = new Batch();
			b.setBatch_id(batch.getBatch_id());
			b.setBatch_name(batch.getBatch_name());
			b.setTotalemp(batch.getTotalemp());
			b.setCourse(c);
			batchnew.add(b);	
		}
		c.setBatches(batchnew);
		return course;
		
	}

}
