package com.demo.entity.service;



import com.demo.entity.Employee;

public interface EmployeeService {
	
	Employee getEmployeeById(Long emp_id);
	void deleteEmployee(Long emp_id);
	Employee createEmployee(Employee employee);
}
