package com.demo.dto;

import java.util.List;

import org.springframework.stereotype.Component;

import com.demo.entity.Batch;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

//@Data
@Component
public class Batchdto {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long batch_id;
	private String batch_name;
	private int totalemp;
	public long getBatch_id() {
		return batch_id;
	}
	public void setBatch_id(long batch_id) {
		this.batch_id = batch_id;
	}
	public String getBatch_name() {
		return batch_name;
	}
	public void setBatch_name(String batch_name) {
		this.batch_name = batch_name;
	}
	public int getTotalemp() {
		return totalemp;
	}
	public void setTotalemp(int totalemp) {
		this.totalemp = totalemp;
	}

	
}
