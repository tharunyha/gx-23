package com.demo.entity.service;

import com.demo.dto.Coursedto;
import com.demo.entity.Course;


public interface CourseService {

	//Coursedto getCourseById(Long course_id);
	void deleteCourse(Long course_id);
	Coursedto createCourse(Coursedto course);
}
