package com.pro.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pro.entity.PolicyHolder;

@Repository
public interface PolicyHolderRepo extends JpaRepository<PolicyHolder, Long> {

}
