package com.pro.entity;

import java.util.Date;
import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class PolicyHolder {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ph_id;
	private String ph_name;
	private Date dob;
	private double annualincome;
	private String occupation;
	private String phonenum;
	private String email;
	
//	@ManyToOne
//	@JoinColumn(name = "policy_id")
//	private Policy policy;
	
	@OneToMany(mappedBy = "policyHolder")
	private Set<Medical> medical;
	

	@OneToMany(mappedBy = "policyHolder")
	private Set<Address> add;


	public long getPh_id() {
		return ph_id;
	}


	public void setPh_id(long ph_id) {
		this.ph_id = ph_id;
	}


	public String getPh_name() {
		return ph_name;
	}


	public void setPh_name(String ph_name) {
		this.ph_name = ph_name;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public double getAnnualincome() {
		return annualincome;
	}


	public void setAnnualincome(double annualincome) {
		this.annualincome = annualincome;
	}


	public String getOccupation() {
		return occupation;
	}


	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}


	public String getPhonenum() {
		return phonenum;
	}


	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Policy getPolicy() {
		return policy;
	}


	public void setPolicy(Policy policy) {
		this.policy = policy;
	}


	public Set<Medical> getMedical() {
		return medical;
	}


	public void setMedical(Set<Medical> medical) {
		this.medical = medical;
	}


	public Set<Address> getAdd() {
		return add;
	}


	public void setAdd(Set<Address> add) {
		this.add = add;
	}
	
	
	
}
