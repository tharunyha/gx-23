package com.pro.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Medical {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long med_id;
	private String med_history;


	@ManyToOne
	@JoinColumn(name = "ph_id")
	private PolicyHolder policyHolder;


	public long getMed_id() {
		return med_id;
	}


	public void setMed_id(long med_id) {
		this.med_id = med_id;
	}


	public String getMed_history() {
		return med_history;
	}


	public void setMed_history(String med_history) {
		this.med_history = med_history;
	}


	public PolicyHolder getPolicyHolder() {
		return policyHolder;
	}


	public void setPolicyHolder(PolicyHolder policyHolder) {
		this.policyHolder = policyHolder;
	}
	
	

}
