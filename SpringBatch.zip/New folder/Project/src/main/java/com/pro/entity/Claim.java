package com.pro.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;

import jakarta.persistence.OneToOne;


@Entity
public class Claim {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long claim_no;
	private String claim_reason;
	private double amount;
	
	public long getClaim_no() {
		return claim_no;
	}

	public void setClaim_no(long claim_no) {
		this.claim_no = claim_no;
	}

	public String getClaim_reason() {
		return claim_reason;
	}

	public void setClaim_reason(String claim_reason) {
		this.claim_reason = claim_reason;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public PolicyHolder getPolicyHolder() {
		return policyHolder;
	}

	public void setPolicyHolder(PolicyHolder policyHolder) {
		this.policyHolder = policyHolder;
	}

	@OneToOne
	@JoinColumn(name = "ph_id")
	private PolicyHolder policyHolder;
	
	
	

}
