package com.pro.entity;

import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Policy {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long policyid;
	private String policytype;
	private String policyname;
	private String desc;
//	
//	@OneToMany(mappedBy = "policy")
//	private Set<PolicyHolder> policyHolder;
	
//	
//	public Set<PolicyHolder> getPolicyHolder() {
//		return policyHolder;
//	}
//	public void setPolicyHolder(Set<PolicyHolder> policyHolder) {
//		this.policyHolder = policyHolder;
	}
	public long getPolicyid() {
		return policyid;
	}
	public void setPolicyid(long policyid) {
		this.policyid = policyid;
	}
	public String getPolicytype() {
		return policytype;
	}
	public void setPolicytype(String policytype) {
		this.policytype = policytype;
	}
	public String getPolicyname() {
		return policyname;
	}
	public void setPolicyname(String policyname) {
		this.policyname = policyname;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
}
