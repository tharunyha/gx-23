package com.gxe.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Service;

import com.gxe.modal.Policy;
import com.gxe.modal.Usersdeet;
import com.gxe.repo.PolicyRepo;
import com.gxe.repo.UserRepo;
import com.gxe.service.PolicyService;
import com.gxe.util.BajajUtils;

@Service
public class PolicyServiceImpl implements PolicyService {
	
	@Autowired
	PolicyRepo policyrepo;
	
	@Autowired
	UserRepo userrepo; 
//	AuditorAware<String> auditorAware;

	
	
	AuditorAware<String> auditaware = new AuditorAware<String>() {
		
		@Override
		public Optional<String> getCurrentAuditor() {
		    long id=7;
			Optional<Usersdeet> user = userrepo.findById(id);
			if(user.isPresent()&&user.get().getUserrole()==BajajUtils.ROLE_ADMIN) {
				return Optional.of(user.get().getUsername());
			}
			return Optional.of("Tharunyha");
		}
	};
	@Override
	public Policy addorupdatePolicy(Policy policies) {
		Optional<String> username =auditaware.getCurrentAuditor() ;
		username.ifPresent(policies::setCreatedBy);
		policies.setModifiedBy(username.orElse(null));
		return policyrepo.save(policies);
	}

	@Override
	public List<Policy> getallPolicies() {
		return policyrepo.findAll();
	}

	@Override
	public Optional<Policy> getPolicybyId(Long policyId) {
		return policyrepo.findById(policyId);
	}

	@Override
	public String deletePolicy(Long policyId) {
		policyrepo.deleteById(policyId);
		return "Policy with id "+policyId+" is deleted";
	}

	

}
