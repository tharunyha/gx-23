package com.gxe.mapper;

import org.springframework.stereotype.Component;

import com.gxe.dto.RegisterDto;
import com.gxe.modal.Usersdeet;
@Component
public class RegistrationMapper {
	
	public RegisterDto toregisterdto (Usersdeet user) {
		RegisterDto dto = new RegisterDto();
		dto.setUsername(user.getUsername());
		dto.setUseremail(user.getUseremail());
		dto.setPassword(user.getPassword());
		dto.setUserphoneno(user.getUserphoneno());
		dto.setUserrole(user.getUserrole());
		dto.setUserstatus(user.getUserstatus());
		return dto;
	}
	
	public Usersdeet touser(RegisterDto dto) {
		Usersdeet userent = new Usersdeet();
		userent.setUsername(dto.getUsername());
		userent.setUseremail(dto.getUseremail());
		userent.setPassword(dto.getPassword());
		userent.setUserphoneno(dto.getUserphoneno());
		userent.setUserrole(dto.getUserrole());
		userent.setUserstatus(dto.getUserstatus());
		return userent;
				
	}

}
