package com.gxe.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gxe.modal.Policy;
@Repository
public interface PolicyRepo extends JpaRepository<Policy, Long>{

}
