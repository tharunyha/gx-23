package com.gxe.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gxe.modal.Usersdeet;

@Repository
public interface UserRepo extends JpaRepository<Usersdeet, Long> {
	Optional<Usersdeet> findByUsername(String username);
	Optional<Usersdeet> findByUseremail(String useremail);
	Optional<Usersdeet> findByUserphoneno(String phonenumber);
	
	
}
