package com.gxe.service;

import java.util.Optional;

import javax.naming.AuthenticationException;

import com.gxe.dto.LoginDto;
import com.gxe.dto.RegisterDto;
import com.gxe.modal.Usersdeet;

public interface UserService {

	
	 RegisterDto registerUser(RegisterDto rdto) throws Exception;
	 Optional<Usersdeet> getUser(long id);
	 Optional<Usersdeet> findUser(String username);
	 RegisterDto modifyUser(RegisterDto regdto)throws Exception;
	
}
