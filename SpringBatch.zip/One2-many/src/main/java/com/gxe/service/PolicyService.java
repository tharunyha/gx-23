package com.gxe.service;

import java.util.List;
import java.util.Optional;

import com.gxe.modal.Policy;

public interface PolicyService {
	public Policy addorupdatePolicy(Policy policies);
	public List<Policy> getallPolicies();
	public Optional<Policy> getPolicybyId(Long policyId);
	public String deletePolicy(Long policyId);
}
