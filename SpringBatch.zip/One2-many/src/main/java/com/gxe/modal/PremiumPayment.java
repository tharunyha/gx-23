package com.gxe.modal;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class PremiumPayment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long payment_id;
	private String paymenttype;
	private String paymentStatus;
	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	private Date paymentdate;
	
	@ManyToOne(cascade = {CascadeType.MERGE})
	@JsonBackReference
	@JoinColumn(name = "buypolicy_id")
	private BuyPolicy buypolicy;

}
