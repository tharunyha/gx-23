package com.gxe.modal;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BuyPolicy {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long buypolicy_id;
	private Date policyStartDate;
	private Date policyEndDate;
	private String paymentCycle;
	private float premiumAmount;
	private float returnAmount;
	private List<String>insuranceDetails;
	@ManyToOne(cascade = {CascadeType.MERGE})
	@JoinColumn(name = "user_id")
	@JsonBackReference
	private Usersdeet users;
	@ManyToOne(cascade = {CascadeType.MERGE})
	@JoinColumn(name = "policy_id")
	@JsonBackReference
	private Policy policy;
	@OneToMany(mappedBy = "buypolicy" , orphanRemoval = true,cascade={CascadeType.ALL},fetch= FetchType.EAGER)
	@JsonManagedReference
	private List<Claim> claim;
	@OneToMany(mappedBy = "buypolicy" ,cascade={CascadeType.ALL},fetch= FetchType.EAGER)
	@JsonManagedReference
	private List<PremiumPayment> payment;

	
	
	

}
