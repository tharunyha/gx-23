package com.gxe.controller;

import java.util.List;
import java.util.Optional;

import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.gxe.dto.RegisterDto;
import com.gxe.modal.Policy;
import com.gxe.modal.Usersdeet;
import com.gxe.service.PolicyService;
import com.gxe.service.UserService;


@CrossOrigin("*")
@RestController
public class PolicyController {
	@Autowired
	PolicyService policyservice;
	
	@Autowired
	UserService userserve;
	
	@PostMapping("/policy")
	public ResponseEntity<Policy>createPolicy(@RequestBody Policy policy){
		Policy newPolicy = policyservice.addorupdatePolicy(policy);
		return new ResponseEntity<>(newPolicy,HttpStatus.CREATED);
	}
	@GetMapping("/Policies")
	public ResponseEntity<List<Policy>>getAllPolicies(){
		List<Policy> policies=policyservice.getallPolicies();
		return new ResponseEntity<>(policies,HttpStatus.OK);
	}
	@GetMapping("/Policies/{policyid}")
	public ResponseEntity<Optional<Policy>>getPolicy(@PathVariable long policyid){
		Optional<Policy> policy=policyservice.getPolicybyId(policyid);
		return new ResponseEntity<>(policy,HttpStatus.OK);	
	}
	@PutMapping("/updatePolicy/{id}")
	public ResponseEntity<Policy>updatePolicy(@PathVariable long id,@RequestBody Policy policy){
		Optional<Policy> oldpolicy=policyservice.getPolicybyId(id);
		if(oldpolicy!=null) {
			policy.setPolicyID(id);
			Policy updatedPolicy = policyservice.addorupdatePolicy(policy);
			return new ResponseEntity<>(updatedPolicy,HttpStatus.ACCEPTED);	
		}
		return ResponseEntity.notFound().build();
	}
	@DeleteMapping("/deletePolicy/{id}")	
	public ResponseEntity<String>delete(@PathVariable long id){
		String deletePolicy=policyservice.deletePolicy(id);
		return new ResponseEntity<>(deletePolicy,HttpStatus.OK);
	}
	@GetMapping("/getbyusername/{username}")
	public ResponseEntity<Optional<Usersdeet>>getUser(@PathVariable String username){
		Optional<Usersdeet> user=userserve.findUser(username);
		return new ResponseEntity<>(user,HttpStatus.OK);
		
	}
}
