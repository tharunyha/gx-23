package com.gxe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@Configuration
@SpringBootApplication
@EnableJpaAuditing
@ComponentScan(basePackages = "com.gxe")
public class One2ManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(One2ManyApplication.class, args);
	}
	 
}
