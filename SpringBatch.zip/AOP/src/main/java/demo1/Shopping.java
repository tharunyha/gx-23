package demo1;

import org.springframework.stereotype.Component;

@Component
public class Shopping {
	public void checkout() {
		System.out.println("you have checked out");
	}
	public int quantity() {
		return 7;
	}
}
