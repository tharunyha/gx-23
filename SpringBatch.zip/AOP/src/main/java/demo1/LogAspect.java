package demo1;

import java.util.logging.Logger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Aspect
@Component
@EnableAspectJAutoProxy
public class LogAspect {
	
	//Log logging = LogFactory.getLog(LogAspect.class);
	@Pointcut("execution(* demo1.Shopping.quantity())")
	public void logPoint() {
		
	}
	
	@Before("logPoint()")
	public void beforeLog() {
		System.out.println("this is before jp");
	}
	@AfterReturning(pointcut = "logPoint()", returning  = "retVal")
	public void afterLog(JoinPoint jp,int retVal) {
		System.out.println("After returning "+retVal);
	}
	
}
