package com.gxe.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gxe.entity.Visitors;

public interface VisitorsRepository extends JpaRepository<Visitors, Long> {

}
