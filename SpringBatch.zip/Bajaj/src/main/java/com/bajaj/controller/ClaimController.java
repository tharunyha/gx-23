package com.bajaj.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.exception.ClaimException;
import com.bajaj.modal.Claim;
import com.bajaj.service.ClaimService;

@RestController
@CrossOrigin("*")
public class ClaimController {

	@Autowired
	ClaimService claimService;

	@PostMapping("/Claim")
	public ResponseEntity<Claim> createPolicy(@RequestBody Claim claim) {
		Claim claims = claimService.newClaim(claim);
		return new ResponseEntity<>(claims, HttpStatus.CREATED);
	}

	@GetMapping("/MyClaim/{claimId}")
	public ResponseEntity<?> getClaim(@PathVariable Integer claimId) {
		try {
			Optional<Claim> claim = claimService.getById(claimId);
			return new ResponseEntity<>(claim, HttpStatus.OK);
		} catch (ClaimException e) {
			return new ResponseEntity<>("Invalid Credentials", HttpStatus.NOT_FOUND);
		}

	}
	
	@GetMapping("/MyClaim/MyPolicy/{policyId}")
	public ResponseEntity<?> getPolicy(@PathVariable Integer policyId) {
		try {
			List<Claim> claim = claimService.getByPolicy(policyId);
			return new ResponseEntity<>(claim, HttpStatus.OK);
		} catch (ClaimException e) {
			return new ResponseEntity<>("Invalid Credentials", HttpStatus.NOT_FOUND);
		}

	}

	@DeleteMapping("/CancelClaim/{id}")
	public ResponseEntity<String> cancelClaim(@PathVariable Integer id) {
		try {
			String deleteClaim = claimService.cancelClaim(id);
			return new ResponseEntity<>(deleteClaim, HttpStatus.OK);
		} catch (ClaimException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}

	}
	
//	@PostMapping("/Claim/{policyId}")
//	public ResponseEntity<?> createPolicy(@PathVariable Integer policyId,@RequestBody Claim claim) {
//		try {
//			Claim claims = claimService.claimByPurchasePolicyId(policyId, claim);
//			return new ResponseEntity<>(claims, HttpStatus.CREATED);
//		} catch (ClaimException e) {
//			e.printStackTrace();
//			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
//		}
//		
//	}

}
