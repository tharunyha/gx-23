package com.bajaj.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.modal.PurchasePolicy;
import com.bajaj.exception.CredentialException;
import com.bajaj.exception.DurationException;
import com.bajaj.exception.MyPolicyException;
import com.bajaj.exception.PaymentException;
import com.bajaj.exception.RenewException;
import com.bajaj.exception.StartDateException;
import com.bajaj.modal.PayPremium;
import com.bajaj.service.BuyPolicyService;

@RestController
@CrossOrigin("*")
public class BuyPolicyController {

	@Autowired
	BuyPolicyService buyService;
 
	@PostMapping("/BuyPolicy/{policyId}/{userId}/{policyPremiumId}")
	public ResponseEntity<?> createPolicy(@RequestBody PurchasePolicy policy,@PathVariable Integer policyId,@PathVariable Integer userId,@PathVariable Integer policyPremiumId) {
		
		try {
			PurchasePolicy newPolicy = buyService.purchasePolicy(policy,policyId,userId,policyPremiumId);
			return new ResponseEntity<>(newPolicy, HttpStatus.CREATED);
		} catch (StartDateException| DurationException| MyPolicyException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
		
	}

	@GetMapping("/Policy/{policyId}")
	public ResponseEntity<?> getPolicy(@PathVariable Integer policyId) {
		try {
			Optional<PurchasePolicy> policy = buyService.getPolicy(policyId);
			return new ResponseEntity<>(policy, HttpStatus.OK);
		} catch (MyPolicyException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}

	}

//	@GetMapping("/Policy/{policyId}/paymenthistory")
//	public ResponseEntity<?> getPolicyPaymentHistory(@PathVariable Integer policyId) {
//
//		try {
//			List<PayPremium> payment = buyService.premiumPaymentHistory(policyId);
//			return new ResponseEntity<>(payment, HttpStatus.OK);
//		} catch (PaymentException e) {
//			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
//		}
//
//	}

	@PutMapping("/RenewPolicy/{policyId}/{premiumId}")
	public ResponseEntity<?> updatePolicy(@PathVariable Integer policyId,@PathVariable Integer premiumId, @RequestBody PurchasePolicy policy) {

		try {
			PurchasePolicy oldPolicy = buyService.updatePolicy(policyId, premiumId, policy);
			return new ResponseEntity<>(oldPolicy, HttpStatus.ACCEPTED);
		} catch (StartDateException| DurationException| MyPolicyException| RenewException e) {
			e.printStackTrace();
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}

	}

	@DeleteMapping("/deletePolicyApplication/{buyPolicyId}")
	public ResponseEntity<String>  deletePolicyApplication(@PathVariable Integer buyPolicyId) {
		try {
			buyService.cancelPolicy(buyPolicyId);
			return new ResponseEntity<>("Policy cancelled",HttpStatus.ACCEPTED);
		} catch (Exception e) {
			return new ResponseEntity<> (e.getMessage(),HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/MyPolicy/{buyPolicyId}/{password}")
	public ResponseEntity<?> getMyPolicy(@PathVariable Integer buyPolicyId, @PathVariable String password) {
		try {
			PurchasePolicy oldPolicy = buyService.myPolicy(buyPolicyId, password);
			return new ResponseEntity<>(oldPolicy, HttpStatus.OK);
		} catch (CredentialException | MyPolicyException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}
	
	@GetMapping("/MyPolicy/{username}")
	public ResponseEntity<?> getMyPolicy(@PathVariable String username) {
		try {
			List<PurchasePolicy> myPolicy = buyService.myPolicies(username);
			return new ResponseEntity<>(myPolicy, HttpStatus.OK);
		} catch (MyPolicyException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

}
