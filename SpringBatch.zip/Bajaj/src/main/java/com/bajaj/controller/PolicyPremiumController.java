package com.bajaj.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.exception.PolicyPremiumException;
import com.bajaj.modal.PolicyPremium;
import com.bajaj.service.PolicyPremiumService;

@RestController
@CrossOrigin("*")
public class PolicyPremiumController {
	
	@Autowired
	PolicyPremiumService policyPremiumService;
	
	 
    @PreAuthorize("hasAuthority('ADMIN')")
	@PostMapping("/postPremium")
	public ResponseEntity<PolicyPremium>createPolicy(@RequestBody PolicyPremium premium){
		PolicyPremium newPremium = policyPremiumService.createPremium(premium);
		return new ResponseEntity<>(newPremium,HttpStatus.CREATED);
	}
	
	@GetMapping("/PolicyPremium/{returnAmount}")
	public ResponseEntity<?>getPolicy(@PathVariable double returnAmount){
		
		try {
			PolicyPremium premium = policyPremiumService.getByReturnAmount(returnAmount);
			return new ResponseEntity<>(premium,HttpStatus.OK);	
		} catch (PolicyPremiumException e) {
			e.printStackTrace();
			return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);	
		}
		
	}
	
	@GetMapping("/PolicyPremium")
	public ResponseEntity<?>getPolicy(){

			List<PolicyPremium> premium = policyPremiumService.getAllPremium();
			return new ResponseEntity<>(premium,HttpStatus.OK);	
		
	}
	

}
