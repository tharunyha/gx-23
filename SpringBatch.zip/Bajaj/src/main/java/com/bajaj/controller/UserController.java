package com.bajaj.controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bajaj.exception.CredentialException;
import com.bajaj.exception.PasswordException;
import com.bajaj.exception.UserEmailException;
import com.bajaj.exception.UserException;
import com.bajaj.exception.UserPhoneException;
import com.bajaj.modal.AuthRequest;
import com.bajaj.modal.Users;
import com.bajaj.repo.UsersRepo;
import com.bajaj.service.UserService;
import com.bajaj.serviceimpl.JwtService;
import com.bajaj.utils.ExceptionUtils;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin("*")
public class UserController {
	@Autowired
	UserService userService;

	@Autowired
	UsersRepo usersRepo;

	@Autowired
	private JwtService jwtService;

	@Autowired
	AuthenticationManager authenticationManager;

	@PostMapping("/Register")
	public ResponseEntity<?> createUser(@RequestBody Users user) {
		try {

			user.setUserStatus(true);
			userService.createUser(user);
			String response = "Successfully Registered\n" + "Username: " + user.getUserName() + "\n" + "User email: "
					+ user.getUserEmail() + "\n" + "Phone number: " + user.getUserPhoneNumber() + "\n"
					+ "Date of Birth: " + user.getDob();
			return new ResponseEntity<>(response, HttpStatus.CREATED);
		} catch (UserException | UserEmailException | UserPhoneException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}

	@GetMapping("/Users")
	public ResponseEntity<List<Users>> getAllUsers() {
		List<Users> user = userService.getAllUsers();
		return new ResponseEntity<>(user, HttpStatus.OK);
	}

	@GetMapping("/User/{username}")
	public ResponseEntity<?> getByUsername(@PathVariable String username) {
		try {
			Optional<Users> user = userService.getUserByName(username);
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/updateUser/{id}")
	public ResponseEntity<?> updateUser(@PathVariable Integer id, @RequestBody Users user) {

		try {
			return new ResponseEntity<>(userService.modifyUser(id, user), HttpStatus.ACCEPTED);
		} catch (UserException|UserEmailException|PasswordException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}

	@DeleteMapping("/deleteUser/{id}")
	public ResponseEntity<String> deleteAccount(@PathVariable Integer id) {
		String deleteUser = userService.deleteUser(id);
		return new ResponseEntity<>(ExceptionUtils.USERDELETED_MESSAGE, HttpStatus.OK);
	}

	@GetMapping("/login/{email}/{password}")
	public ResponseEntity<?> userLogin(@PathVariable String email, @PathVariable String password) {

		try {
			Users user = userService.loginValidation(email, password);
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserException | UserEmailException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}

	@PatchMapping("/updatePassword/{email}/{password}")
	public ResponseEntity<?> updatePassword(@PathVariable String email, @PathVariable String password) {
		try {
			return new ResponseEntity<>(userService.forgotPassword(email, password), HttpStatus.ACCEPTED);
		} catch (NullPointerException e) {
			return new ResponseEntity<>("No user found", HttpStatus.NOT_FOUND);
		}catch (PasswordException ex) {
			return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}

	@PostMapping("/auth/generateToken")
	public ResponseEntity<?> authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
		 try {	
				Users user = userService.loginValidation(authRequest.getEmail(), authRequest.getPassword());
				Authentication authentication = authenticationManager.authenticate(
						new UsernamePasswordAuthenticationToken(authRequest.getEmail(), authRequest.getPassword()));
				authentication.isAuthenticated();
				String token = jwtService.generateToken(authRequest.getEmail());
				return new ResponseEntity<>(token, HttpStatus.OK);
			} catch (UserException | UserEmailException e) {
				return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
			}
		}

	@GetMapping("/auth/user")
	@PreAuthorize("hasAuthority('USER')")
	public String userProfile() {
		return "Welcome to User Profile";
	}

	@GetMapping("/auth/admin")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String adminProfile() {
		return "Welcome to Admin Profile";
	}

    @GetMapping("/user")
    @ResponseBody
    public ResponseEntity<?> currentUserRole(@AuthenticationPrincipal UserDetails userDetails) {
        
        try {
			Optional<Users> user = userService.getUserByEmail(userDetails.getUsername());
			String useremail = userDetails.getAuthorities().toString();
		    return new ResponseEntity<>(useremail, HttpStatus.OK);
		} catch (UserException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
        
    }

	@GetMapping("/userinfo")
	public ResponseEntity<?> getUser(@AuthenticationPrincipal UserDetails userDetails) {
		try {
			String useremail = userDetails.getUsername();
			Optional<Users> user = userService.getUserByEmail(useremail);
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);

		}
	}
}
