package com.bajaj.modal;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "users")
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Users {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "UserId")
	private Integer userId;
	
	@Column(name = "UserName")
	private String userName;
	
	@Column(name = "Password")
	private String password;
	
	@Column(name = "UserEmail")
	private String userEmail;
	
	@Column(name = "UserPhoneNumber")
	private String userPhoneNumber;
	
	@Column(name = "UserRole")
	private String userRole;
	
	@Column(name = "DateOfBirth")
	private Date dob;
	
	@Column(name = "UserAccountStatus")
	private Boolean userStatus;
	
	@OneToMany(mappedBy = "user" ,cascade=CascadeType.ALL)
	@JsonIgnore
	private List<PurchasePolicy> buyPolicy;


}
