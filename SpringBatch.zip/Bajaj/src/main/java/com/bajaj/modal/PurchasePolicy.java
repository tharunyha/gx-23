package com.bajaj.modal;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;



import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchasePolicy {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "PurchasePolicyId")
	private Integer buyPolicyId;
	

	@Column(name = "PolicyStartDate")
	private Date policyStartDate;
	
	@Column(name = "PolicyEndDate")
	private Date policyEndDate;
	
	@Column(name = "PolicyAmount")
	private Double policyAmount;

	@JoinColumn(name = "InsuranceDetails")
	private List<String>insuranceDetails;
	
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "Users")
	private Users user;
	
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "Policy")
	private Policy policy;
	
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "PaymentDetails")
	private PolicyPremium policyPremium;
	
	@OneToMany(mappedBy = "buyPolicy" ,cascade=CascadeType.ALL)
    @JsonIgnore
	private List<Claim> claim;
	
	
	@OneToMany(mappedBy = "buyPolicy" ,cascade=CascadeType.ALL)
	@JsonIgnore
	private List<PayPremium> payPremium;
	
	
	

	
}
