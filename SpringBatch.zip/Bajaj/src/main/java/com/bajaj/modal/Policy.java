package com.bajaj.modal;

import java.util.Date;
import java.util.List;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@EntityListeners(AuditingEntityListener.class)
@Entity
@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Policy {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PolicyId")
	private Integer policyID;
	
	@Column(name = "PolicyName")
	private String policyName;
	
	@Column(name = "PurchaseCategory")
	private String policyCategory;

	@Column(length=1500,name = "PolicyDescription")
	private String policyDescription;
	
	@Column(name = "PolicyStatus")
	private Boolean policyStatus;
	
	@CreatedBy
	@Column(name = "PolicyCreatedBy")
	private String createdBy;
	
	@Column(nullable = false,updatable = false,name = "PolicyCreatedOn")
	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	
	@LastModifiedBy
	@Column(name = "PolicyModifiedBy")
	private String modifiedBy;
	
	@LastModifiedDate
	@Column(name = "PolicyModifiedOn")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;
	
	
	@OneToMany(mappedBy = "policy" ,cascade=CascadeType.ALL)
	@JsonIgnore
	private List<PurchasePolicy> buyPolicy;
	
	@OneToMany(mappedBy = "policy" ,cascade=CascadeType.ALL)
	@JsonIgnore
	private List<PolicyPremium> policyPremium;
	

	
}
