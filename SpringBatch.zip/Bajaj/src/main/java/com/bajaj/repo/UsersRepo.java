package com.bajaj.repo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bajaj.modal.Users;
import java.util.List;
import java.util.Optional;

@Repository
public interface UsersRepo extends JpaRepository<Users,Integer > {
	
	@Query(value = "SELECT * FROM users WHERE user_email= :useremail OR user_name= :username OR user_phone_number= :phonenumber", nativeQuery = true)
	Users findUserExists(@Param("useremail")String userEmail,@Param("username")String userName,@Param("phonenumber")String userPhoneNumber);
	
	
	
	@Query(value="Select * FROM users where user_email=:useremail AND password=:password", nativeQuery = true)
	Users  findByUserEmailAndPassword(@Param("useremail")String userEmail,@Param("password") String password);
	
	@Query(value="Select * FROM users where user_name=:username", nativeQuery = true)
	Optional<Users>  findByUserName(@Param("username") String userName);

	
	@Query(value="Select * FROM users where user_email=:useremail", nativeQuery = true)
	Users  findByUserEmail(@Param("useremail") String userEmail);
	
	@Query(value="Select * FROM users where user_account_status=1", nativeQuery = true)
	List<Users> findByUserStatus();


	
}
