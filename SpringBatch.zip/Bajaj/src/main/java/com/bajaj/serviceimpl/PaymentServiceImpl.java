package com.bajaj.serviceimpl;

/**
 * this is a service class for payment
 * this service contains methods to do payment, get payment by payment id
 * and get list of payments by policy id
 * @author tsenthilkumar
 */
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bajaj.exception.PaymentException;
import com.bajaj.modal.PayPremium;
import com.bajaj.repo.PayPremiumRepo;
import com.bajaj.service.PremiumPaymentService;
import com.bajaj.utils.ExceptionUtils;

@Service
public class PaymentServiceImpl implements PremiumPaymentService  {
	
	@Autowired
	PayPremiumRepo payRepo;
	
	/**
	 * this method is to pay premium(create pay)
	 * @param PayPremium
	 * @return PayPremium created
	 */
	
	@Override
	public PayPremium payPremium(PayPremium  payment) {
		return payRepo.save(payment);
	}
	
	/**
	 * this method is to get payment by payment id
	 * @param String id- payment Id
	 * @exception PaymentException - throws exception if no payment found for given id
	 * @return PayPremium details for given id
	 */
	
	@Override
	public Optional<PayPremium> getPremiumbyId(String id) throws PaymentException {
		Optional<PayPremium>payPremium=payRepo.findById(id);
		if(payPremium.isPresent()) {
			return payPremium;
		}
		throw new PaymentException(ExceptionUtils.PAYMENT_NOTFOUND);
	}
	
	/**
	 * this method is to get list of payments by policy id
	 * @param String id- policy Id
	 * @exception PaymentException - throws exception if no payment found for given id
	 * @return List -PayPremiums 
	 */
	
	@Override
	public List<PayPremium> getAllById(Integer id) throws PaymentException {
		List<PayPremium> premium = payRepo.getPaymentByPolicy(id);
		if(premium!=null) {
			return premium;
		}
		throw new PaymentException(ExceptionUtils.PAYMENT_NOTFOUND);
	}

}
