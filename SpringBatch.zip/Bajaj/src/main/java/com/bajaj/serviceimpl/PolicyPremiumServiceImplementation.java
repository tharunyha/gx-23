package com.bajaj.serviceimpl;

/**
 * this is a service class for policy premium
 * it contains method to create premium, get all premiums and get by return amount
 * @author tsenthilkumar
 */
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bajaj.exception.PolicyPremiumException;
import com.bajaj.modal.PolicyPremium;
import com.bajaj.repo.PolicyPremiumRepo;
import com.bajaj.service.PolicyPremiumService;
import com.bajaj.utils.ExceptionUtils;
@Service
public class PolicyPremiumServiceImplementation implements PolicyPremiumService {
	
	@Autowired
	PolicyPremiumRepo policyPremiumRepo;
	
	/**
	 * this method is to create new premium for policy
	 * @param PolicyPremium
	 * @return PolicyPremium
	 */
	
	@Override
	public PolicyPremium createPremium(PolicyPremium premium) {
		return policyPremiumRepo.save(premium);
	}
	
	/**
	 * this method is to get premium for policy by return amount
	 * @param double- returnAmount
	 * @exception PolicyPremiumException - throws exception if no premium found
	 * 			 for given return amount
	 * @return PolicyPremium
	 */

	@Override
	public PolicyPremium getByReturnAmount(double returnAmount) throws PolicyPremiumException {
		Optional<PolicyPremium> premium= Optional.of(policyPremiumRepo.findByReturnAmount(returnAmount));
		if(premium.isPresent()) {
			return premium.get();
		}
		throw new PolicyPremiumException(ExceptionUtils.PREMIUM_EXCEPTION);
	}
	
	/**
	 * this method is to get all premiums
	 * @return List- list of PolicyPremiums
	 */

	@Override
	public List<PolicyPremium> getAllPremium() {
		return policyPremiumRepo.findAll();
	}

}
