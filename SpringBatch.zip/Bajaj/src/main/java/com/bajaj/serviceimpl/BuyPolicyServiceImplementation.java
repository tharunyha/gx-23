package com.bajaj.serviceimpl;

/**
 * this is a service class for purchase policy
 * this service class contains methods like create,get, update and delete purchase policy
 * along with getting payment history for given purchased policy
 * @author tsenthilkumar
 */

import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.bajaj.modal.PurchasePolicy;
import com.bajaj.modal.Users;
import com.bajaj.exception.CredentialException;
import com.bajaj.exception.DurationException;
import com.bajaj.exception.EndDateException;
import com.bajaj.exception.MyPolicyException;
import com.bajaj.exception.RenewException;
import com.bajaj.exception.StartDateException;
//import com.bajaj.exception.PaymentException;
//import com.bajaj.modal.PayPremium;
import com.bajaj.modal.Policy;
import com.bajaj.modal.PolicyPremium;
import com.bajaj.repo.BuyPolicyRepo;
import com.bajaj.repo.PolicyPremiumRepo;
import com.bajaj.repo.PolicyRepo;
import com.bajaj.repo.UsersRepo;
import com.bajaj.service.BuyPolicyService;
import com.bajaj.utils.ExceptionUtils;

@Service
public class BuyPolicyServiceImplementation implements BuyPolicyService {

	@Autowired
	BuyPolicyRepo buyPolicyRepo;

	@Autowired
	UsersRepo usersRepo;

	@Autowired
	PolicyRepo policyRepo;

	@Autowired
	PolicyPremiumRepo policyPremiumRepo;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	/**
	 * this method is to purchase new Policy
	 * 
	 * @param PurchasePolicy - details of policy to be purchased
	 * @param Integer        - policyId that you are purchasing
	 * @param Integer        - userId
	 * @param Integer        - policyPremiumId
	 * @exception MyPolicyException- throws exception if premium details is not
	 *                               available for the policy
	 * @return PurchasePolicy- details of purchased policy
	 */

	@Override
	public PurchasePolicy purchasePolicy(PurchasePolicy buy, Integer policyId, Integer userId, Integer policyPremiumId)
			throws StartDateException, DurationException, MyPolicyException {
		Optional<Policy> policy = policyRepo.findById(policyId);
		Optional<Users> users = usersRepo.findById(userId);
		buy.setPolicy(policy.get());
		buy.setUser(users.get());
		LocalDate startDate = buy.getPolicyStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate endDate = buy.getPolicyEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		long duration = Duration.between(startDate.atStartOfDay(), endDate.atStartOfDay()).toDays() / 365;
		if (duration > 3 || duration < 1) {
			throw new DurationException("Duration should atleast be 1 year and maximum be 3 years");
		}
		LocalDate now = LocalDate.now();
		if (startDate.compareTo(now) < 0) {
			throw new StartDateException("Give present date or future date");
		}
		Optional<PolicyPremium> premium = policyPremiumRepo.findById(policyPremiumId);
		buy.setPolicyPremium(premium.get());
		if (premium.isPresent()) {
			buy.setPolicyAmount(duration == 1 ? premium.get().getDurationOne()
					: (duration == 2 ? premium.get().getDurationTwo()
							: (duration == 3 ? premium.get().getDurationThree() : null)));
			return buyPolicyRepo.save(buy);
		}
		throw new MyPolicyException(ExceptionUtils.PURCHASE_FAILED);

	}

	/**
	 * this method is to get purchased policy by id
	 * 
	 * @param Integer- id
	 * @exception MyPolicyException- throws exception if no purchase policy is found
	 *                               with given id;
	 * @return PurchasePolicy
	 */

	@Override
	public Optional<PurchasePolicy> getPolicy(Integer id) throws MyPolicyException {
		Optional<PurchasePolicy> policy = buyPolicyRepo.findById(id);
		if (policy.isPresent()) {
			return policy;
		}
		throw new MyPolicyException(ExceptionUtils.PURCHASEPOLICY_EXCEPTION);
	}

	/**
	 * this method is to renew Purchased Policy
	 * 
	 * @param PurchasePolicy - details of policy to be purchased
	 * @param Integer        - purchased policy id
	 * @param Integer        - policyPremiumId
	 * @exception MyPolicyException- throws exception if premium details is not
	 *                               available for the policy
	 * @return PurchasePolicy- details of renewed policy
	 * @throws RenewException 
	 */

	@Override
	public PurchasePolicy updatePolicy(Integer policyId, Integer policyPremiumId, PurchasePolicy policy)
			throws StartDateException, DurationException, MyPolicyException, RenewException {

		Optional<PurchasePolicy> buypolicy = Optional.of(buyPolicyRepo.findById(policyId)
				.orElseThrow(() -> new MyPolicyException(ExceptionUtils.PURCHASEPOLICY_EXCEPTION)));
		if (buypolicy.isPresent()) {
			PurchasePolicy renewPolicy = buypolicy.get();
			renewPolicy.setPolicyEndDate(policy.getPolicyEndDate());
			renewPolicy.setPolicyStartDate(policy.getPolicyStartDate());
			if (policy.getPolicyStartDate().compareTo(buypolicy.get().getPolicyEndDate()) > 0) {
				LocalDate startDate = (policy.getPolicyStartDate().toInstant().atZone(ZoneId.systemDefault())
						.toLocalDate());
				LocalDate endDate = policy.getPolicyEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				long duration = Duration.between(startDate.atStartOfDay(), endDate.atStartOfDay()).toDays() / 365;
				Optional<PolicyPremium> premium = policyPremiumRepo.findById(policyPremiumId);

				if (duration > 3 || duration < 1) {
					throw new DurationException("Duration should atleast be 1 year and maximum be 3 years");
				}
				LocalDate now = LocalDate.now();
				if (startDate.compareTo(now) < 0) {
					throw new StartDateException("Give present date or future date");
				}
				buypolicy.get().setPolicyPremium(premium.get());
				if (premium.isPresent()) {
					buypolicy.get()
							.setPolicyAmount(duration == 1 ? premium.get().getDurationOne()
									: (duration == 2 ? premium.get().getDurationTwo()
											: (duration == 3 ? premium.get().getDurationThree() : null)));
				}
				PurchasePolicy update = buypolicy.get();
				return buyPolicyRepo.save(update);	
			} if (policy.getPolicyStartDate().compareTo(buypolicy.get().getPolicyEndDate()) < 0) {
				throw new RenewException("Policy cannot be renewed before the term ends.");
				
			}
			
		}
		throw new MyPolicyException(ExceptionUtils.RENEW_EXCEPTION);
	}

	/**
	 * this method is to delete the policy purchased
	 * 
	 * @param Integer- PurchasePolicyid
	 * @exception MyPolicyException- throws exception if no purchase found with
	 *                               given id
	 * @return String- message to display
	 */

	@Override
	public String cancelPolicy(Integer buypolicyid) throws MyPolicyException {
		Optional<PurchasePolicy> policy = buyPolicyRepo.findById(buypolicyid);
		if (policy.isPresent()) {
			buyPolicyRepo.deleteById(buypolicyid);
			return ExceptionUtils.PURCHASEPOLICYCANCEL_MESSAGE;
		}
		throw new MyPolicyException(ExceptionUtils.PURCHASEPOLICY_EXCEPTION);
	}

//	@Override
//	public List<PayPremium> premiumPaymentHistory(Integer id) throws PaymentException {
//		Optional<PurchasePolicy> policy = buyPolicyRepo.findById(id);
//		if (policy.isPresent()) {
//			return policy.get().getPayPremium();
//		}
//		throw new PaymentException(ExceptionUtils.PURCHASE_FAILED);
//	}

	/**
	 * this method is to get purchase policy detail after validating the user
	 * 
	 * @param Integer- purchase policy id
	 * @param String   - user password
	 * @exception CredentialException - throws exception on invalid credentials
	 * @return Purchased policy details of given id
	 */

	@Override
	public PurchasePolicy myPolicy(Integer buypolicyId, String password) throws MyPolicyException, CredentialException {
		PurchasePolicy policy = buyPolicyRepo.findById(buypolicyId).orElseThrow(MyPolicyException::new);
		if (!policy.equals(null)) {
			String encryptedPassword = policy.getUser().getPassword();
			Boolean validate = passwordEncoder.matches(password, encryptedPassword);
			if (validate == true) {
				return policy;
			}
		}
		throw new CredentialException(ExceptionUtils.CREDENTIAL_EXCEPTION);
	}

	/**
	 * this method is to fetch list of policies purchased by user
	 * 
	 * @param String username
	 * @exception MyPolicyException throws exception if no user found with given
	 *                              username
	 * @return List of policies purchased by user
	 */

	@Override
	public List<PurchasePolicy> myPolicies(String username) throws MyPolicyException {
		Optional<Users> user = usersRepo.findByUserName(username);
		if (user != null) {
			return buyPolicyRepo.findByUsers_Username(username);
		}
		throw new MyPolicyException(ExceptionUtils.PURCHASEPOLICY_EXCEPTION);

	}

}
