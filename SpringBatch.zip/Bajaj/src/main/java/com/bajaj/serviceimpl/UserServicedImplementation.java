package com.bajaj.serviceimpl;

/**
 *this is a service class for user 
 * this service contains methods to create, get, update, delete users 
 * along with login and forgot password
 * @author tsenthilkumar;
 */

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.bajaj.exception.PasswordException;
import com.bajaj.exception.UserEmailException;
import com.bajaj.exception.UserException;
import com.bajaj.modal.Users;
import com.bajaj.repo.UsersRepo;
import com.bajaj.service.UserService;
import com.bajaj.utils.ExceptionUtils;
import com.bajaj.utils.RoleUtils;

@Service
public class UserServicedImplementation implements UserService, UserDetailsService {

	@Autowired
	UsersRepo usersRepo;
	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	/**
	 * this method is used to create new user
	 * 
	 * @param Users - takes user detail
	 * @exception UserException - throws error if user with same email,phone number,
	 *                          username exists
	 * @return Users detail
	 */

	@Override
	public Users createUser(Users user) throws UserException {
		if (usersRepo.findUserExists(user.getUserEmail(), user.getUserName(), user.getUserName()) != null) {
			throw new UserException(ExceptionUtils.USER_EXIST);

		}
		if ((user.getUserRole() == null || user.getUserRole().isEmpty()) && user.getUserEmail() == null
				|| !user.getUserEmail().endsWith(ExceptionUtils.ADMIN_EMAIL)) {
			user.setUserRole(RoleUtils.ROLE_USER);

		} else {
			user.setUserRole(RoleUtils.ROLE_ADMIN);
		}
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		Users users = (usersRepo.save(user));
		return users;
	}

	/**
	 * this method is used to get all existing users
	 * 
	 * @return list of users
	 */

	@Override
	public List<Users> getAllUsers() {
		return usersRepo.findAll();
	}

	/**
	 * this method is used to get user by username
	 * 
	 * @param String - username
	 * @exception UserException- throws exception if username not exists
	 * @return User
	 */

	@Override
	public Optional<Users> getUserByName(String username) throws UserException {
		Optional<Users> user = usersRepo.findByUserName(username);
		if (user == null) {
			throw new UserException(ExceptionUtils.USERNAME_EXCEPTION);
		}
		return user;
	}

	@Override
	public Optional<Users> getUserByEmail(String useremail) throws UserException {
		Optional<Users> user = Optional.of(usersRepo.findByUserEmail(useremail));
		if (user == null) {
			throw new UserException(ExceptionUtils.USERNAME_EXCEPTION);
		}
		return user;
	}

	/**
	 * this is login method
	 * 
	 * @param String- userEmail
	 * @param String- password
	 * @exception UserEmailException- throws exception if email not exists
	 * @exception UserException-      throws exception if password is incorrect
	 * @return user details
	 */

	@Override
	public Users loginValidation(String useremail, String password) throws UserException, UserEmailException {
		Users user = usersRepo.findByUserEmail(useremail);
		if (user == null) {
			throw new UserEmailException(ExceptionUtils.USEREMAIL_EXCEPTION);
		}
		String encryptedPassword = user.getPassword();

		if (!passwordEncoder.matches(password, encryptedPassword)) {
			throw new UserException(ExceptionUtils.PASSWORD_EXCEPTION);
		} else {

			return user;
		}

	}

	/**
	 * this is user detail update method
	 * 
	 * @param integer- userId
	 * @param user
	 * @exception Exception- throws Exception if user with same details already
	 *                       exists
	 * @return user
	 */

//	@Override
//	public Users modifyUser(Integer id, Users user) throws Exception {
//		Optional<Users> users = usersRepo.findById(id);
//		if (users.isPresent()) {
//			Users userEntity=users.get();
//			if(user.getUserName()==null||user.getUserName().isEmpty()) {
//				userEntity.setUserName(users.get().getUserName());
//			}else {
//				userEntity.setUserName(user.getUserName());
//			}
//			if(user.getUserEmail()==null||user.getUserEmail().isEmpty()) {
//				userEntity.setUserEmail(users.get().getUserEmail());
//			}else {
//				userEntity.setUserName(user.getUserEmail());
//			}
//			if(user.getUserPhoneNumber()==null||user.getUserPhoneNumber().isEmpty()) {
//				userEntity.setUserPhoneNumber(users.get().getUserPhoneNumber());
//			}else {
//				userEntity.setUserPhoneNumber(user.getUserPhoneNumber());
//			}
//			if(user.getDob()==null||((CharSequence) user.getDob()).isEmpty()) {
//				userEntity.setDob(users.get().getDob());
//			}else {
//				userEntity.setDob(user.getDob());
//			}
//
//			if(user.getPassword()==null) {
//				userEntity.setPassword(users.get().getPassword());
//			}else {
//				String encodedPassword = passwordEncoder.encode(user.getPassword());
//				userEntity.setPassword(encodedPassword);
//			}
//			if ((userEntity.getUserRole() == null || userEntity.getUserRole().isEmpty()) && userEntity.getUserEmail() == null
//					|| !userEntity.getUserEmail().endsWith(ExceptionUtils.ADMIN_EMAIL)) {
//				userEntity.setUserRole(RoleUtils.ROLE_USER);
//
//			} else {
//				userEntity.setUserRole(RoleUtils.ROLE_ADMIN);
//			}
//			if (usersRepo.findUserExists(user.getUserEmail(), user.getUserName(), user.getUserPhoneNumber()) != null) {
//				throw new Exception(ExceptionUtils.USER_EXIST);
//
//			}else {
//				usersRepo.save(userEntity);  
//				return userEntity;	
//			}
//			
//		}
//		
//		else {
//			throw new UserException("User not Found");
//		}
//		
//	}
	@Override
	public Users modifyUser(Integer id, Users user) throws UserException, UserEmailException, PasswordException {
		Optional<Users> users = usersRepo.findById(id);
		if (users.isPresent()) {
			Users userEntity = users.get();
			// Use the ternary operator to assign values based on conditions
			userEntity
					.setUserName(user.getUserName() == null || user.getUserName().isEmpty() ? users.get().getUserName()
							: user.getUserName());
			userEntity.setUserEmail(
					user.getUserEmail() == null || user.getUserEmail().isEmpty() ? users.get().getUserEmail()
							: user.getUserEmail());
			userEntity.setUserPhoneNumber(user.getUserPhoneNumber() == null || user.getUserPhoneNumber().isEmpty()
					? users.get().getUserPhoneNumber()
					: user.getUserPhoneNumber());
			userEntity.setDob(user.getDob() == null ? users.get().getDob() : user.getDob());

//			userEntity.setPassword(user.getPassword() == null ? users.get().getPassword()
//					: passwordEncoder.encode(user.getPassword()));
			userEntity.setUserRole((userEntity.getUserRole() == null || userEntity.getUserRole().isEmpty())
					&& (userEntity.getUserEmail() == null
							|| !userEntity.getUserEmail().endsWith(ExceptionUtils.ADMIN_EMAIL)) ? RoleUtils.ROLE_USER
									: RoleUtils.ROLE_ADMIN);

			String encodedPassword = users.get().getPassword();
			String password = user.getPassword();
			if (user.getPassword() == null) {
				userEntity.setPassword(encodedPassword);
			} else if (passwordEncoder.matches(password, encodedPassword)) {
				userEntity.setPassword(encodedPassword);
				throw new PasswordException(ExceptionUtils.SAMEPASSWORD);
			} else {
				String encrypt = passwordEncoder.encode(user.getPassword());
				userEntity.setPassword(encrypt);
			}

			if (usersRepo.findUserExists(user.getUserEmail(), user.getUserName(), user.getUserPhoneNumber()) != null) {
				throw new UserEmailException(ExceptionUtils.USER_EXIST);
			} else {
				usersRepo.save(userEntity);
				return userEntity;
			}

		}

		else {
			throw new UserException(ExceptionUtils.NOUSER_EXCEPTION);
		}

	}

	/**
	 * this method is to soft delete the user account
	 * 
	 * @param Integer - userId
	 * @return String - message to display
	 */

	@Override
	public String deleteUser(Integer userid) {
		Optional<Users> user = usersRepo.findById(userid);
		if (user.isPresent() && user.get().getUserStatus() == true) {
			Users users = user.get();
			users.setUserStatus(false);
			usersRepo.save(users);
			return ExceptionUtils.USERDELETED_MESSAGE;
		}
		return ExceptionUtils.NOUSER_EXCEPTION;
	}

	/**
	 * this method is to update password
	 * 
	 * @param - String userEmail
	 * @param - String password
	 * @return String - message to display
	 * @throws PasswordException
	 * @throws UserException
	 */

	@Override
	public String forgotPassword(String useremail, String password) throws NullPointerException, PasswordException {
		Optional<Users> user = Optional.of(usersRepo.findByUserEmail(useremail));
		if (user.isPresent()) {
			Users entity = user.get();
			String encodedPassword = user.get().getPassword();
			if (passwordEncoder.matches(password, encodedPassword)) {
				throw new PasswordException(ExceptionUtils.SAMEPASSWORD);
			} else {
				String encrypt = passwordEncoder.encode(password);
				entity.setPassword(encrypt);
				usersRepo.save(entity);
			}
			return ExceptionUtils.PASSWORDUPDATE_SUCCESSFUL;
		} else {
			throw new NullPointerException("No user found");
		}
	}

	/**
	 * this method is used to get user by email
	 * 
	 * @param String - email
	 * @exception UsernameNotFoundException- throws exception if user with given id
	 *                                       don't exist
	 * @return User
	 */
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Optional<Users> user = Optional.of(usersRepo.findByUserEmail(email));
		return user.map(UserInfoDetails::new)
				.orElseThrow(() -> new UsernameNotFoundException("User not found " + email));

	}

}
