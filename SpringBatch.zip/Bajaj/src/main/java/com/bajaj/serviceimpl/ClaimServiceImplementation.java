package com.bajaj.serviceimpl;
/**
 * this is a service class for claims
 * this service contains method to create,get and cancel claims
 * @author tsenthilkumar
 */

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bajaj.exception.ClaimException;
import com.bajaj.modal.Claim;
import com.bajaj.repo.ClaimRepo;
import com.bajaj.service.ClaimService;
import com.bajaj.utils.ExceptionUtils;

@Service
public class ClaimServiceImplementation implements ClaimService {

	@Autowired
	ClaimRepo claimRepo;
	
	/**
	 * this method is to create claim
	 * @param Claim-Claim details
	 * @return Claim- created claim details
	 */
	
	@Override
	public Claim newClaim(Claim claim) {
		claim.setActiveStatus(true);
		claim.setClaimstatus(ExceptionUtils.CLAIM_STATUS);
		return claimRepo.save(claim);
	}
	
	/**
	 * this method is to get claim by claim id
	 * @param Integer- claimId
	 * @exception ClaimException- throws exception if no claim for given id is found
	 * @return Claim details for given id
	 */
	
	@Override
	public Optional<Claim> getById(Integer id) throws ClaimException {
		Optional<Claim> claim = claimRepo.findById(id);
		if (claim.isPresent()) {
			return claim;
		}
		throw new ClaimException(ExceptionUtils.CLAIM_EXCEPTION);
	}
	
	/**
	 * this method is to close the claim
	 * @param Integer- claim id
	 * @exception ClaimException- throws exception if no claim found for given id
	 * @return String - message to be displayed
	 */

	@Override
	public String cancelClaim(Integer id) throws ClaimException {
		Optional<Claim> claims = claimRepo.findById(id);
		if (claims.isPresent()) {
			Claim claim = claims.get();
			claim.setActiveStatus(false);
			claim.setClaimstatus("CLOSED");
			claimRepo.save(claim);
			return ExceptionUtils.CLAIMDELETED_MESSAGE;
		}
		throw new ClaimException(ExceptionUtils.CLAIM_EXCEPTION);
	}
	
	/**
	 * this method is to get list of claim by policy id
	 * @param Integer-policyId
	 * @exception ClaimException - throws exception if no claims found for given policyId
	 * @return List- list of claims associated with the given policy id
	 */

	@Override
	public List<Claim> getByPolicy(Integer policyId) throws ClaimException {
		List<Claim> claim = claimRepo.findByPolicy(policyId);
		if (claim!=null) {
			return claim;
		}
		throw new ClaimException(ExceptionUtils.CLAIM_EXCEPTION);
	
	}



}
