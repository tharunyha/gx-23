package com.bajaj.serviceimpl;

/**
 * this service contains methods to create, get, modify and delete policy
 *  along with fetching premium detail
 *  @author tsenthilkumar
 */

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.bajaj.exception.PolicyCategoryNotFound;
import com.bajaj.exception.PolicyNotFound;
import com.bajaj.exception.UserException;
import com.bajaj.modal.Policy;
import com.bajaj.modal.PolicyPremium;

import com.bajaj.repo.PolicyRepo;

import com.bajaj.service.PolicyService;
import com.bajaj.utils.ExceptionUtils;

@Service
public class PolicyServiceImplementation implements PolicyService {

	@Autowired
	PolicyRepo policyRepo;
	
	/**
	 * this method is to get the logged in user
	 */

	AuditorAware<String> auditAware = new AuditorAware<String>() {
		@Override
		public Optional<String> getCurrentAuditor() {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			return Optional.of(((UserDetails) authentication.getPrincipal()).getUsername());
		}
	};

	
	
	/**
	 * this method is to add new policy or update existing policy
	 * @param Policy
	 * @return Policy
	 */
	
	@Override
	public Policy addUpdatePolicy(Policy policies) {
		Optional<String> userEmail = auditAware.getCurrentAuditor();
		if (userEmail.isPresent())
			userEmail.ifPresent(policies::setCreatedBy);
		policies.setModifiedBy(userEmail.orElse(null));
		policies.setPolicyStatus(true);
		return policyRepo.save(policies);
	}
	
	
	/**
	 * this method is to get all the policies
	 * @exception PolicyNotFoundException- throws exception if no 
	 *            policies found
	 * @return List- List of policies
	 */
	@Override
	public List<Policy> getallPolicies() throws PolicyNotFound {
		if (!policyRepo.equals(null)) {
			return policyRepo.findAll();
		}
		throw new PolicyNotFound(ExceptionUtils.ALLPOLICIES_EXCEPTION);
	}
	
	/**
	 * this method is to get List of policies based on category
	 * @param String category
	 * @exception PolicyCategoryNotFoundException- throws exception 
	 *             if no policies found for given category
	 * @return List- List of policies in the category
	 */

	@Override
	public Optional<List<Policy>> getByCategory(String category) throws PolicyCategoryNotFound {
		Optional<List<Policy>> policy = policyRepo.findByPolicyCategoryContaining(category);
		if (policy.isPresent()) {
			return policy;
		}
		throw new PolicyCategoryNotFound(ExceptionUtils.POLICYCATEGORY_EXCEPTION);
	}
	
	/**
	 * this method is to get policy by name
	 * @param String 
	 * @exception PolicyNotFoundException- throws exception if no 
	 *            policy found
	 * @return Policy
	 */
	
	@Override
	public Optional<Policy> getByName(String policyName) throws PolicyNotFound {
		Optional<Policy> policy = policyRepo.findByPolicyNameContaining(policyName);
		if (policy.isPresent()) {
			return policy;
		}
		throw new PolicyNotFound(ExceptionUtils.POLICY_EXCEPTION);
	}
	
	
	/**
	 * this method is to soft delete the policy(inactivate)
	 * @param Integer- policyId
	 * @exception throws PolicyNotFoundException if no policy with
	 * 			 given id is present
	 * @return String - message to display
	 */
	
	@Override
	public String deletePolicy(Integer policyId) throws PolicyNotFound {
		Optional<Policy> policy = policyRepo.findById(policyId);
		if (policy.isPresent()) {
			Policy policyEntity = policy.get();
			policyEntity.setPolicyStatus(false);
			policyRepo.save(policyEntity);
			return ExceptionUtils.POLICYDELETED_MESSAGE;
		}
		throw new PolicyNotFound(ExceptionUtils.POLICY_EXCEPTION);
	}
	
	/**
	 * this method is to get list of premium details
	 * associated with the policy
	 * @param Integer- policyId
	 * @exception throws PolicyNotFoundException if no policy with
	 * 			 given id is present
	 * @return List - List of premiums associated with the policy
	 */

	@Override
	public List<PolicyPremium> policyPremiumDetail(Integer id) throws PolicyNotFound {
		Optional<Policy> policy = policyRepo.findById(id);
		if (policy.isPresent()) {
			return policy.get().getPolicyPremium();
		}
		throw new PolicyNotFound(ExceptionUtils.POLICY_EXCEPTION);

	}
}
