package com.bajaj.exception;

public class PasswordException extends Exception {

	public PasswordException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PasswordException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
