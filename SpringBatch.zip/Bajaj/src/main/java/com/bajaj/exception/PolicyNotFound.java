package com.bajaj.exception;

public class PolicyNotFound extends Exception {

	public PolicyNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PolicyNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
