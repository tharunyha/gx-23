package com.bajaj.exception;

public class PaymentException extends Exception {

	public PaymentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PaymentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
