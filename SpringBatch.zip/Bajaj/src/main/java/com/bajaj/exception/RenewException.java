package com.bajaj.exception;

public class RenewException extends Exception {

	public RenewException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RenewException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
