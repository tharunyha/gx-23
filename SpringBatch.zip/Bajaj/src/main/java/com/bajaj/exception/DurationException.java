package com.bajaj.exception;

public class DurationException extends Exception {

	public DurationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DurationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
