package com.bajaj.exception;

public class EndDateException extends Exception{

	public EndDateException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EndDateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
