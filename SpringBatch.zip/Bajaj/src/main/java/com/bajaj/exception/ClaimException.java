package com.bajaj.exception;

public class ClaimException extends Exception{

	public ClaimException() {
		super();
	}

	public ClaimException(String message) {
		super(message);
	}
	
}
