package com.bajaj.exception;

public class PolicyPremiumException  extends Exception{

	public PolicyPremiumException() {
		super();
		
	}

	public PolicyPremiumException(String message) {
		super(message);
	}

}
