package com.bajaj.exception;

public class StartDateException extends Exception{

	public StartDateException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StartDateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
