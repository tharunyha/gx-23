package com.bajaj.service;

import java.util.List;
import java.util.Optional;

import com.bajaj.exception.ClaimException;
import com.bajaj.modal.Claim;


public interface ClaimService {
	Claim newClaim (Claim claim);
	Optional<Claim> getById(Integer id) throws ClaimException;
	String cancelClaim(Integer id) throws ClaimException;
	List<Claim> getByPolicy(Integer policyId)throws ClaimException;
	//Claim claimByPurchasePolicyId (Integer policyId, Claim claim) throws ClaimException;
}
