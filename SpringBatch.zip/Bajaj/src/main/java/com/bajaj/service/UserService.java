package com.bajaj.service;

import java.util.List;
import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.bajaj.exception.PasswordException;
import com.bajaj.exception.UserEmailException;
import com.bajaj.exception.UserException;
import com.bajaj.exception.UserPhoneException;
import com.bajaj.modal.Users;

public interface UserService {
	Users createUser(Users user) throws UserException, UserEmailException, UserPhoneException ;
	List<Users> getAllUsers();
	Optional<Users>  getUserByName(String username) throws UserException;
	Users loginValidation(String useremail, String password) throws UserException, UserEmailException; ;
	Users modifyUser(Integer userid, Users user)throws UserException,UserEmailException,PasswordException;
	String deleteUser(Integer userid);
	String forgotPassword(String useremail,String password) throws PasswordException, NullPointerException;
	UserDetails loadUserByUsername(String email) throws UsernameNotFoundException ;
	Optional<Users> getUserByEmail(String useremail) throws UserException;		
	
	
}
