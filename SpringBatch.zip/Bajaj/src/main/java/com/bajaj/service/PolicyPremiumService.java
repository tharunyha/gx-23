package com.bajaj.service;

import java.util.List;

import com.bajaj.exception.PolicyPremiumException;
import com.bajaj.modal.PolicyPremium;

public interface PolicyPremiumService {
	
	PolicyPremium createPremium(PolicyPremium premium);
	List<PolicyPremium> getAllPremium();
	PolicyPremium getByReturnAmount(double returnAmount) throws PolicyPremiumException;
}
