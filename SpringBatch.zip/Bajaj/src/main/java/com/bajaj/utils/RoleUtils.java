package com.bajaj.utils;

public class RoleUtils {
	public final static String ROLE_ADMIN="ADMIN";
	public final static String ROLE_USER="USER";
}
