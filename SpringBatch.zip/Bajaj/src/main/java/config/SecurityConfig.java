package config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.bajaj.serviceimpl.UserServicedImplementation;

import filter.JwtAuthFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
	
	
	
	
	 @Autowired
	    private JwtAuthFilter authFilter; 
	  
	    // User Creation 
	    @Bean
	    public UserDetailsService userDetailsService() { 
	        return new UserServicedImplementation(); 
	    } 
	  
	    // Configuring HttpSecurity 
	    @Bean
	    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception { 
//
//	    	http.csrf(AbstractHttpConfigurer::disable)
//	        .authorizeHttpRequests(authorizationManagerRequestMatcherRegistry ->
//	                authorizationManagerRequestMatcherRegistry
//	                        .requestMatchers("/auth/generateToken","/Register","/User/*","/updateUser/**","/deleteUser/**",
//	                        		"/login/**","/updatePassword/**","/BuyPolicy/**","/Policy/**","/RenewPolicy/**",
//	                        		"/deletePolicyApplication/**","/MyPolicy/**","/Claim","/MyClaim/**","/CancelClaim/**",
//	                        		"/payment/**","/PayPremium/**","/AllPolicies","/PoliciesByName/**",
//	                        		"/PoliciesByCategory/**","/PolicyPremium/**","/user","/userinfo").permitAll()
//	                        .requestMatchers("/auth/admin","/NewPolicy","/postPremium",
//                        		"/updatePolicy/**","/deletePolicy/**").hasRole("ADMIN")
//	                        .anyRequest().authenticated())
//	        .httpBasic(Customizer.withDefaults())
//	        .sessionManagement(httpSecuritySessionManagementConfigurer -> httpSecuritySessionManagementConfigurer.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
//
//	      return http.build();
//	    	       
//	    } 
	    return http.csrf().disable() 
                .authorizeHttpRequests() 
                .requestMatchers("/auth/generateToken","/Register",
                		"/login/**","/AllPolicies","/PoliciesByName/**",
                		"/PoliciesByCategory/**").permitAll() 
                .and() 
                .authorizeHttpRequests().requestMatchers("/auth/user").authenticated() 
                .and() 
                .authorizeHttpRequests().requestMatchers("/auth/admin","/NewPolicy","/postPremium",
                		"/updatePolicy/**","/deletePolicy/**").authenticated() 
                .and() 
                .authorizeHttpRequests().anyRequest().authenticated()
                .and()
                .sessionManagement() 
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS) 
                .and() 
                .authenticationProvider(authenticationProvider()) 
                .addFilterBefore(authFilter, UsernamePasswordAuthenticationFilter.class) 
                .build(); 
	    }
	    // Password Encoding 
	    @Bean
		public BCryptPasswordEncoder encoder() {
		    return new BCryptPasswordEncoder();
		} 
	  
	    @Bean
	    public AuthenticationProvider authenticationProvider() { 
	        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider(); 
	        authenticationProvider.setUserDetailsService(userDetailsService()); 
	        authenticationProvider.setPasswordEncoder(encoder()); 
	        return authenticationProvider; 
	    } 
	  
	    @Bean
	    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception { 
	        return config.getAuthenticationManager(); 
	    } 
	  
	  
	 
}
