package com.gxe.controller;

import javax.naming.AuthenticationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gxe.dto.RegisterDto;
import com.gxe.service.UserService;

@RequestMapping
@RestController
public class UserController {
	
	@Autowired
	UserService userserve;
	
	@PostMapping("/register")
	public ResponseEntity<RegisterDto>createUser(@RequestBody RegisterDto rdto) throws AuthenticationException{
		return new ResponseEntity<RegisterDto>(userserve.registerUser(rdto),HttpStatus.CREATED);	
	}

}
