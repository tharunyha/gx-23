package com.gxe.seviceimpl;

import java.util.Optional;

import javax.naming.AuthenticationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gxe.dto.RegisterDto;
import com.gxe.entity.Usersdeet;
import com.gxe.mapper.LoginMapper;
import com.gxe.mapper.RegistrationMapper;
import com.gxe.repo.UserRepo;
import com.gxe.service.UserService;
import com.gxe.util.BajajUtils;

import jakarta.servlet.http.HttpSession;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo userRepo;

	@Autowired
	RegistrationMapper regmap;

	@Override
	public RegisterDto registerUser(RegisterDto rdto) throws AuthenticationException {
		Optional<Usersdeet> existingUser = userRepo.findByUsername(rdto.getUsername());
		if (existingUser.isPresent()) {
			throw new AuthenticationException("Username already exists");
		}
		if ((rdto.getUserrole() == null || rdto.getUserrole().isEmpty())&& ! rdto.getUseremail().endsWith("@galaxe.com") ) {
			rdto.setUserrole(BajajUtils.ROLE_USER);
		}  else if (rdto.getUseremail().endsWith("@galaxe.com")) {
				rdto.setUserrole(BajajUtils.ROLE_ADMIN);
			} else {
				throw new AuthenticationException("Invalid role. Allowed roles are USER and ADMIN.");
			}
		Usersdeet useent = regmap.touser(rdto);
		userRepo.save(useent);
		return regmap.toregisterdto(useent);
	}

	@Override
	public Optional<Usersdeet> getUser(long id) {
		return userRepo.findById(id);	}

	@Override
	public RegisterDto modifyUser(RegisterDto regdto) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
