package com.gxe.dto;

import org.springframework.stereotype.Component;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterDto {
	private String username;
	private String password;
	private String useremail;
	private String userphoneno;
	private String userrole;
	private Boolean userstatus;
}
