package com.gxe.entity;

public class Policy {
	
	

}
