package com.gxe.util;

public class BajajUtils {
	public final static String ROLE_ADMIN ="ADMIN";
	public final static String ROLE_USER ="USER";
}
