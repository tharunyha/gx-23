package com.gxe.mapper;

import com.gxe.dto.LoginDto;
import com.gxe.entity.Usersdeet;

public class LoginMapper {
	
	public LoginDto tologindto(Usersdeet user) {
		LoginDto dto = new LoginDto();
		dto.setUsername(user.getUsername());
		dto.setPassword(user.getPassword());
		return dto;
	}
	
	public Usersdeet touser (LoginDto dto) {
		Usersdeet userent = new Usersdeet();
		userent.setUsername(dto.getUsername());
		userent.setPassword(dto.getPassword());
		return userent;
	}

}
