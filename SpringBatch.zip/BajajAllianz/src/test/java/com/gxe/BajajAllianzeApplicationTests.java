package com.gxe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BajajAllianzeApplicationTests {

	@Test
	void contextLoads() {
	}

}
