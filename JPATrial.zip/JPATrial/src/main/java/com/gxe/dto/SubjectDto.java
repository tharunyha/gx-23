package com.gxe.dto;

public class SubjectDto {
	
	private int subjectcode;
	private String subject;
	private int credits;
	
	
	public int getSubjectcode() {
		return subjectcode;
	}
	public void setSubjectcode(int subjectcode) {
		this.subjectcode = subjectcode;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getCredits() {
		return credits;
	}
	public void setCredits(int credits) {
		this.credits = credits;
	}

}
