package com.gxe.service;

import java.util.List;

import com.gxe.dto.StudentDto;
import com.gxe.entity.Student;
import com.gxe.exception.StudentException;

public interface StudentService {

	 StudentDto enrollStudent(StudentDto studentdto);
	 StudentDto viewStudent(int id) throws StudentException;
	 List<StudentDto> viewallStudent() throws StudentException;
	 StudentDto updateStudent(StudentDto studentdto);
	 void removeStudent(int id) throws StudentException;

}
