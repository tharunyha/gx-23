package com.gxe.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gxe.dao.StudentRepository;
import com.gxe.dto.StudentDto;
import com.gxe.entity.Student;
import com.gxe.exception.StudentException;
import com.gxe.mapper.StudentMapper;
import com.gxe.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	StudentRepository studentrepo;
	@Autowired
	StudentMapper studentmap ;
	
	
	@Override
	public StudentDto enrollStudent(StudentDto studentdto) {
		return studentmap.toStudentdto(studentrepo.save(studentmap.toStudent(studentdto)));
	}
	
	@Override
	public StudentDto viewStudent(int id) throws StudentException {
			Optional<Student> student=studentrepo.findById(id);
			if(student.isPresent()) {
				return studentmap.toStudentdto(student.get());
			}else {
				throw new StudentException("no student with id "+id+" found");
			}		
	}
	
	@Override
	public StudentDto updateStudent(StudentDto studentdto) {
		return studentmap.toStudentdto(studentrepo.save(studentmap.toStudent(studentdto)));
	}
	
	@Override
	public void removeStudent(int id) throws StudentException {
		if(studentrepo.findById(id).isPresent()) {
			studentrepo.deleteById(id);
		}else {
			throw new StudentException("Student not Found");
		}
	}
	@Override
	public List<StudentDto> viewallStudent() throws StudentException {
		List<Student> ti = studentrepo.findAll();
		List<StudentDto> tdt = new ArrayList<>();
		if(!ti.isEmpty()) {
			for(Student tick : ti) {
				tdt.add(studentmap.toStudentdto(tick));
			}
			return tdt;
		}else {
			throw new StudentException("No record found");
		}
	}
	
}
