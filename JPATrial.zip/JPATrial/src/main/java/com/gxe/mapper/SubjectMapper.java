package com.gxe.mapper;

import com.gxe.dto.SubjectDto;
import com.gxe.entity.Subject;

public class SubjectMapper {
	
	public SubjectDto toSubjectdto(Subject subject) {
		SubjectDto dto=new SubjectDto();
		dto.setSubjectcode(subject.getSubjectcode());
		dto.setSubject(subject.getSubject());
		dto.setCredits(subject.getCredits());
		return dto;	
	}
	
	public Subject toSubject(SubjectDto subjectdto) {
		Subject subject=new Subject();
		subject.setSubjectcode(subjectdto.getSubjectcode());
		subject.setSubject(subjectdto.getSubject());
		subject.setCredits(subjectdto.getCredits());
		return subject;	
	}

}
